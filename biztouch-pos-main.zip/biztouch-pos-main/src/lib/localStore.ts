export function getJSON<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function setJSON<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

export const storeKeys = {
  shift: "spa-pos.shift",
  heldBills: "spa-pos.held-bills",
  sales: "spa-pos.sales",
  expenses: "spa-pos.expenses",
} as const;
