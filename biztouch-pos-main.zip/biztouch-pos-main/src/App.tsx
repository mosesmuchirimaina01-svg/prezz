import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Auth from "./pages/Auth";
import CashierDashboard from "./pages/CashierDashboard";
import NewCashierDashboard from "./pages/NewCashierDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import NewAdminDashboard from "./pages/NewAdminDashboard";
import NewBackofficeManagement from "./pages/NewBackofficeManagement";
import SystemManagement from "./pages/SystemManagement";
import ConnectionManagement from "./pages/ConnectionManagement";
import AdminModule from "./pages/AdminModule";
import PWAInstallPrompt from "@/components/PWAInstallPrompt";

const queryClient = new QueryClient();

const App = () => (
  <HelmetProvider>
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <PWAInstallPrompt />
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/cashier" element={<NewCashierDashboard />} />
              <Route path="/admin" element={<NewAdminDashboard />} />
              <Route path="/backoffice" element={<NewBackofficeManagement />} />
              <Route path="/system" element={<SystemManagement />} />
              <Route path="/connection" element={<ConnectionManagement />} />
              <Route path="/admin/:module" element={<AdminModule />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  </HelmetProvider>
);

export default App;
