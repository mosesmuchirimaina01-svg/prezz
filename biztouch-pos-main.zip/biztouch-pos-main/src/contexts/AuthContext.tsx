import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

interface Profile {
  id: string;
  user_id: string;
  username: string;
  full_name: string;
  role: 'admin' | 'manager' | 'supervisor' | 'cashier';
  is_active: boolean;
  company_id?: string;
}

interface Company {
  id: string;
  name: string;
  database_name: string;
  database_url?: string;
  connection_string?: string;
  status: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  selectedCompany: Company | null;
  companies: Company[];
  signIn: (email: string, password: string, companyId: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, userData: { username: string; full_name: string; role?: string; company_id: string; phone_number?: string; id_number?: string; fingerprint?: string | null }) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  selectCompany: (company: Company) => Promise<void>;
  fetchCompanies: () => Promise<Company[]>;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) {
        console.error('Error fetching profile:', error);
        return;
      }

      setProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  };

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          setTimeout(() => {
            fetchProfile(session.user.id);
          }, 0);
        } else {
          setProfile(null);
        }
        
        setLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        fetchProfile(session.user.id);
      }
      
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchCompanies = async (): Promise<Company[]> => {
    const { data, error } = await supabase
      .from('companies')
      .select('id, name, database_name, database_url, connection_string, status')
      .eq('is_active', true)
      .eq('status', 'active');
    
    if (error) {
      console.error('Error fetching companies:', error);
      return [];
    }
    
    setCompanies(data || []);
    return data || [];
  };

  const selectCompany = async (company: Company) => {
    setSelectedCompany(company);
    localStorage.setItem('selectedCompany', JSON.stringify(company));
    
    // Update the user's profile with the selected company_id
    if (user?.id) {
      await supabase
        .from('profiles')
        .update({ company_id: company.id })
        .eq('user_id', user.id);
      
      // Refresh profile to reflect the change
      await fetchProfile(user.id);
    }
  };

  const signIn = async (email: string, password: string, companyId: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    
    if (!error) {
      // Set the selected company after successful login
      const company = companies.find(c => c.id === companyId);
      if (company) {
        selectCompany(company);
      }
    }
    
    return { error };
  };

  const signUp = async (email: string, password: string, userData: { username: string; full_name: string; role?: string; company_id: string; phone_number?: string; id_number?: string; fingerprint?: string | null }) => {
    const redirectUrl = `${window.location.origin}/`;
    
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: userData
      }
    });
    return { error };
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error('Error signing out:', error);
    } else {
      setUser(null);
      setSession(null);
      setProfile(null);
      setSelectedCompany(null);
      localStorage.removeItem('selectedCompany');
    }
  };

  // Load selected company from localStorage on app start
  useEffect(() => {
    const stored = localStorage.getItem('selectedCompany');
    if (stored && user?.id) {
      try {
        const company = JSON.parse(stored);
        setSelectedCompany(company);
        
        // Update profile with the stored company_id
        supabase
          .from('profiles')
          .update({ company_id: company.id })
          .eq('user_id', user.id)
          .then(() => fetchProfile(user.id));
      } catch (error) {
        console.error('Error parsing stored company:', error);
      }
    }
    fetchCompanies();
  }, [user?.id]);

  const value = {
    user,
    session,
    profile,
    selectedCompany,
    companies,
    signIn,
    signUp,
    signOut,
    selectCompany,
    fetchCompanies,
    loading,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};