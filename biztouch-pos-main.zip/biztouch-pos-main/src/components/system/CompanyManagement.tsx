import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2, Plus, Edit, Trash2, Calendar, ExternalLink, Database } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

type Company = {
  id: string;
  name: string;
  contact_person: string;
  email: string;
  phone: string;
  address: string;
  subscription_type: 'basic' | 'premium' | 'enterprise';
  expiry_date: string;
  status: 'active' | 'expired' | 'suspended';
  database_name: string;
  created_at: string;
  last_payment: string;
};

export const CompanyManagement = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [companies, setCompanies] = useState<Company[]>([]);

  // Load companies from database
  React.useEffect(() => {
    const loadCompanies = async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (!error && data) {
        setCompanies(data as any);
      }
    };
    loadCompanies();
  }, []);

  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingCompany, setEditingCompany] = useState<Company | null>(null);
  const [newCompany, setNewCompany] = useState({
    name: "",
    contact_person: "",
    email: "",
    phone: "",
    address: "",
    subscription_type: "basic" as const,
    subscription_months: 12
  });

  const handleCreateCompany = async () => {
    if (!newCompany.name || !newCompany.email || !newCompany.phone) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);
      
      // Call Supabase Edge Function to create company with schema and admin user
      const { data, error } = await supabase.functions.invoke('create-company', {
        body: { company: newCompany }
      });

      if (error || !data?.success) {
        throw new Error((error as any)?.message || data?.error || 'Failed to create company');
      }

      toast({
        title: "✅ Company Created Successfully!",
        description: `${newCompany.name} created with isolated database. Admin credentials sent to ${newCompany.email}`,
      });
      
      setShowCreateDialog(false);
      setNewCompany({
        name: "",
        contact_person: "",
        email: "",
        phone: "",
        address: "",
        subscription_type: "basic",
        subscription_months: 12
      });

      // Refresh companies list
      setTimeout(() => window.location.reload(), 1500);
    } catch (error: any) {
      toast({
        title: "❌ Error",
        description: error.message || "Failed to create company and database",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const createCompanyDatabase = async (company: Company) => {
    // This would create a new Supabase database for the company
    // For now, we'll simulate the SQL setup
    console.log(`Creating database for ${company.name}...`);
    
    const setupSQL = `
      -- Company: ${company.name}
      -- Database: ${company.database_name}
      
      -- Create tables
      CREATE TABLE categories (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        description TEXT,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMPTZ DEFAULT now()
      );
      
      CREATE TABLE suppliers (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        contact_person TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT,
        address TEXT,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMPTZ DEFAULT now()
      );
      
      CREATE TABLE products (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        cost_price DECIMAL(10,2),
        stock_quantity INTEGER DEFAULT 0,
        min_stock_level INTEGER DEFAULT 0,
        category_id UUID REFERENCES categories(id),
        supplier_id UUID REFERENCES suppliers(id),
        is_active BOOLEAN DEFAULT true,
        blocked_from_selling BOOLEAN DEFAULT false,
        created_at TIMESTAMPTZ DEFAULT now()
      );
      
      -- Add more tables as needed...
      
      -- Enable RLS
      ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
      ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
      ALTER TABLE products ENABLE ROW LEVEL SECURITY;
      
      -- Create default admin user
      INSERT INTO auth.users (email, password) VALUES ('${company.email}', 'temp_password_123');
    `;
    
    console.log('SQL Setup:', setupSQL);
    
    // In a real implementation, this would:
    // 1. Create new Supabase project via API
    // 2. Run the SQL setup script
    // 3. Configure authentication
    // 4. Set up initial data
    
    return { success: true, database_url: `https://${company.database_name}.supabase.co` };
  };

  const handleDeleteCompany = (id: string) => {
    setCompanies(prev => prev.filter(c => c.id !== id));
    toast({
      title: "Company Deleted",
      description: "Company and associated database have been removed",
    });
  };

  const handleExtendSubscription = (id: string, months: number) => {
    setCompanies(prev => prev.map(company => {
      if (company.id === id) {
        const currentExpiry = new Date(company.expiry_date);
        const newExpiry = new Date(currentExpiry);
        newExpiry.setMonth(newExpiry.getMonth() + months);
        
        return {
          ...company,
          expiry_date: newExpiry.toISOString().split('T')[0],
          status: 'active' as const,
          last_payment: new Date().toISOString().split('T')[0]
        };
      }
      return company;
    }));
    
    toast({
      title: "Subscription Extended",
      description: `Subscription extended by ${months} months`,
    });
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      active: "default",
      expired: "destructive",
      suspended: "secondary"
    } as const;
    
    return <Badge variant={variants[status as keyof typeof variants]}>{status}</Badge>;
  };

  const getSubscriptionBadge = (type: string) => {
    const colors = {
      basic: "bg-blue-100 text-blue-800",
      premium: "bg-purple-100 text-purple-800",
      enterprise: "bg-orange-100 text-orange-800"
    };
    
    return <Badge className={colors[type as keyof typeof colors]}>{type}</Badge>;
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Building2 className="h-4 w-4" />
          Company Management System
        </h2>
        <div className="flex gap-2">
          <Button size="sm" asChild>
            <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer">
              <ExternalLink className="h-3 w-3 mr-1" />
              Supabase Dashboard
            </a>
          </Button>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-3 w-3 mr-1" />
                New Company
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="text-sm">Create New Company</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">Company Name</Label>
                    <Input
                      value={newCompany.name}
                      onChange={(e) => setNewCompany(prev => ({ ...prev, name: e.target.value }))}
                      className="text-xs h-7"
                      placeholder="ABC Store"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Contact Person</Label>
                    <Input
                      value={newCompany.contact_person}
                      onChange={(e) => setNewCompany(prev => ({ ...prev, contact_person: e.target.value }))}
                      className="text-xs h-7"
                      placeholder="John Doe"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">Email</Label>
                    <Input
                      type="email"
                      value={newCompany.email}
                      onChange={(e) => setNewCompany(prev => ({ ...prev, email: e.target.value }))}
                      className="text-xs h-7"
                      placeholder="admin@company.com"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Phone</Label>
                    <Input
                      value={newCompany.phone}
                      onChange={(e) => setNewCompany(prev => ({ ...prev, phone: e.target.value }))}
                      className="text-xs h-7"
                      placeholder="+254700000000"
                    />
                  </div>
                </div>
                
                <div>
                  <Label className="text-xs">Address</Label>
                  <Input
                    value={newCompany.address}
                    onChange={(e) => setNewCompany(prev => ({ ...prev, address: e.target.value }))}
                    className="text-xs h-7"
                    placeholder="123 Main Street, City"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">Subscription Type</Label>
                    <Select value={newCompany.subscription_type} onValueChange={(value: any) => setNewCompany(prev => ({ ...prev, subscription_type: value }))}>
                      <SelectTrigger className="text-xs h-7">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic - KES 2,000/month</SelectItem>
                        <SelectItem value="premium">Premium - KES 5,000/month</SelectItem>
                        <SelectItem value="enterprise">Enterprise - KES 10,000/month</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">Subscription Period</Label>
                    <Select value={newCompany.subscription_months.toString()} onValueChange={(value) => setNewCompany(prev => ({ ...prev, subscription_months: parseInt(value) }))}>
                      <SelectTrigger className="text-xs h-7">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Month</SelectItem>
                        <SelectItem value="3">3 Months</SelectItem>
                        <SelectItem value="6">6 Months</SelectItem>
                        <SelectItem value="12">12 Months</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => setShowCreateDialog(false)} className="flex-1 text-xs h-7">
                    Cancel
                  </Button>
                  <Button size="sm" onClick={handleCreateCompany} className="flex-1 text-xs h-7">
                    <Database className="h-2 w-2 mr-1" />
                    Create & Setup DB
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-2">
        <Card>
          <CardContent className="p-2">
            <div className="text-center">
              <div className="text-lg font-bold">{companies.length}</div>
              <div className="text-xs text-muted-foreground">Total Companies</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="text-center">
              <div className="text-lg font-bold text-green-600">{companies.filter(c => c.status === 'active').length}</div>
              <div className="text-xs text-muted-foreground">Active</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="text-center">
              <div className="text-lg font-bold text-red-600">{companies.filter(c => c.status === 'expired').length}</div>
              <div className="text-xs text-muted-foreground">Expired</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="text-center">
              <div className="text-lg font-bold">KES 84,000</div>
              <div className="text-xs text-muted-foreground">Monthly Revenue</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Companies Table */}
      <Card>
        <CardHeader className="p-2">
          <CardTitle className="text-sm">Companies & Subscriptions</CardTitle>
        </CardHeader>
        <CardContent className="p-2">
          <div className="overflow-auto max-h-96">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs h-6">Company</TableHead>
                  <TableHead className="text-xs h-6">Contact</TableHead>
                  <TableHead className="text-xs h-6">Subscription</TableHead>
                  <TableHead className="text-xs h-6">Expiry</TableHead>
                  <TableHead className="text-xs h-6">Status</TableHead>
                  <TableHead className="text-xs h-6">Database</TableHead>
                  <TableHead className="text-xs h-6">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {companies.map((company) => (
                  <TableRow key={company.id}>
                    <TableCell className="text-xs">
                      <div>
                        <div className="font-medium">{company.name}</div>
                        <div className="text-muted-foreground">{company.email}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs">
                      <div>
                        <div>{company.contact_person}</div>
                        <div className="text-muted-foreground">{company.phone}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs">
                      {getSubscriptionBadge(company.subscription_type)}
                    </TableCell>
                    <TableCell className="text-xs">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-2 w-2" />
                        {company.expiry_date}
                      </div>
                    </TableCell>
                    <TableCell className="text-xs">
                      {getStatusBadge(company.status)}
                    </TableCell>
                    <TableCell className="text-xs">
                      <code className="text-xs bg-muted px-1 rounded">{company.database_name}</code>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" className="h-5 text-xs px-1">
                          <Edit className="h-2 w-2" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => handleExtendSubscription(company.id, 1)}
                          className="h-5 text-xs px-1"
                        >
                          Extend
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive" 
                          onClick={() => handleDeleteCompany(company.id)}
                          className="h-5 text-xs px-1"
                        >
                          <Trash2 className="h-2 w-2" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};