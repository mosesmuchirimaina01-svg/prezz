import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, ArrowRight, Banknote } from 'lucide-react';

interface SaleCompleteDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  totalAmount: number;
  amountReceived: number;
  paymentMethod: string;
  onNextCustomer: () => void;
}

export const SaleCompleteDialog: React.FC<SaleCompleteDialogProps> = ({
  open,
  onOpenChange,
  totalAmount,
  amountReceived,
  paymentMethod,
  onNextCustomer,
}) => {
  const balance = amountReceived - totalAmount;

  const handleNextCustomer = () => {
    onNextCustomer();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Sale Completed Successfully
          </DialogTitle>
          <DialogDescription>
            Transaction has been processed
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="p-4 bg-muted rounded-lg space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Total Amount:</span>
              <span className="font-semibold">KES {totalAmount.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Amount Received:</span>
              <span className="font-semibold">KES {amountReceived.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between items-center pt-2 border-t">
              <span className="text-sm text-muted-foreground">Payment Method:</span>
              <Badge variant="outline">{paymentMethod.toUpperCase()}</Badge>
            </div>
          </div>

          {/* Customer Change in Red Bold Tab */}
          <div className="bg-red-600 text-white p-6 rounded-lg shadow-lg">
            <div className="flex items-center justify-center gap-3 mb-2">
              <Banknote className="h-10 w-10" />
              <div className="text-center">
                <div className="text-sm font-medium mb-1 uppercase tracking-wider">Customer Change</div>
                <div className="text-4xl font-bold">
                  KES {balance.toFixed(2)}
                </div>
              </div>
            </div>
          </div>

          <Button 
            onClick={handleNextCustomer}
            className="w-full h-16 text-xl font-bold bg-blue-600 hover:bg-blue-700"
            size="lg"
          >
            <ArrowRight className="h-6 w-6 mr-2" />
            NEXT CUSTOMER
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};