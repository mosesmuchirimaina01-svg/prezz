import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Search, Save, X } from "lucide-react";

type Product = {
  id: string;
  code: string;
  name: string;
  price: number;
  stock_quantity: number;
  min_stock_level: number;
  is_active: boolean;
};

export const ProductEdit: React.FC = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [searchCode, setSearchCode] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [editForm, setEditForm] = useState({
    name: "",
    stock_quantity: 0,
    min_stock_level: 0,
  });

  const handleSearch = async () => {
    if (!searchCode.trim() || !profile?.company_id) return;

    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('company_id', profile.company_id)
        .eq('code', searchCode)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setSelectedProduct(data);
        setEditForm({
          name: data.name,
          stock_quantity: data.stock_quantity,
          min_stock_level: data.min_stock_level || 0,
        });
      } else {
        toast({
          title: "Not Found",
          description: "Product not found",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error searching product:', error);
      toast({
        title: "Error",
        description: "Failed to search product",
        variant: "destructive",
      });
    }
  };

  const handleSave = async () => {
    if (!selectedProduct) return;

    try {
      const { error } = await supabase
        .from('products')
        .update({
          name: editForm.name,
          stock_quantity: editForm.stock_quantity,
          min_stock_level: editForm.min_stock_level,
        })
        .eq('id', selectedProduct.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Product updated successfully",
      });

      // Reset
      setSelectedProduct(null);
      setSearchCode("");
      setEditForm({ name: "", stock_quantity: 0, min_stock_level: 0 });
    } catch (error) {
      console.error('Error updating product:', error);
      toast({
        title: "Error",
        description: "Failed to update product",
        variant: "destructive",
      });
    }
  };

  const handleCancel = () => {
    setSelectedProduct(null);
    setSearchCode("");
    setEditForm({ name: "", stock_quantity: 0, min_stock_level: 0 });
  };

  return (
    <div className="p-4">
      <Card>
        <CardHeader>
          <CardTitle>Edit Product</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search Section */}
          <div className="flex gap-2">
            <Input
              placeholder="Enter product code..."
              value={searchCode}
              onChange={(e) => setSearchCode(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button onClick={handleSearch}>
              <Search className="h-4 w-4" />
            </Button>
          </div>

          {/* Edit Form */}
          {selectedProduct && (
            <div className="space-y-4 border-t pt-4">
              <div className="grid gap-2">
                <Label>Product Code</Label>
                <Input value={selectedProduct.code} disabled />
              </div>

              <div className="grid gap-2">
                <Label>Product Name</Label>
                <Input
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                />
              </div>

              <div className="grid gap-2">
                <Label>Stock Quantity</Label>
                <Input
                  type="number"
                  value={editForm.stock_quantity}
                  onChange={(e) => setEditForm({ ...editForm, stock_quantity: parseInt(e.target.value) || 0 })}
                />
              </div>

              <div className="grid gap-2">
                <Label>Minimum Stock Level</Label>
                <Input
                  type="number"
                  value={editForm.min_stock_level}
                  onChange={(e) => setEditForm({ ...editForm, min_stock_level: parseInt(e.target.value) || 0 })}
                />
              </div>

              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={handleCancel}>
                  <X className="h-4 w-4 mr-1" />
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  <Save className="h-4 w-4 mr-1" />
                  Save Changes
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
