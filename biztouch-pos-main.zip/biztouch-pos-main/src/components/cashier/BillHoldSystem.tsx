import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Clock, Pause, Play, Eye } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { SupervisorPasswordDialog } from "@/components/SupervisorPasswordDialog";

interface HeldBill {
  id: string;
  bill_number: string;
  customer_name?: string;
  total_amount?: number;
  total?: number;
  items_count?: number;
  items?: any[];
  hold_reason: string;
  held_at: string;
  held_by: string;
  cashier?: { full_name: string };
}

interface BillHoldSystemProps {
  currentBill?: any;
  heldBills?: any[];
  onHoldBill?: (reason: string) => void;
  onUnholdBill?: (bill: any) => void;
}

export const BillHoldSystem: React.FC<BillHoldSystemProps> = ({
  currentBill,
  heldBills = [],
  onHoldBill,
  onUnholdBill
}) => {
  const [isHoldDialogOpen, setIsHoldDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedBill, setSelectedBill] = useState<HeldBill | null>(null);
  const [holdReason, setHoldReason] = useState("");
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [pendingAction, setPendingAction] = useState<"hold" | "unhold" | null>(null);
  const { toast } = useToast();

  const handleHoldBill = async () => {
    if (!currentBill || !holdReason.trim()) return;
    
    setPendingAction("hold");
    setShowPasswordDialog(true);
  };

  const handleUnholdBill = async (bill: HeldBill) => {
    setSelectedBill(bill);
    setPendingAction("unhold");
    setShowPasswordDialog(true);
  };

  const onPasswordVerified = async () => {
    try {
      if (pendingAction === "hold" && currentBill) {
        onHoldBill?.(holdReason);
        setIsHoldDialogOpen(false);
        setHoldReason("");
        
      } else if (pendingAction === "unhold" && selectedBill) {
        onUnholdBill?.(selectedBill);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${pendingAction} bill`,
        variant: "destructive",
      });
    } finally {
      setShowPasswordDialog(false);
      setPendingAction(null);
      setSelectedBill(null);
    }
  };

  const viewBillDetails = (bill: HeldBill) => {
    setSelectedBill(bill);
    setIsViewDialogOpen(true);
  };

  return (
    <div>
      <Card className="flex-1 overflow-hidden">
        <CardHeader className="p-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xs">Bill Hold System</CardTitle>
            <div className="flex gap-1">
              {currentBill && currentBill.items?.length > 0 && (
                <Dialog open={isHoldDialogOpen} onOpenChange={setIsHoldDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="text-xs h-5 px-2">
                      <Pause className="h-2 w-2 mr-1" />
                      Hold
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm">
                    <DialogHeader>
                      <DialogTitle className="text-sm">Hold Current Bill</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-3">
                      <div>
                        <Label className="text-xs">Reason for holding bill</Label>
                        <Textarea
                          placeholder="Enter reason..."
                          value={holdReason}
                          onChange={(e) => setHoldReason(e.target.value)}
                          className="text-xs min-h-16"
                          required
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => setIsHoldDialogOpen(false)} className="flex-1 text-xs h-6">
                          Cancel
                        </Button>
                        <Button size="sm" onClick={handleHoldBill} disabled={!holdReason.trim()} className="flex-1 text-xs h-6">
                          Hold Bill
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
              <Badge variant="outline" className="text-xs">{heldBills.length} Held</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-2 overflow-hidden">
          <div className="overflow-auto h-full space-y-1">
            {heldBills.length === 0 ? (
              <div className="text-center text-xs text-muted-foreground py-4">
                No bills currently held
              </div>
            ) : (
              heldBills.slice(0, 5).map((bill) => (
                <div key={bill.id} className="flex items-center justify-between p-1 bg-muted/50 rounded text-xs">
                  <div className="flex-1">
                    <div className="font-medium">{bill.bill_number}</div>
                    <div className="text-muted-foreground">KES {bill.total?.toFixed(2) || '0.00'} • {bill.items?.length || 0} items</div>
                    <div className="text-muted-foreground truncate text-xs">{bill.hold_reason}</div>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => viewBillDetails(bill)}
                      className="h-4 text-xs p-0 w-6"
                    >
                      <Eye className="h-2 w-2" />
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleUnholdBill(bill)}
                      className="h-4 text-xs px-1"
                    >
                      Unhold
                    </Button>
                  </div>
                </div>
              ))
            )}
            {heldBills.length > 5 && (
              <div className="text-center">
                <Button size="sm" variant="outline" className="text-xs h-5">
                  View All ({heldBills.length})
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* View Bill Details Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Bill Details - {selectedBill?.bill_number}</DialogTitle>
          </DialogHeader>
          {selectedBill && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Customer</Label>
                  <p>{selectedBill.customer_name || "Walk-in Customer"}</p>
                </div>
                <div>
                  <Label>Total Amount</Label>
                  <p>KES {(selectedBill.total_amount || selectedBill.total || 0).toFixed(2)}</p>
                </div>
                <div>
                  <Label>Held At</Label>
                  <p>{new Date(selectedBill.held_at).toLocaleString()}</p>
                </div>
                <div>
                  <Label>Held By</Label>
                  <p>{selectedBill.cashier?.full_name || "Current User"}</p>
                </div>
              </div>
              <div>
                <Label>Hold Reason</Label>
                <p className="mt-1 p-2 bg-gray-50 rounded">{selectedBill.hold_reason}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Supervisor Password Dialog */}
      <SupervisorPasswordDialog
        open={showPasswordDialog}
        onOpenChange={(open) => {
          setShowPasswordDialog(open);
          if (!open) {
            setPendingAction(null);
            setSelectedBill(null);
          }
        }}
        onSuccess={onPasswordVerified}
        action={pendingAction === "hold" ? "Hold Bill" : "Unhold Bill"}
      />
    </div>
  );
};