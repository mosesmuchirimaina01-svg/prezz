import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Banknote, FileText, TrendingUp, TrendingDown, DollarSign } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

interface EODData {
  totalCashSales: number;
  totalMpesaSales: number;
  totalBankSales: number;
  totalSales: number;
  totalExpenses: number;
  cashInHand: number;
  excess: number;
  shortage: number;
  salesCount: number;
  expenses: any[];
  sales: any[];
}

export const EODManagement: React.FC = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [cashInHand, setCashInHand] = useState<string>("");
  const [eodData, setEodData] = useState<EODData | null>(null);
  const [showZReport, setShowZReport] = useState(false);

  useEffect(() => {
    if (profile?.company_id) {
      fetchTodaysData();
    }
  }, [profile]);

  const fetchTodaysData = async () => {
    if (!profile?.company_id) return;

    setLoading(true);
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayISO = today.toISOString();

      // Fetch today's sales
      const { data: sales, error: salesError } = await supabase
        .from('sales')
        .select('*')
        .eq('company_id', profile.company_id)
        .gte('created_at', todayISO);

      if (salesError) throw salesError;

      // Fetch today's expenses
      const { data: expenses, error: expensesError } = await supabase
        .from('expenses')
        .select('*')
        .eq('company_id', profile.company_id)
        .gte('created_at', todayISO);

      if (expensesError) throw expensesError;

      // Calculate totals
      const cashSales = sales?.filter(s => s.payment_method === 'cash') || [];
      const mpesaSales = sales?.filter(s => s.payment_method === 'mpesa') || [];
      const bankSales = sales?.filter(s => s.payment_method === 'bank') || [];

      const totalCashSales = cashSales.reduce((sum, s) => sum + Number(s.total_amount), 0);
      const totalMpesaSales = mpesaSales.reduce((sum, s) => sum + Number(s.total_amount), 0);
      const totalBankSales = bankSales.reduce((sum, s) => sum + Number(s.total_amount), 0);
      const totalSales = totalCashSales + totalMpesaSales + totalBankSales;
      const totalExpenses = expenses?.reduce((sum, e) => sum + Number(e.amount), 0) || 0;

      setEodData({
        totalCashSales,
        totalMpesaSales,
        totalBankSales,
        totalSales,
        totalExpenses,
        cashInHand: 0,
        excess: 0,
        shortage: 0,
        salesCount: sales?.length || 0,
        expenses: expenses || [],
        sales: sales || []
      });
    } catch (error) {
      console.error('Error fetching EOD data:', error);
      toast({
        title: "Error",
        description: "Failed to fetch end of day data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const calculateExcessShortage = () => {
    if (!eodData || !cashInHand) return;

    const expectedCash = eodData.totalCashSales - eodData.totalExpenses;
    const actualCash = parseFloat(cashInHand);
    const difference = actualCash - expectedCash;

    setEodData({
      ...eodData,
      cashInHand: actualCash,
      excess: difference > 0 ? difference : 0,
      shortage: difference < 0 ? Math.abs(difference) : 0
    });
  };

  const handleGenerateZReport = () => {
    if (!cashInHand) {
      toast({
        title: "Cash Amount Required",
        description: "Please enter the actual cash in hand",
        variant: "destructive",
      });
      return;
    }
    calculateExcessShortage();
    setShowZReport(true);
  };

  const printZReport = () => {
    window.print();
  };

  if (loading) {
    return <div className="flex items-center justify-center p-8">Loading EOD data...</div>;
  }

  return (
    <div className="space-y-4 p-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">End of Day Management</h2>
        <Badge variant="outline" className="text-lg">
          {new Date().toLocaleDateString()}
        </Badge>
      </div>

      {!showZReport ? (
        <>
          {/* Sales Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Banknote className="h-4 w-4" />
                  Cash Sales
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  KES {eodData?.totalCashSales.toFixed(2) || '0.00'}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  M-Pesa Sales
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  KES {eodData?.totalMpesaSales.toFixed(2) || '0.00'}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Bank Sales
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">
                  KES {eodData?.totalBankSales.toFixed(2) || '0.00'}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <TrendingDown className="h-4 w-4" />
                  Total Expenses
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">
                  KES {eodData?.totalExpenses.toFixed(2) || '0.00'}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Cash Reconciliation */}
          <Card>
            <CardHeader>
              <CardTitle>Cash Reconciliation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Expected Cash (Cash Sales - Expenses)</Label>
                  <div className="text-2xl font-bold mt-2">
                    KES {((eodData?.totalCashSales || 0) - (eodData?.totalExpenses || 0)).toFixed(2)}
                  </div>
                </div>
                <div>
                  <Label htmlFor="cashInHand">Actual Cash in Hand</Label>
                  <Input
                    id="cashInHand"
                    type="number"
                    step="0.01"
                    value={cashInHand}
                    onChange={(e) => setCashInHand(e.target.value)}
                    placeholder="0.00"
                    className="mt-2"
                  />
                </div>
              </div>

              <Button 
                onClick={handleGenerateZReport} 
                className="w-full"
                disabled={!cashInHand}
              >
                Generate Z Report
              </Button>
            </CardContent>
          </Card>

          {/* Expenses List */}
          <Card>
            <CardHeader>
              <CardTitle>Today's Expenses ({eodData?.expenses.length || 0})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {eodData?.expenses.map((expense) => (
                  <div key={expense.id} className="flex justify-between items-center p-2 bg-muted/50 rounded">
                    <div>
                      <div className="font-medium">{expense.reason}</div>
                      <div className="text-sm text-muted-foreground">
                        {new Date(expense.created_at).toLocaleTimeString()}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">KES {Number(expense.amount).toFixed(2)}</div>
                    </div>
                  </div>
                ))}
                {(!eodData?.expenses || eodData.expenses.length === 0) && (
                  <div className="text-center text-muted-foreground py-4">
                    No expenses recorded today
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        // Z Report View
        <div className="space-y-4 print:p-8">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-3xl">Z REPORT</CardTitle>
              <div className="text-muted-foreground">
                {new Date().toLocaleDateString()} - {new Date().toLocaleTimeString()}
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <Separator />
              
              {/* Sales Summary */}
              <div>
                <h3 className="font-bold text-xl mb-4">SALES SUMMARY</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Sales Count:</span>
                    <span className="font-bold">{eodData?.salesCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cash Sales:</span>
                    <span className="font-bold">KES {eodData?.totalCashSales.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>M-Pesa Sales:</span>
                    <span className="font-bold">KES {eodData?.totalMpesaSales.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Bank Sales:</span>
                    <span className="font-bold">KES {eodData?.totalBankSales.toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg font-bold">
                    <span>TOTAL SALES:</span>
                    <span>KES {eodData?.totalSales.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Expenses */}
              <div>
                <h3 className="font-bold text-xl mb-4">EXPENSES</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Expenses:</span>
                    <span className="font-bold text-red-600">KES {eodData?.totalExpenses.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Cash Reconciliation */}
              <div>
                <h3 className="font-bold text-xl mb-4">CASH RECONCILIATION</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Expected Cash:</span>
                    <span className="font-bold">
                      KES {((eodData?.totalCashSales || 0) - (eodData?.totalExpenses || 0)).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Actual Cash:</span>
                    <span className="font-bold">KES {eodData?.cashInHand.toFixed(2)}</span>
                  </div>
                  <Separator />
                  {eodData && eodData.excess > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4" />
                        Excess:
                      </span>
                      <span className="font-bold">KES {eodData.excess.toFixed(2)}</span>
                    </div>
                  )}
                  {eodData && eodData.shortage > 0 && (
                    <div className="flex justify-between text-red-600">
                      <span className="flex items-center gap-2">
                        <TrendingDown className="h-4 w-4" />
                        Shortage:
                      </span>
                      <span className="font-bold">KES {eodData.shortage.toFixed(2)}</span>
                    </div>
                  )}
                </div>
              </div>

              <Separator />

              {/* Receipt Numbers Range */}
              <div>
                <h3 className="font-bold text-xl mb-4">RECEIPT DETAILS</h3>
                <div className="space-y-2">
                  {eodData?.sales && eodData.sales.length > 0 && (
                    <>
                      <div className="flex justify-between">
                        <span>First Receipt:</span>
                        <span className="font-bold">
                          {eodData.sales[0]?.id.substring(0, 8)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Last Receipt:</span>
                        <span className="font-bold">
                          {eodData.sales[eodData.sales.length - 1]?.id.substring(0, 8)}
                        </span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              <Separator />

              {/* Footer */}
              <div className="text-center text-sm text-muted-foreground">
                <p>Cashier: {profile?.full_name}</p>
                <p>Generated by GB PAWA POS System</p>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-2 print:hidden">
            <Button onClick={() => setShowZReport(false)} variant="outline" className="flex-1">
              Back to EOD
            </Button>
            <Button onClick={printZReport} className="flex-1">
              Print Z Report
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
