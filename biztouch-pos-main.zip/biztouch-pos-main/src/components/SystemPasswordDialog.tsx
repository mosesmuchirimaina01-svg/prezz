import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface SystemPasswordDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  action?: string;
}

export const SystemPasswordDialog: React.FC<SystemPasswordDialogProps> = ({
  open,
  onOpenChange,
  onSuccess,
  action = "access system functions"
}) => {
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Verify password - using default password for now
      // In production, this would verify against the hashed password in database
      const isValid = password === '28132813';

      if (isValid) {
        toast({
          title: "System Access Granted",
          description: `You can now ${action.toLowerCase()}.`,
        });
        onSuccess();
        onOpenChange(false);
        setPassword('');
      } else {
        toast({
          title: "Access Denied",
          description: "Invalid system password.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error verifying system password:', error);
      toast({
        title: "Error",
        description: "Failed to verify system password.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>System Authorization Required</DialogTitle>
          <DialogDescription>
            Please enter the system password to {action.toLowerCase()}.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="system-password">System Password</Label>
            <Input
              id="system-password"
              type="password"
              placeholder="Enter system password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          
          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Verifying..." : "Authorize"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};