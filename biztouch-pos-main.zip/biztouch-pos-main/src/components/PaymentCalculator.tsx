import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface PaymentCalculatorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  total: number;
  onPayment: (method: 'cash' | 'mpesa' | 'bank', amountReceived: number) => void;
  defaultMethod?: 'cash' | 'mpesa' | 'bank';
}

export const PaymentCalculator: React.FC<PaymentCalculatorProps> = ({
  open,
  onOpenChange,
  total,
  onPayment,
  defaultMethod = 'cash'
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'mpesa' | 'bank'>(defaultMethod);
  const [amountReceived, setAmountReceived] = useState('');

  // Update payment method when defaultMethod changes
  React.useEffect(() => {
    setPaymentMethod(defaultMethod);
  }, [defaultMethod]);

  const balance = parseFloat(amountReceived) - total;
  const isValidPayment = parseFloat(amountReceived) >= total;

  const handlePayment = () => {
    if (isValidPayment) {
      onPayment(paymentMethod, parseFloat(amountReceived));
      onOpenChange(false);
      setAmountReceived('');
    }
  };

  const quickAmounts = [total, total + 50, total + 100, total + 500];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Process Payment</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <Card>
            <CardContent className="pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold">Total: KES {total.toFixed(2)}</div>
              </div>
            </CardContent>
          </Card>

          <div>
            <Label>Payment Method</Label>
            <div className="flex gap-2 mt-2">
              {(['cash', 'mpesa', 'bank'] as const).map((method) => (
                <Button
                  key={method}
                  variant={paymentMethod === method ? 'default' : 'outline'}
                  onClick={() => setPaymentMethod(method)}
                  className="flex-1"
                >
                  {method.toUpperCase()}
                </Button>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="amount-received">Amount Received</Label>
            <Input
              id="amount-received"
              type="number"
              step="0.01"
              value={amountReceived}
              onChange={(e) => setAmountReceived(e.target.value)}
              placeholder="Enter amount received"
            />
          </div>

          {paymentMethod === 'cash' && (
            <div>
              <Label>Quick Amounts</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {quickAmounts.map((amount) => (
                  <Button
                    key={amount}
                    variant="outline"
                    size="sm"
                    onClick={() => setAmountReceived(amount.toString())}
                  >
                    KES {amount.toFixed(0)}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {amountReceived && (
            <Card>
              <CardContent className="pt-4">
                <div className="flex justify-between items-center">
                  <span>Balance to Give:</span>
                  <div className="text-right">
                    {balance >= 0 ? (
                      <Badge variant="default" className="text-lg">
                        KES {balance.toFixed(2)}
                      </Badge>
                    ) : (
                      <Badge variant="destructive" className="text-lg">
                        Short: KES {Math.abs(balance).toFixed(2)}
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="flex gap-2">
            <Button 
              onClick={handlePayment} 
              disabled={!isValidPayment}
              className="flex-1"
            >
              Complete Payment
            </Button>
            <Button 
              variant="outline" 
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};