import React from "react";
import { Button } from "@/components/ui/button";

const isStandalone = () =>
  (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) ||
  (window.navigator as any).standalone === true;

const isIOSSafari = () => {
  const ua = navigator.userAgent;
  const ios = /iphone|ipad|ipod/i.test(ua);
  const safari = /safari/i.test(ua) && !/crios|fxios|edgios|chrome|android/i.test(ua);
  return ios && safari;
};

const PWAInstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = React.useState<any>(null);
  const [visible, setVisible] = React.useState(false);
  const [iosTip, setIosTip] = React.useState(false);

  React.useEffect(() => {
    if (isStandalone()) return; // already installed

    const onBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setVisible(true);
    };
    window.addEventListener("beforeinstallprompt", onBeforeInstall);

    // iOS Safari fallback (no beforeinstallprompt)
    if (isIOSSafari()) {
      const t = setTimeout(() => setIosTip(true), 1200);
      return () => {
        window.removeEventListener("beforeinstallprompt", onBeforeInstall);
        clearTimeout(t);
      };
    }

    return () => window.removeEventListener("beforeinstallprompt", onBeforeInstall);
  }, []);

  const onInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    setDeferredPrompt(null);
    setVisible(false);
  };

  if (!visible && !iosTip) return null;

  return (
    <aside className="fixed inset-x-0 bottom-0 z-50 mx-auto mb-4 w-[min(680px,95%)] rounded-md border bg-card p-3 shadow-lg">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-medium">Install GB PAWA POS</p>
          {visible ? (
            <p className="text-xs text-muted-foreground">Add to your home screen for a faster, offline-ready experience.</p>
          ) : (
            <p className="text-xs text-muted-foreground">On iPhone/iPad: tap the Share icon, then "Add to Home Screen".</p>
          )}
        </div>
        <div className="flex gap-2">
          {visible ? (
            <Button size="sm" variant="ghost" onClick={() => setVisible(false)}>Later</Button>
          ) : (
            <Button size="sm" variant="ghost" onClick={() => setIosTip(false)}>Got it</Button>
          )}
          {visible && <Button onClick={onInstall}>Install</Button>}
        </div>
      </div>
    </aside>
  );
};

export default PWAInstallPrompt;
