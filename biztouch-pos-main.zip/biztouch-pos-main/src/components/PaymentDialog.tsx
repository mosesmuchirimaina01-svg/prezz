import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';

interface PaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  totalAmount: number;
  onPayment: (paymentMethod: 'cash' | 'mpesa' | 'bank', amountReceived: number) => void;
}

export const PaymentDialog: React.FC<PaymentDialogProps> = ({
  open,
  onOpenChange,
  totalAmount,
  onPayment
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'mpesa' | 'bank'>('cash');
  const [amountReceived, setAmountReceived] = useState(totalAmount.toString());
  
  const change = parseFloat(amountReceived) - totalAmount;

  const handlePayment = () => {
    onPayment(paymentMethod, parseFloat(amountReceived));
    onOpenChange(false);
    setAmountReceived(totalAmount.toString());
  };

  const quickAmounts = [
    { label: 'Exact', value: totalAmount },
    { label: '50', value: 50 },
    { label: '100', value: 100 },
    { label: '200', value: 200 },
    { label: '500', value: 500 },
    { label: '1000', value: 1000 },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Process Payment</DialogTitle>
          <DialogDescription>
            Complete the payment for this transaction.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Total Amount</p>
                <p className="text-3xl font-bold">KES {totalAmount.toFixed(2)}</p>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-2">
            <Label htmlFor="payment-method">Payment Method</Label>
            <Select value={paymentMethod} onValueChange={(value) => setPaymentMethod(value as any)}>
              <SelectTrigger>
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">Cash</SelectItem>
                <SelectItem value="mpesa">M-Pesa</SelectItem>
                <SelectItem value="bank">Bank Transfer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {paymentMethod === 'cash' && (
            <>
              <div className="space-y-2">
                <Label htmlFor="amount-received">Amount Received</Label>
                <Input
                  id="amount-received"
                  type="number"
                  step="0.01"
                  value={amountReceived}
                  onChange={(e) => setAmountReceived(e.target.value)}
                  min={totalAmount}
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                {quickAmounts.map((amount) => (
                  <Button
                    key={amount.label}
                    variant="outline"
                    size="sm"
                    onClick={() => setAmountReceived(amount.value.toString())}
                  >
                    {amount.label}
                  </Button>
                ))}
              </div>

              {change >= 0 && (
                <Card>
                  <CardContent className="pt-4">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground">Change</p>
                      <p className="text-xl font-semibold text-green-600">
                        KES {change.toFixed(2)}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}

          {(paymentMethod === 'mpesa' || paymentMethod === 'bank') && (
            <div className="text-center p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                {paymentMethod === 'mpesa' 
                  ? 'Customer will pay via M-Pesa'
                  : 'Customer will pay via bank transfer'
                }
              </p>
              <p className="font-semibold">KES {totalAmount.toFixed(2)}</p>
            </div>
          )}

          <div className="flex justify-end space-x-2">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handlePayment}
              disabled={paymentMethod === 'cash' && parseFloat(amountReceived) < totalAmount}
            >
              Complete Payment
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};