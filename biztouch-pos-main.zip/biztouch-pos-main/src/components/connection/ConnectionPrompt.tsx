import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building2, Database, Calendar, Lock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface ConnectionPromptProps {
  onConnectionSuccess: () => void;
}

export const ConnectionPrompt: React.FC<ConnectionPromptProps> = ({ onConnectionSuccess }) => {
  const [selectedCompanyId, setSelectedCompanyId] = useState('');
  const [systemPassword, setSystemPassword] = useState('');
  const [connectionDate, setConnectionDate] = useState(new Date().toISOString().split('T')[0]);
  const [isConnecting, setIsConnecting] = useState(false);
  const { companies, fetchCompanies, selectCompany } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    fetchCompanies();
  }, []);

  const handleConnect = async () => {
    if (!selectedCompanyId) {
      toast({
        title: "Company Required",
        description: "Please select a company to connect to.",
        variant: "destructive",
      });
      return;
    }

    if (systemPassword !== '28132813') {
      toast({
        title: "Invalid Password",
        description: "System admin password is incorrect.",
        variant: "destructive",
      });
      return;
    }

    setIsConnecting(true);

    try {
      const selectedCompany = companies.find(c => c.id === selectedCompanyId);
      if (selectedCompany) {
        selectCompany(selectedCompany);
        
        // Store connection metadata
        localStorage.setItem('connectionDate', connectionDate);
        localStorage.setItem('connectionTime', new Date().toISOString());
        
        toast({
          title: "Connected Successfully",
          description: `Connected to ${selectedCompany.name}`,
        });
        
        onConnectionSuccess();
      }
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: "Failed to connect to the selected company.",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const selectedCompany = companies.find(c => c.id === selectedCompanyId);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold flex items-center justify-center gap-2">
            <Database className="h-6 w-6" />
            Database Connection
          </CardTitle>
          <CardDescription>
            Connect to your company database to continue
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="company">Select Company</Label>
            <Select value={selectedCompanyId} onValueChange={setSelectedCompanyId}>
              <SelectTrigger id="company">
                <SelectValue placeholder="Choose a company..." />
              </SelectTrigger>
              <SelectContent>
                {companies.map((company) => (
                  <SelectItem key={company.id} value={company.id}>
                    <div className="flex items-center gap-2">
                      <Building2 className="h-4 w-4" />
                      {company.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedCompany && (
              <div className="text-xs text-muted-foreground mt-1 p-2 bg-muted rounded">
                <div className="flex items-center gap-1">
                  <Database className="h-3 w-3" />
                  Database: {selectedCompany.database_name}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="systemPassword">System Admin Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="systemPassword"
                type="password"
                placeholder="Enter system admin password"
                value={systemPassword}
                onChange={(e) => setSystemPassword(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="connectionDate">Connection Date</Label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="connectionDate"
                type="date"
                value={connectionDate}
                onChange={(e) => setConnectionDate(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <Button 
            onClick={handleConnect} 
            className="w-full" 
            disabled={isConnecting || !selectedCompanyId}
          >
            {isConnecting ? "Connecting..." : "Connect to Database"}
          </Button>

          {companies.length === 0 && (
            <div className="text-center text-sm text-muted-foreground p-4 bg-muted rounded">
              No companies available. Please contact your system administrator.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};