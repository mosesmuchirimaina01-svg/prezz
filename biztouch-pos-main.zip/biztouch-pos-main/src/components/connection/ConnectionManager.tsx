import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Building2, Database, Unplug, Clock, Calendar } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';

export const ConnectionManager: React.FC = () => {
  const { selectedCompany, selectCompany } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const connectionDate = localStorage.getItem('connectionDate');
  const connectionTime = localStorage.getItem('connectionTime');

  const handleDisconnect = () => {
    if (window.confirm('Are you sure you want to disconnect from the current company? You will need to reconnect to continue.')) {
      selectCompany(null as any);
      localStorage.removeItem('connectionDate');
      localStorage.removeItem('connectionTime');
      sessionStorage.clear();
      
      toast({
        title: "Disconnected",
        description: "You have been disconnected from the company database.",
      });

      navigate('/');
    }
  };

  const handleReconnect = () => {
    selectCompany(null as any);
    localStorage.removeItem('connectionDate');
    localStorage.removeItem('connectionTime');
    sessionStorage.clear();
    
    toast({
      title: "Ready to Reconnect",
      description: "Please select a company to connect to.",
    });

    navigate('/');
    window.location.reload();
  };

  if (!selectedCompany) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p className="text-muted-foreground">No active connection. Please connect to a company database.</p>
          <Button onClick={handleReconnect} className="mt-4">
            Connect to Database
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Connection Management</h2>
        <p className="text-sm text-muted-foreground">Manage your database connection</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Current Connection</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-primary" />
                <span className="font-semibold text-lg">{selectedCompany.name}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Database className="h-4 w-4" />
                <code className="bg-background px-2 py-1 rounded">
                  {selectedCompany.database_name}
                </code>
              </div>
            </div>
            <Badge variant={selectedCompany.status === 'active' ? 'default' : 'destructive'}>
              {selectedCompany.status}
            </Badge>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {connectionDate && (
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Calendar className="h-4 w-4" />
                  Connection Date
                </div>
                <div className="font-medium">{new Date(connectionDate).toLocaleDateString()}</div>
              </div>
            )}
            
            {connectionTime && (
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Clock className="h-4 w-4" />
                  Connected At
                </div>
                <div className="font-medium">{new Date(connectionTime).toLocaleTimeString()}</div>
              </div>
            )}
          </div>

          <div className="flex gap-2 pt-4 border-t">
            <Button 
              variant="destructive" 
              onClick={handleDisconnect}
              className="flex-1"
            >
              <Unplug className="h-4 w-4 mr-2" />
              Disconnect
            </Button>
            <Button 
              variant="outline" 
              onClick={handleReconnect}
              className="flex-1"
            >
              Switch Company
            </Button>
          </div>

          <div className="text-xs text-muted-foreground text-center p-3 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded">
            <strong>Note:</strong> Disconnecting will log you out of all modules. You will need to reconnect and log in again.
          </div>
        </CardContent>
      </Card>
    </div>
  );
};