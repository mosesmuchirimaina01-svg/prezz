import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Edit, TrendingUp, TrendingDown, DollarSign, Package } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useUserPermissions } from '@/hooks/useUserPermissions';
import { supabase } from '@/integrations/supabase/client';

interface Product {
  id: string;
  code: string;
  name: string;
  current_price: number;
  cost_price: number;
  profit_margin: number;
  stock_quantity: number;
  category: string;
  last_price_change: string;
}

export const PriceChangeManagement: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showDialog, setShowDialog] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [newPrice, setNewPrice] = useState(0);
  const [priceChangeReason, setPriceChangeReason] = useState('');
  const [minimumProfitMargin, setMinimumProfitMargin] = useState(20); // Default 20%
  const { toast } = useToast();
  const permissions = useUserPermissions();

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('id, code, name, price, cost_price, stock_quantity')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      
      const formattedProducts: Product[] = (data || []).map(p => ({
        id: p.id,
        code: p.code,
        name: p.name,
        current_price: p.price,
        cost_price: p.cost_price || 0,
        profit_margin: p.cost_price ? ((p.price - p.cost_price) / p.cost_price) * 100 : 0,
        stock_quantity: p.stock_quantity,
        category: 'General',
        last_price_change: new Date().toISOString().split('T')[0],
      }));
      
      setProducts(formattedProducts);
      setFilteredProducts(formattedProducts);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch products",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    // Filter products based on search query
    const filtered = products.filter(product =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.code.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredProducts(filtered);
  }, [searchQuery, products]);

  const calculateNewProfitMargin = (costPrice: number, sellingPrice: number) => {
    if (costPrice === 0) return 0;
    return ((sellingPrice - costPrice) / costPrice) * 100;
  };

  const getMinimumSellingPrice = (costPrice: number) => {
    return costPrice * (1 + minimumProfitMargin / 100);
  };

  const handlePriceChange = (product: Product) => {
    if (!permissions.canChangePrices) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to change prices",
        variant: "destructive",
      });
      return;
    }

    setSelectedProduct(product);
    setNewPrice(product.current_price);
    setPriceChangeReason('');
    setShowDialog(true);
  };

  const handleSubmitPriceChange = async () => {
    if (!selectedProduct) return;

    const minimumPrice = getMinimumSellingPrice(selectedProduct.cost_price);
    
    if (newPrice < minimumPrice) {
      toast({
        title: "Price Below Minimum",
        description: `Price cannot be below minimum selling price of $${minimumPrice.toFixed(2)} (${minimumProfitMargin}% profit margin)`,
        variant: "destructive",
      });
      return;
    }

    if (!priceChangeReason.trim()) {
      toast({
        title: "Reason Required",
        description: "Please provide a reason for the price change",
        variant: "destructive",
      });
      return;
    }

    try {
      // Update product price
      const updatedProduct = {
        ...selectedProduct,
        current_price: newPrice,
        profit_margin: calculateNewProfitMargin(selectedProduct.cost_price, newPrice),
        last_price_change: new Date().toISOString().split('T')[0],
      };

      setProducts(prev => prev.map(product => 
        product.id === selectedProduct.id ? updatedProduct : product
      ));

      toast({
        title: "Price Updated",
        description: `Price for ${selectedProduct.name} updated successfully`,
      });

      setShowDialog(false);
      setSelectedProduct(null);
      setNewPrice(0);
      setPriceChangeReason('');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update price",
        variant: "destructive",
      });
    }
  };

  const getProfitMarginBadge = (margin: number) => {
    if (margin >= 40) {
      return <Badge className="bg-green-100 text-green-800">High ({margin.toFixed(1)}%)</Badge>;
    } else if (margin >= 20) {
      return <Badge className="bg-yellow-100 text-yellow-800">Normal ({margin.toFixed(1)}%)</Badge>;
    } else {
      return <Badge variant="destructive">Low ({margin.toFixed(1)}%)</Badge>;
    }
  };

  if (!permissions.canChangePrices) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p className="text-muted-foreground">You don't have permission to manage prices.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Price Management</h2>
          <p className="text-sm text-muted-foreground">Manage product prices and profit margins</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Label htmlFor="margin" className="text-sm">Min Profit %:</Label>
            <Input
              id="margin"
              type="number"
              value={minimumProfitMargin}
              onChange={(e) => setMinimumProfitMargin(Number(e.target.value))}
              className="w-20"
              min="0"
              max="100"
            />
          </div>
        </div>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search products by name or code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Package className="h-4 w-4" />
              Total Products
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{products.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-green-600" />
              High Margin
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {products.filter(p => p.profit_margin >= 40).length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingDown className="h-4 w-4 text-red-600" />
              Low Margin
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {products.filter(p => p.profit_margin < 20).length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Avg Margin
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {products.length > 0 ? (products.reduce((sum, p) => sum + p.profit_margin, 0) / products.length).toFixed(1) : 0}%
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle>Product Prices</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead>Cost Price</TableHead>
                <TableHead>Selling Price</TableHead>
                <TableHead>Profit Margin</TableHead>
                <TableHead>Stock</TableHead>
                <TableHead>Last Changed</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.map((product) => (
                <TableRow key={product.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{product.name}</div>
                      <div className="text-sm text-muted-foreground">{product.code} • {product.category}</div>
                    </div>
                  </TableCell>
                  <TableCell>${product.cost_price.toFixed(2)}</TableCell>
                  <TableCell className="font-medium">${product.current_price.toFixed(2)}</TableCell>
                  <TableCell>{getProfitMarginBadge(product.profit_margin)}</TableCell>
                  <TableCell>
                    <Badge variant={product.stock_quantity > 10 ? "default" : "destructive"}>
                      {product.stock_quantity}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {product.last_price_change}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handlePriceChange(product)}
                    >
                      <Edit className="h-3 w-3 mr-1" />
                      Change Price
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Price Change Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Change Price - {selectedProduct?.name}</DialogTitle>
          </DialogHeader>
          
          {selectedProduct && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm text-muted-foreground">Current Price</Label>
                  <div className="text-lg font-bold">${selectedProduct.current_price.toFixed(2)}</div>
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Cost Price</Label>
                  <div className="text-lg">${selectedProduct.cost_price.toFixed(2)}</div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="new_price">New Selling Price</Label>
                <Input
                  id="new_price"
                  type="number"
                  step="0.01"
                  value={newPrice}
                  onChange={(e) => setNewPrice(parseFloat(e.target.value) || 0)}
                  placeholder="Enter new price"
                />
                <div className="text-sm text-muted-foreground">
                  Minimum price: ${getMinimumSellingPrice(selectedProduct.cost_price).toFixed(2)} 
                  ({minimumProfitMargin}% profit margin)
                </div>
              </div>
              
              {newPrice > 0 && (
                <div className="p-3 bg-muted rounded-lg">
                  <div className="text-sm">
                    <div className="flex justify-between">
                      <span>New Profit Margin:</span>
                      <span className={`font-bold ${calculateNewProfitMargin(selectedProduct.cost_price, newPrice) >= minimumProfitMargin ? 'text-green-600' : 'text-red-600'}`}>
                        {calculateNewProfitMargin(selectedProduct.cost_price, newPrice).toFixed(2)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Profit per unit:</span>
                      <span className="font-bold">${(newPrice - selectedProduct.cost_price).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="reason">Reason for Price Change</Label>
                <Select value={priceChangeReason} onValueChange={setPriceChangeReason}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select reason" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cost_increase">Cost Increase</SelectItem>
                    <SelectItem value="market_demand">Market Demand</SelectItem>
                    <SelectItem value="competitor_pricing">Competitor Pricing</SelectItem>
                    <SelectItem value="promotion">Promotion/Discount</SelectItem>
                    <SelectItem value="margin_improvement">Margin Improvement</SelectItem>
                    <SelectItem value="seasonal_adjustment">Seasonal Adjustment</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowDialog(false)}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSubmitPriceChange}
                  disabled={newPrice <= 0 || !priceChangeReason}
                >
                  Update Price
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};