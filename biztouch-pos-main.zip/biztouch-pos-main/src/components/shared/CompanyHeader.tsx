import React from 'react';
import { Building2, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';

interface CompanyHeaderProps {
  title: string;
  showCompanyInfo?: boolean;
}

export const CompanyHeader: React.FC<CompanyHeaderProps> = ({ 
  title, 
  showCompanyInfo = true 
}) => {
  const { selectedCompany } = useAuth();

  return (
    <div className="bg-yellow-50 border-b p-2 shrink-0">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div>
            <h1 className="text-lg font-bold flex items-center gap-2">
              {title}
              {selectedCompany && showCompanyInfo && (
                <>
                  <span className="text-muted-foreground">•</span>
                  <Building2 className="h-4 w-4 text-primary" />
                  <span className="text-primary">{selectedCompany.name}</span>
                </>
              )}
            </h1>
            <p className="text-sm text-muted-foreground">
              {showCompanyInfo && selectedCompany ? (
                <>Connected to {selectedCompany.database_name} • {new Date().toLocaleDateString()}</>
              ) : (
                <>System Dashboard • {new Date().toLocaleDateString()}</>
              )}
            </p>
          </div>
        </div>
        
        {showCompanyInfo && selectedCompany && (
          <Badge variant="outline" className="text-xs">
            <Building2 className="h-3 w-3 mr-1" />
            {selectedCompany.status}
          </Badge>
        )}
      </div>
      
      {showCompanyInfo && !selectedCompany && (
        <Alert className="mt-2 bg-destructive/10 border-destructive/20">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-sm">
            No company selected. Please return to login and select a company.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
};