import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Users, Shield, Eye } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { DataTable } from "@/components/ui/data-table";
import { ActionModal } from "@/components/ui/action-modal";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface User {
  id: string;
  username: string;
  full_name: string;
  role: string;
  permissions: string[];
  is_active: boolean;
  created_at: string;
}

export const AdminUserManagement = () => {
  const { profile } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [viewingUser, setViewingUser] = useState<User | null>(null);
  const [showViewModal, setShowViewModal] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    full_name: "",
    password: "",
    confirm_password: "",
    role: "",
    permissions: [] as string[]
  });
  const { toast } = useToast();

  const availablePermissions = [
    { id: 'view_sales', label: 'View Sales' },
    { id: 'view_reports', label: 'View Reports' },
    { id: 'manage_stock', label: 'Manage Stock' },
    { id: 'delete_items', label: 'Delete Items' },
    { id: 'hold_bills', label: 'Hold Bills' },
    { id: 'manage_users', label: 'Manage Users' },
    { id: 'system_settings', label: 'System Settings' }
  ];

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const { data: profilesData, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;

      // Transform profiles data to match User interface
      const transformedUsers = profilesData?.map(profile => ({
        id: profile.id,
        username: profile.username,
        full_name: profile.full_name,
        role: profile.role,
        permissions: [], // Will be fetched separately if needed
        is_active: profile.is_active,
        created_at: profile.created_at
      })) || [];

      setUsers(transformedUsers);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({
        title: "Error",
        description: "Failed to load users",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = async () => {
    try {
      if (formData.password !== formData.confirm_password) {
        toast({
          title: "Error",
          description: "Passwords do not match",
          variant: "destructive",
        });
        return;
      }

      if (editingUser) {
        // Update existing user
        const { error } = await supabase
          .from('profiles')
          .update({
            username: formData.username,
            full_name: formData.full_name,
            role: formData.role as 'admin' | 'cashier' | 'manager' | 'supervisor'
          })
          .eq('id', editingUser.id);

        if (error) throw error;
        toast({ title: "Success", description: "User updated successfully" });
      } else {
        // Create new user profile with proper auth user creation
        if (!formData.password || formData.password.length < 6) {
          toast({
            title: "Error",
            description: "Password must be at least 6 characters",
            variant: "destructive",
          });
          return;
        }

        if (!profile?.company_id) {
          toast({
            title: "Error",
            description: "No company selected",
            variant: "destructive",
          });
          return;
        }

        // Create Supabase auth user first
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email: `${formData.username}@${profile.company_id}.local`,
          password: formData.password,
          options: {
            data: {
              username: formData.username,
              full_name: formData.full_name,
              role: formData.role,
              company_id: profile.company_id
            }
          }
        });

        if (authError) throw authError;
        if (!authData.user) throw new Error('Failed to create user');

        // Profile will be created automatically by the trigger
        // Just wait a bit for it to complete
        await new Promise(resolve => setTimeout(resolve, 1000));

        toast({ 
          title: "Success", 
          description: "User created successfully" 
        });
      }
      
      setIsDialogOpen(false);
      setEditingUser(null);
      setFormData({ username: "", full_name: "", password: "", confirm_password: "", role: "", permissions: [] });
      fetchUsers();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save user",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setFormData({
      username: user.username,
      full_name: user.full_name,
      password: "",
      confirm_password: "",
      role: user.role,
      permissions: user.permissions
    });
    setIsDialogOpen(true);
  };

  const handlePermissionChange = (permissionId: string, checked: boolean) => {
    if (checked) {
      setFormData(prev => ({
        ...prev,
        permissions: [...prev.permissions, permissionId]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        permissions: prev.permissions.filter(p => p !== permissionId)
      }));
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Users className="h-3 w-3" />
          User Management & Rights
        </h3>
        <Button 
          size="sm" 
          onClick={() => setIsDialogOpen(true)}
          className="h-6 text-xs px-2"
        >
          <Plus className="h-2 w-2 mr-1" />
          Add User
        </Button>
      </div>

      <Card className="shadow-md">
        <CardHeader className="p-2 bg-muted/30">
          <CardTitle className="text-xs">System Users</CardTitle>
        </CardHeader>
        <CardContent className="p-2">
          <DataTable
            data={users}
            columns={[
              {
                key: 'username',
                header: 'Username',
                cell: (user) => user.username,
                className: "font-medium"
              },
              {
                key: 'full_name',
                header: 'Full Name',
                cell: (user) => user.full_name
              },
              {
                key: 'role',
                header: 'Role',
                cell: (user) => (
                  <Badge variant="secondary" className="text-xs h-4 capitalize">
                    {user.role}
                  </Badge>
                ),
                className: "w-16"
              },
              {
                key: 'permissions',
                header: 'Permissions',
                cell: (user) => (
                  <div className="flex flex-wrap gap-1">
                    {user.permissions.slice(0, 2).map(permission => (
                      <Badge key={permission} variant="outline" className="text-xs h-4">
                        {permission.replace('_', ' ')}
                      </Badge>
                    ))}
                    {user.permissions.length > 2 && (
                      <span className="text-xs text-muted-foreground">+{user.permissions.length - 2}</span>
                    )}
                  </div>
                ),
                className: "w-32"
              },
              {
                key: 'is_active',
                header: 'Status',
                cell: (user) => (
                  <Badge variant={user.is_active ? "default" : "destructive"} className="text-xs h-4">
                    {user.is_active ? "Active" : "Inactive"}
                  </Badge>
                ),
                className: "w-16"
              },
              {
                key: 'actions',
                header: 'Actions',
                cell: (user) => (
                  <div className="flex gap-1">
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="h-4 w-4 p-0"
                      onClick={() => {
                        setViewingUser(user);
                        setShowViewModal(true);
                      }}
                    >
                      <Eye className="h-2 w-2" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="h-4 w-4 p-0" 
                      onClick={() => handleEdit(user)}
                    >
                      <Edit className="h-2 w-2" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="h-4 w-4 p-0 text-destructive"
                    >
                      <Trash2 className="h-2 w-2" />
                    </Button>
                  </div>
                ),
                className: "w-20"
              }
            ]}
            compact={true}
            maxHeight="300px"
            emptyMessage="No users found"
          />
        </CardContent>
      </Card>

      {/* Add/Edit User Modal */}
      <ActionModal
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        title={editingUser ? "Edit User" : "Create New User"}
        description="Manage user account and permissions"
        size="md"
        primaryAction={{
          label: editingUser ? "Update User" : "Create User",
          onClick: handleSubmit
        }}
        secondaryAction={{
          label: "Cancel",
          onClick: () => {
            setIsDialogOpen(false);
            setEditingUser(null);
            setFormData({ username: "", full_name: "", password: "", confirm_password: "", role: "", permissions: [] });
          }
        }}
      >
        <div className="space-y-3">
          <div>
            <Label htmlFor="username" className="text-xs">Username</Label>
            <Input
              id="username"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              className="text-xs h-8"
              required
            />
          </div>
          <div>
            <Label htmlFor="full_name" className="text-xs">Full Name</Label>
            <Input
              id="full_name"
              value={formData.full_name}
              onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
              className="text-xs h-8"
              required
            />
          </div>
          <div>
            <Label htmlFor="password" className="text-xs">Password</Label>
            <Input
              id="password"
              type="password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              className="text-xs h-8"
              required={!editingUser}
              placeholder={editingUser ? "Leave blank to keep current password" : ""}
            />
          </div>
          <div>
            <Label htmlFor="confirm_password" className="text-xs">Confirm Password</Label>
            <Input
              id="confirm_password"
              type="password"
              value={formData.confirm_password}
              onChange={(e) => setFormData({ ...formData, confirm_password: e.target.value })}
              className="text-xs h-8"
              required={!editingUser}
              placeholder={editingUser ? "Leave blank to keep current password" : ""}
            />
          </div>
          <div>
            <Label htmlFor="role" className="text-xs">Role</Label>
            <Select onValueChange={(value) => setFormData({ ...formData, role: value })}>
              <SelectTrigger className="text-xs h-8">
                <SelectValue placeholder="Select role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cashier">Cashier</SelectItem>
                <SelectItem value="supervisor">Supervisor</SelectItem>
                <SelectItem value="manager">Manager</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Permissions</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {availablePermissions.map((permission) => (
                <div key={permission.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={permission.id}
                    checked={formData.permissions.includes(permission.id)}
                    onCheckedChange={(checked) => handlePermissionChange(permission.id, checked as boolean)}
                  />
                  <Label htmlFor={permission.id} className="text-xs">{permission.label}</Label>
                </div>
              ))}
            </div>
          </div>
        </div>
      </ActionModal>

      {/* View User Details Modal */}
      <ActionModal
        open={showViewModal}
        onOpenChange={setShowViewModal}
        title="User Details"
        description={viewingUser ? `Details for ${viewingUser.full_name}` : ""}
        size="md"
        secondaryAction={{
          label: "Close",
          onClick: () => setShowViewModal(false)
        }}
      >
        {viewingUser && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground">Username</label>
                <p className="text-sm">{viewingUser.username}</p>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">Full Name</label>
                <p className="text-sm">{viewingUser.full_name}</p>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">Role</label>
                <p className="text-sm capitalize">{viewingUser.role}</p>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">Status</label>
                <p className="text-sm">{viewingUser.is_active ? "Active" : "Inactive"}</p>
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground">Permissions</label>
                <div className="flex flex-wrap gap-1 mt-1">
                  {viewingUser.permissions.map(permission => (
                    <Badge key={permission} variant="outline" className="text-xs">
                      {permission.replace('_', ' ')}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground">Created</label>
                <p className="text-sm">{new Date(viewingUser.created_at).toLocaleString()}</p>
              </div>
            </div>
          </div>
        )}
      </ActionModal>
    </div>
  );
};