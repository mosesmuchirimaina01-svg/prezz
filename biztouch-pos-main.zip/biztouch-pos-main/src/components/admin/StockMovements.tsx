import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TrendingUp, Search } from "lucide-react";

interface StockMovement {
  id: string;
  product_name: string;
  product_code: string;
  movement_type: string;
  quantity: number;
  reason: string;
  user_name: string;
  created_at: string;
}

export const StockMovements = () => {
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    // Mock data
    setMovements([
      {
        id: "1",
        product_name: "Product A",
        product_code: "PA001",
        movement_type: "in",
        quantity: 50,
        reason: "Purchase order received",
        user_name: "Manager",
        created_at: new Date().toISOString()
      },
      {
        id: "2",
        product_name: "Product B",
        product_code: "PB002",
        movement_type: "out",
        quantity: 5,
        reason: "Sale transaction",
        user_name: "Cashier1",
        created_at: new Date().toISOString()
      }
    ]);
  }, []);

  const filteredMovements = movements.filter(movement =>
    movement.product_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    movement.product_code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <TrendingUp className="h-4 w-4" />
          Stock Movements
        </h3>
        <div className="flex items-center gap-2">
          <Search className="h-3 w-3 text-muted-foreground" />
          <Input
            placeholder="Search movements..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-48 text-xs h-8"
          />
        </div>
      </div>

      <Card>
        <CardContent className="p-3">
          <div className="overflow-auto max-h-64">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs">Product</TableHead>
                  <TableHead className="text-xs">Code</TableHead>
                  <TableHead className="text-xs">Type</TableHead>
                  <TableHead className="text-xs">Quantity</TableHead>
                  <TableHead className="text-xs">Reason</TableHead>
                  <TableHead className="text-xs">User</TableHead>
                  <TableHead className="text-xs">Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMovements.map((movement) => (
                  <TableRow key={movement.id}>
                    <TableCell className="text-xs font-medium">{movement.product_name}</TableCell>
                    <TableCell className="text-xs font-mono">{movement.product_code}</TableCell>
                    <TableCell className="text-xs">
                      <span className={movement.movement_type === 'in' ? "text-green-600" : "text-red-600"}>
                        {movement.movement_type === 'in' ? 'IN' : 'OUT'}
                      </span>
                    </TableCell>
                    <TableCell className="text-xs">{movement.quantity}</TableCell>
                    <TableCell className="text-xs">{movement.reason}</TableCell>
                    <TableCell className="text-xs">{movement.user_name}</TableCell>
                    <TableCell className="text-xs">{new Date(movement.created_at).toLocaleDateString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};