import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Package, Plus, MinusCircle, PlusCircle, AlertTriangle, History } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface Product {
  id: string;
  name: string;
  code: string;
  stock_quantity: number;
  min_stock_level: number | null;
}

interface StockMovement {
  id: string;
  product_id: string;
  movement_type: string;
  quantity: number;
  reason: string | null;
  created_at: string;
  products?: { name: string; code: string };
}

export const StockInput: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [stockMovements, setStockMovements] = useState<StockMovement[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<string>('');
  const [movementType, setMovementType] = useState<'in' | 'out' | 'adjustment'>('in');
  const [quantity, setQuantity] = useState('');
  const [reason, setReason] = useState('');
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false);
  const { toast } = useToast();
  const { selectedCompany, profile } = useAuth();

  useEffect(() => {
    fetchProducts();
    fetchStockMovements();
  }, []);

  const fetchProducts = async () => {
    try {
      if (!selectedCompany?.id) return;

      const { data, error } = await supabase
        .from('products')
        .select('id, name, code, stock_quantity, min_stock_level')
        .eq('company_id', selectedCompany.id)
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast({
        title: "Error",
        description: "Failed to load products",
        variant: "destructive",
      });
    }
  };

  const fetchStockMovements = async () => {
    try {
      const { data, error } = await supabase
        .from('stock_movements')
        .select(`
          *,
          products(name, code)
        `)
        .order('created_at', { ascending: false })
        .limit(50);
      
      if (error) throw error;
      setStockMovements(data || []);
    } catch (error) {
      console.error('Error fetching stock movements:', error);
    }
  };

  const processStockMovement = async () => {
    if (!selectedProduct || !quantity || !reason) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const quantityNum = parseInt(quantity);
    if (quantityNum <= 0) {
      toast({
        title: "Validation Error",
        description: "Quantity must be greater than 0",
        variant: "destructive",
      });
      return;
    }

    try {
      // Get current stock
      const { data: product, error: productError } = await supabase
        .from('products')
        .select('stock_quantity')
        .eq('id', selectedProduct)
        .single();

      if (productError) throw productError;

      let newQuantity = product.stock_quantity;

      if (movementType === 'in') {
        newQuantity += quantityNum;
      } else if (movementType === 'out') {
        if (quantityNum > product.stock_quantity) {
          toast({
            title: "Insufficient Stock",
            description: "Cannot remove more stock than available",
            variant: "destructive",
          });
          return;
        }
        newQuantity -= quantityNum;
      } else if (movementType === 'adjustment') {
        newQuantity = quantityNum;
      }

      // Update product stock
      const { error: updateError } = await supabase
        .from('products')
        .update({ stock_quantity: newQuantity })
        .eq('id', selectedProduct);

      if (updateError) throw updateError;

      // Get user profile for company_id and user_id
      if (!profile?.id || !selectedCompany?.id) {
        throw new Error('No company selected or user not authenticated');
      }

      // Record stock movement
      const { error: movementError } = await supabase
        .from('stock_movements')
        .insert({
          product_id: selectedProduct,
          movement_type: movementType,
          quantity: movementType === 'adjustment' ? Math.abs(quantityNum - product.stock_quantity) : quantityNum,
          reason: reason,
          user_id: profile.user_id,
          company_id: selectedCompany.id
        });

      if (movementError) throw movementError;

      toast({
        title: "Success",
        description: "Stock updated successfully",
      });

      // Reset form
      setSelectedProduct('');
      setQuantity('');
      setReason('');
      
      // Refresh data
      fetchProducts();
      fetchStockMovements();
    } catch (error) {
      console.error('Error processing stock movement:', error);
      toast({
        title: "Error",
        description: "Failed to update stock",
        variant: "destructive",
      });
    }
  };

  const getMovementTypeColor = (type: string) => {
    switch (type) {
      case 'in': return 'bg-green-100 text-green-800';
      case 'out': return 'bg-red-100 text-red-800';
      case 'adjustment_in': return 'bg-blue-100 text-blue-800';
      case 'adjustment_out': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const lowStockProducts = products.filter(p => 
    p.min_stock_level && p.stock_quantity <= p.min_stock_level
  );

  const outOfStockProducts = products.filter(p => p.stock_quantity === 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Stock Input & Management</h2>
        <Dialog open={isHistoryDialogOpen} onOpenChange={setIsHistoryDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline">
              <History className="h-4 w-4 mr-2" />
              View History
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Stock Movement History</DialogTitle>
            </DialogHeader>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Reason</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stockMovements.map((movement) => (
                  <TableRow key={movement.id}>
                    <TableCell>
                      {new Date(movement.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{movement.products?.name}</div>
                        <div className="text-sm text-gray-500">{movement.products?.code}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getMovementTypeColor(movement.movement_type)}>
                        {movement.movement_type.replace('_', ' ').toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell>{movement.quantity}</TableCell>
                    <TableCell>{movement.reason || '-'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </DialogContent>
        </Dialog>
      </div>

      {/* Alert Cards */}
      <div className="grid gap-4 md:grid-cols-2">
        {outOfStockProducts.length > 0 && (
          <Card className="border-red-200 bg-red-50">
            <CardHeader>
              <CardTitle className="text-red-800 flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Out of Stock ({outOfStockProducts.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                {outOfStockProducts.slice(0, 3).map((product) => (
                  <div key={product.id} className="text-sm">
                    {product.name} ({product.code})
                  </div>
                ))}
                {outOfStockProducts.length > 3 && (
                  <div className="text-sm text-red-600">
                    +{outOfStockProducts.length - 3} more products
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {lowStockProducts.length > 0 && (
          <Card className="border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle className="text-orange-800 flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Low Stock ({lowStockProducts.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                {lowStockProducts.slice(0, 3).map((product) => (
                  <div key={product.id} className="text-sm">
                    {product.name}: {product.stock_quantity} / {product.min_stock_level}
                  </div>
                ))}
                {lowStockProducts.length > 3 && (
                  <div className="text-sm text-orange-600">
                    +{lowStockProducts.length - 3} more products
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Stock Input Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Process Stock Movement
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="product-select">Select Product</Label>
              <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a product..." />
                </SelectTrigger>
                <SelectContent>
                  {products.map((product) => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name} ({product.code}) - Current: {product.stock_quantity}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="movement-type">Movement Type</Label>
              <Select value={movementType} onValueChange={(value: any) => setMovementType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="in">
                    <div className="flex items-center gap-2">
                      <PlusCircle className="h-4 w-4 text-green-500" />
                      Stock In (Add)
                    </div>
                  </SelectItem>
                  <SelectItem value="out">
                    <div className="flex items-center gap-2">
                      <MinusCircle className="h-4 w-4 text-red-500" />
                      Stock Out (Remove)
                    </div>
                  </SelectItem>
                  <SelectItem value="adjustment">
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-blue-500" />
                      Stock Adjustment (Set to)
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="quantity">
                {movementType === 'adjustment' ? 'New Stock Level' : 'Quantity'}
              </Label>
              <Input
                id="quantity"
                type="number"
                min="0"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder={movementType === 'adjustment' ? 'Enter new stock level' : 'Enter quantity'}
              />
            </div>

            <div>
              <Label htmlFor="reason">Reason</Label>
              <Textarea
                id="reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Reason for stock movement..."
                rows={3}
              />
            </div>

            <Button onClick={processStockMovement} className="w-full">
              Process Stock Movement
            </Button>
          </CardContent>
        </Card>

        {/* Current Stock Levels */}
        <Card>
          <CardHeader>
            <CardTitle>Current Stock Levels</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Current Stock</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.slice(0, 10).map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{product.name}</div>
                        <div className="text-sm text-gray-500">{product.code}</div>
                      </div>
                    </TableCell>
                    <TableCell>{product.stock_quantity}</TableCell>
                    <TableCell>
                      {product.stock_quantity === 0 ? (
                        <Badge variant="destructive">Out of Stock</Badge>
                      ) : product.min_stock_level && product.stock_quantity <= product.min_stock_level ? (
                        <Badge className="bg-orange-100 text-orange-800">Low Stock</Badge>
                      ) : (
                        <Badge variant="default">In Stock</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {products.length > 10 && (
              <div className="text-center text-sm text-gray-500 mt-2">
                Showing 10 of {products.length} products
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};