import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, DollarSign, Users, Package, FileText, Download, Eye } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { DataTable } from "@/components/ui/data-table";
import { ActionModal } from "@/components/ui/action-modal";

type SaleRecord = {
  id: string;
  total_amount: number;
  payment_method: string;
  created_at: string;
  cashier_name: string;
  items_count: number;
};

type ProductPerformance = {
  product_name: string;
  quantity_sold: number;
  revenue: number;
  profit: number;
};

export const SalesReports = () => {
  const { profile } = useAuth();
  const [reportPeriod, setReportPeriod] = useState("daily");
  const [reportType, setReportType] = useState("overview");
  const [dateFrom, setDateFrom] = useState(new Date().toISOString().split('T')[0]);
  const [dateTo, setDateTo] = useState(new Date().toISOString().split('T')[0]);
  const [salesData, setSalesData] = useState<SaleRecord[]>([]);
  const [productPerformance, setProductPerformance] = useState<ProductPerformance[]>([]);
  const [loading, setLoading] = useState(false);
  const [viewingSale, setViewingSale] = useState<SaleRecord | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);

  const dailySalesData = [
    { day: 'Mon', sales: 4000, transactions: 24 },
    { day: 'Tue', sales: 3000, transactions: 18 },
    { day: 'Wed', sales: 2000, transactions: 15 },
    { day: 'Thu', sales: 2780, transactions: 21 },
    { day: 'Fri', sales: 1890, transactions: 14 },
    { day: 'Sat', sales: 2390, transactions: 17 },
    { day: 'Sun', sales: 3490, transactions: 25 },
  ];

  const paymentMethodData = [
    { name: 'Cash', value: 45, color: '#8884d8' },
    { name: 'M-Pesa', value: 35, color: '#82ca9d' },
    { name: 'Bank', value: 20, color: '#ffc658' },
  ];

  const cashierPerformance = [
    { name: 'John Doe', sales: 15000, transactions: 45, avg_transaction: 333 },
    { name: 'Jane Smith', sales: 12000, transactions: 38, avg_transaction: 316 },
    { name: 'Mike Johnson', sales: 9800, transactions: 32, avg_transaction: 306 },
  ];

  useEffect(() => {
    fetchSalesData();
  }, [reportPeriod, dateFrom, dateTo, profile]);

  const fetchSalesData = async () => {
    if (!profile) return;
    setLoading(true);
    
    try {
      let query = supabase
        .from('sales')
        .select(`
          *,
          profiles!inner(full_name)
        `)
        .gte('created_at', `${dateFrom}T00:00:00`)
        .lte('created_at', `${dateTo}T23:59:59`)
        .order('created_at', { ascending: false });

      if (profile.role === 'cashier') {
        query = query.eq('cashier_id', profile.id);
      }

      const { data, error } = await query;
      
      if (error) throw error;
      
      const transformedData = data?.map(sale => ({
        id: sale.id,
        total_amount: Number(sale.total_amount),
        payment_method: sale.payment_method,
        created_at: sale.created_at,
        cashier_name: (sale.profiles as any)?.full_name || 'Unknown',
        items_count: 0 // Would need to join with sale_items
      })) || [];
      
      setSalesData(transformedData);
    } catch (error) {
      console.error('Error fetching sales data:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalSales = salesData.reduce((sum, sale) => sum + sale.total_amount, 0);
  const totalTransactions = salesData.length;
  const avgTransaction = totalTransactions > 0 ? totalSales / totalTransactions : 0;

  const generateReport = () => {
    console.log(`Generating ${reportType} report for ${reportPeriod} period`);
  };

  const exportData = (type: string) => {
    console.log(`Exporting ${type} data`);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <TrendingUp className="h-3 w-3" />
          Sales Reports & Analytics
        </h3>
        <div className="flex gap-1">
          <Select value={reportType} onValueChange={setReportType}>
            <SelectTrigger className="w-24 text-xs h-6">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="overview">Overview</SelectItem>
              <SelectItem value="detailed">Detailed</SelectItem>
              <SelectItem value="cashier">Cashier</SelectItem>
              <SelectItem value="product">Product</SelectItem>
            </SelectContent>
          </Select>
          <Input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="w-24 text-xs h-6"
          />
          <Input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className="w-24 text-xs h-6"
          />
          <Button size="sm" onClick={generateReport} className="h-6 text-xs px-2">
            <FileText className="h-2 w-2 mr-1" />
            Generate
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-2">
        <Card>
          <CardContent className="p-2">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Total Sales</p>
                <p className="text-sm font-bold">KES {totalSales.toLocaleString()}</p>
              </div>
              <DollarSign className="h-4 w-4 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Transactions</p>
                <p className="text-sm font-bold">{totalTransactions}</p>
              </div>
              <Package className="h-4 w-4 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Avg Transaction</p>
                <p className="text-sm font-bold">KES {avgTransaction.toFixed(0)}</p>
              </div>
              <TrendingUp className="h-4 w-4 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Growth</p>
                <p className="text-sm font-bold text-green-600">+12.5%</p>
              </div>
              <TrendingUp className="h-4 w-4 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {/* Sales Chart */}
        <Card>
          <CardHeader className="p-2">
            <CardTitle className="text-xs">Daily Sales Overview</CardTitle>
          </CardHeader>
          <CardContent className="p-2">
            <ResponsiveContainer width="100%" height={150}>
              <BarChart data={dailySalesData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" tick={{ fontSize: 8 }} />
                <YAxis tick={{ fontSize: 8 }} />
                <Bar dataKey="sales" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Payment Methods */}
        <Card>
          <CardHeader className="p-2">
            <CardTitle className="text-xs">Payment Methods</CardTitle>
          </CardHeader>
          <CardContent className="p-2">
            <ResponsiveContainer width="100%" height={150}>
              <PieChart>
                <Pie
                  data={paymentMethodData}
                  cx="50%"
                  cy="50%"
                  outerRadius={50}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                >
                  {paymentMethodData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tables */}
      <div className="grid grid-cols-2 gap-3">
        {/* Recent Sales */}
        <Card className="shadow-md">
          <CardHeader className="p-2 bg-muted/30">
            <div className="flex justify-between items-center">
              <CardTitle className="text-xs">Recent Sales</CardTitle>
              <Button size="sm" variant="outline" onClick={() => exportData('sales')} className="h-5 text-xs px-1">
                <Download className="h-2 w-2 mr-1" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-2">
            <DataTable
              data={salesData.slice(0, 10)}
              columns={[
                {
                  key: 'created_at',
                  header: 'Time',
                  cell: (sale) => new Date(sale.created_at).toLocaleTimeString(),
                  className: "w-20"
                },
                {
                  key: 'total_amount',
                  header: 'Amount',
                  cell: (sale) => `KES ${sale.total_amount.toFixed(2)}`,
                  className: "font-medium text-right"
                },
                {
                  key: 'payment_method',
                  header: 'Method',
                  cell: (sale) => (
                    <Badge variant="outline" className="text-xs h-4">{sale.payment_method}</Badge>
                  ),
                  className: "w-16"
                },
                {
                  key: 'cashier_name',
                  header: 'Cashier',
                  cell: (sale) => sale.cashier_name
                },
                {
                  key: 'actions',
                  header: 'Actions',
                  cell: (sale) => (
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="h-4 text-xs p-0"
                      onClick={() => {
                        setViewingSale(sale);
                        setShowDetailModal(true);
                      }}
                    >
                      <Eye className="h-2 w-2" />
                    </Button>
                  ),
                  className: "w-12"
                }
              ]}
              compact={true}
              maxHeight="160px"
              emptyMessage="No sales data available"
            />
          </CardContent>
        </Card>

        {/* Cashier Performance */}
        <Card className="shadow-md">
          <CardHeader className="p-2 bg-muted/30">
            <div className="flex justify-between items-center">
              <CardTitle className="text-xs">Cashier Performance</CardTitle>
              <Button size="sm" variant="outline" onClick={() => exportData('cashiers')} className="h-5 text-xs px-1">
                <Download className="h-2 w-2 mr-1" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-2">
            <DataTable
              data={cashierPerformance}
              columns={[
                {
                  key: 'name',
                  header: 'Cashier',
                  cell: (cashier) => cashier.name,
                  className: "font-medium"
                },
                {
                  key: 'sales',
                  header: 'Sales',
                  cell: (cashier) => `KES ${cashier.sales.toLocaleString()}`,
                  className: "text-right"
                },
                {
                  key: 'transactions',
                  header: 'Trans.',
                  cell: (cashier) => cashier.transactions.toString(),
                  className: "text-center w-12"
                },
                {
                  key: 'avg_transaction',
                  header: 'Avg',
                  cell: (cashier) => `KES ${cashier.avg_transaction}`,
                  className: "text-right"
                }
              ]}
              compact={true}
              maxHeight="160px"
              emptyMessage="No performance data available"
            />
          </CardContent>
        </Card>
      </div>

      {/* Sale Detail Modal */}
      <ActionModal
        open={showDetailModal}
        onOpenChange={setShowDetailModal}
        title="Sale Details"
        description={viewingSale ? `Transaction from ${new Date(viewingSale.created_at).toLocaleString()}` : ""}
        size="md"
        secondaryAction={{
          label: "Close",
          onClick: () => setShowDetailModal(false)
        }}
      >
        {viewingSale && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground">Sale ID</label>
                <p className="text-sm">{viewingSale.id.slice(0, 8)}...</p>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">Amount</label>
                <p className="text-sm font-medium">KES {viewingSale.total_amount.toFixed(2)}</p>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">Payment Method</label>
                <p className="text-sm">{viewingSale.payment_method}</p>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">Cashier</label>
                <p className="text-sm">{viewingSale.cashier_name}</p>
              </div>
              <div className="col-span-2">
                <label className="text-xs font-medium text-muted-foreground">Date & Time</label>
                <p className="text-sm">{new Date(viewingSale.created_at).toLocaleString()}</p>
              </div>
            </div>
          </div>
        )}
      </ActionModal>
    </div>
  );
};