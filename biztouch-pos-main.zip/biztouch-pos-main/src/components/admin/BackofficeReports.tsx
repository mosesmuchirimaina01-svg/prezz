import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Download, Calendar } from "lucide-react";

export const BackofficeReports = () => {
  const [reportType, setReportType] = useState("");
  const [dateRange, setDateRange] = useState("");

  const reports = [
    {
      id: "1",
      name: "Stock Report",
      type: "Inventory",
      generated_at: new Date().toISOString(),
      status: "Ready"
    },
    {
      id: "2",
      name: "Supplier Performance",
      type: "Supplier",
      generated_at: new Date().toISOString(),
      status: "Ready"
    }
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <FileText className="h-4 w-4" />
          Backoffice Reports
        </h3>
        <div className="flex gap-2">
          <Select onValueChange={setReportType}>
            <SelectTrigger className="w-40 text-xs h-8">
              <SelectValue placeholder="Report type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="inventory">Inventory</SelectItem>
              <SelectItem value="supplier">Supplier</SelectItem>
              <SelectItem value="orders">Orders</SelectItem>
            </SelectContent>
          </Select>
          <Input
            type="date"
            className="w-32 text-xs h-8"
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
          />
          <Button size="sm">
            <FileText className="h-3 w-3 mr-1" />
            Generate
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-3">
          <div className="overflow-auto max-h-64">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs">Report Name</TableHead>
                  <TableHead className="text-xs">Type</TableHead>
                  <TableHead className="text-xs">Generated</TableHead>
                  <TableHead className="text-xs">Status</TableHead>
                  <TableHead className="text-xs">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell className="text-xs font-medium">{report.name}</TableCell>
                    <TableCell className="text-xs">{report.type}</TableCell>
                    <TableCell className="text-xs">{new Date(report.generated_at).toLocaleDateString()}</TableCell>
                    <TableCell className="text-xs">
                      <span className="text-green-600">{report.status}</span>
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="outline" className="h-6 text-xs">
                        <Download className="h-3 w-3 mr-1" />
                        Download
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};