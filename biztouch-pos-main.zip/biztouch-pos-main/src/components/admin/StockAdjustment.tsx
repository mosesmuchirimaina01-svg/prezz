import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface Product {
  id: string;
  name: string;
  code: string;
  stock_quantity: number;
}

interface StockAdjustmentProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export const StockAdjustment: React.FC<StockAdjustmentProps> = ({
  open,
  onOpenChange,
  onSuccess
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [movementType, setMovementType] = useState('stock_in');
  const [quantity, setQuantity] = useState('');
  const [reason, setReason] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingProducts, setLoadingProducts] = useState(true);
  
  const { toast } = useToast();
  const { profile, selectedCompany } = useAuth();

  useEffect(() => {
    if (open) {
      fetchProducts();
    }
  }, [open]);

  const fetchProducts = async () => {
    try {
      setLoadingProducts(true);
      const { data, error } = await supabase
        .from('products')
        .select('id, name, code, stock_quantity')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch products",
        variant: "destructive",
      });
    } finally {
      setLoadingProducts(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (!profile?.id) {
        throw new Error('User profile not found');
      }

      if (!selectedCompany?.id) {
        throw new Error('No company selected');
      }

      const adjustmentQuantity = parseInt(quantity);
      if (isNaN(adjustmentQuantity) || adjustmentQuantity <= 0) {
        throw new Error('Invalid quantity');
      }

      // Record the stock adjustment
      const { error: adjustmentError } = await supabase
        .from('stock_adjustments')
        .insert({
          product_id: selectedProductId,
          adjustment_type: movementType,
          quantity: adjustmentQuantity,
          reason,
          adjusted_by: profile.id,
          company_id: selectedCompany.id
        });

      if (adjustmentError) throw adjustmentError;

      // Update product stock quantity
      const selectedProduct = products.find(p => p.id === selectedProductId);
      if (selectedProduct) {
        let newQuantity = selectedProduct.stock_quantity;
        
        if (movementType === 'stock_in') {
          newQuantity += adjustmentQuantity;
        } else if (movementType === 'stock_out') {
          newQuantity = Math.max(0, newQuantity - adjustmentQuantity);
        } else if (movementType === 'adjustment') {
          newQuantity = adjustmentQuantity; // Set to exact quantity
        }

        const { error: updateError } = await supabase
          .from('products')
          .update({ stock_quantity: newQuantity })
          .eq('id', selectedProductId);

        if (updateError) throw updateError;
      }

      // Also record as stock movement
      const { error: movementError } = await supabase
        .from('stock_movements')
        .insert({
          product_id: selectedProductId,
          user_id: profile.id,
          quantity: movementType === 'stock_out' ? -adjustmentQuantity : adjustmentQuantity,
          movement_type: movementType,
          reason,
          company_id: selectedCompany.id
        });

      if (movementError) throw movementError;

      toast({
        title: "Success",
        description: "Stock adjustment completed successfully",
      });

      // Reset form
      setSelectedProductId('');
      setMovementType('stock_in');
      setQuantity('');
      setReason('');
      
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      console.error('Error processing stock adjustment:', error);
      toast({
        title: "Error",
        description: "Failed to process stock adjustment",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setSelectedProductId('');
    setMovementType('stock_in');
    setQuantity('');
    setReason('');
    onOpenChange(false);
  };

  const selectedProduct = products.find(p => p.id === selectedProductId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Stock Adjustment</DialogTitle>
          <DialogDescription>
            Adjust stock levels based on physical counts and reconciliation.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="product-select">Select Product</Label>
            {loadingProducts ? (
              <div className="text-sm text-muted-foreground">Loading products...</div>
            ) : (
              <Select value={selectedProductId} onValueChange={setSelectedProductId} required>
                <SelectTrigger id="product-select">
                  <SelectValue placeholder="Choose a product..." />
                </SelectTrigger>
                <SelectContent>
                  {products.map((product) => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.code} - {product.name} (Current: {product.stock_quantity})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          {selectedProduct && (
            <div className="p-3 bg-muted rounded-lg">
              <div className="text-sm">
                <strong>Current Stock:</strong> {selectedProduct.stock_quantity} units
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="movement-type">Movement Type</Label>
            <Select value={movementType} onValueChange={setMovementType} required>
              <SelectTrigger id="movement-type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="stock_in">Stock In (Add)</SelectItem>
                <SelectItem value="stock_out">Stock Out (Remove)</SelectItem>
                <SelectItem value="adjustment">Adjustment (Set Exact)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="quantity">Quantity</Label>
            <Input
              id="quantity"
              type="number"
              min="1"
              placeholder="Enter quantity"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reason">Reason</Label>
            <Textarea
              id="reason"
              placeholder="Enter reason for adjustment"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              rows={3}
            />
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading || !selectedProductId}>
              {isLoading ? "Processing..." : "Save"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};