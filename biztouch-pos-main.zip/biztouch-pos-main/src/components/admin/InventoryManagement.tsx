import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Package, AlertTriangle, Plus, Edit } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import { ActionModal } from "@/components/ui/action-modal";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";

interface Product {
  id: string;
  name: string;
  code: string;
  stock_quantity: number;
  min_stock_level: number;
  price: number;
  cost_price: number;
  is_active: boolean;
  category_id?: string;
  supplier_id?: string;
}

export const InventoryManagement = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newProduct, setNewProduct] = useState({
    name: '',
    code: '',
    price: '',
    cost_price: '',
    stock_quantity: '',
    min_stock_level: '5'
  });
  const { toast } = useToast();
  const { selectedCompany } = useAuth();

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      if (!selectedCompany?.id) {
        setProducts([]);
        return;
      }

      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('company_id', selectedCompany.id)
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch products",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddProduct = async () => {
    try {
      if (!selectedCompany?.id) {
        toast({
          title: "Error",
          description: "Please select a company first",
          variant: "destructive",
        });
        return;
      }

      // Validate required fields
      if (!newProduct.name.trim()) {
        toast({
          title: "Error",
          description: "Product name is required",
          variant: "destructive",
        });
        return;
      }

      if (!newProduct.code.trim()) {
        toast({
          title: "Error",
          description: "Product code is required",
          variant: "destructive",
        });
        return;
      }

      if (!newProduct.price || parseFloat(newProduct.price) <= 0) {
        toast({
          title: "Error",
          description: "Valid selling price is required",
          variant: "destructive",
        });
        return;
      }

      if (editingProduct) {
        // Update existing product
        const { error } = await supabase
          .from('products')
          .update({
            name: newProduct.name.trim(),
            price: parseFloat(newProduct.price),
            cost_price: newProduct.cost_price ? parseFloat(newProduct.cost_price) : 0,
            stock_quantity: newProduct.stock_quantity ? parseInt(newProduct.stock_quantity) : 0,
            min_stock_level: parseInt(newProduct.min_stock_level) || 5,
          })
          .eq('id', editingProduct.id);

        if (error) throw error;

        toast({
          title: "Success",
          description: "Product updated successfully",
        });
      } else {
        // Create new product
        const { error } = await supabase
          .from('products')
          .insert({
            name: newProduct.name.trim(),
            code: newProduct.code.trim(),
            price: parseFloat(newProduct.price),
            cost_price: newProduct.cost_price ? parseFloat(newProduct.cost_price) : 0,
            stock_quantity: newProduct.stock_quantity ? parseInt(newProduct.stock_quantity) : 0,
            min_stock_level: parseInt(newProduct.min_stock_level) || 5,
            company_id: selectedCompany.id,
            is_active: true
          });

        if (error) {
          console.error("Product creation error:", error);
          
          if (error.code === '23505') {
            toast({
              title: "Duplicate Product Code",
              description: "A product with this code already exists. Please use a different code.",
              variant: "destructive",
            });
            return;
          }
          
          if (error.code === '42501') {
            toast({
              title: "Permission Denied",
              description: "You don't have permission to add products. Please contact your administrator.",
              variant: "destructive",
            });
            return;
          }

          toast({
            title: "Database Error",
            description: error.message || "Failed to add product. Please try again.",
            variant: "destructive",
          });
          return;
        }

        toast({
          title: "Success",
          description: "Product added successfully",
        });
      }

      setShowAddProduct(false);
      setEditingProduct(null);
      setNewProduct({
        name: '',
        code: '',
        price: '',
        cost_price: '',
        stock_quantity: '',
        min_stock_level: '5'
      });
      fetchProducts();
    } catch (error) {
      console.error("Unexpected error:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setNewProduct({
      name: product.name,
      code: product.code,
      price: product.price.toString(),
      cost_price: product.cost_price?.toString() || '',
      stock_quantity: product.stock_quantity.toString(),
      min_stock_level: product.min_stock_level.toString()
    });
    setShowAddProduct(true);
  };

  const getStockStatus = (quantity: number, minLevel: number) => {
    if (quantity === 0) return { label: "Out of Stock", variant: "destructive" as const };
    if (quantity <= minLevel) return { label: "Low Stock", variant: "secondary" as const };
    return { label: "In Stock", variant: "default" as const };
  };

  if (loading) {
    return <div className="p-4">Loading inventory...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Package className="h-6 w-6" />
          Inventory Management
        </h2>
        <div className="flex items-center gap-2">
          <Button onClick={() => setShowAddProduct(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Add Product
          </Button>
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-64"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{products.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Low Stock</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {products.filter(p => p.stock_quantity <= p.min_stock_level && p.stock_quantity > 0).length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Out of Stock</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {products.filter(p => p.stock_quantity === 0).length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ₹{products.reduce((sum, p) => sum + (p.stock_quantity * (p.cost_price || 0)), 0).toFixed(2)}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Product Inventory</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-auto max-h-96">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Product Name</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>Min Level</TableHead>
                  <TableHead>Unit Price</TableHead>
                  <TableHead>Cost Price</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((product) => {
                  const status = getStockStatus(product.stock_quantity, product.min_stock_level);
                  return (
                    <TableRow key={product.id}>
                      <TableCell className="font-mono">{product.code}</TableCell>
                      <TableCell className="font-medium">{product.name}</TableCell>
                      <TableCell>
                        <span className={product.stock_quantity <= product.min_stock_level ? 
                          "text-red-600 font-bold" : ""}>
                          {product.stock_quantity}
                        </span>
                      </TableCell>
                      <TableCell>{product.min_stock_level}</TableCell>
                      <TableCell>₹{product.price}</TableCell>
                      <TableCell>₹{product.cost_price || 0}</TableCell>
                      <TableCell>
                        <Badge variant={status.variant}>{status.label}</Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleEditProduct(product)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <ActionModal
        open={showAddProduct}
        onOpenChange={(open) => {
          setShowAddProduct(open);
          if (!open) {
            setEditingProduct(null);
            setNewProduct({
              name: '',
              code: '',
              price: '',
              cost_price: '',
              stock_quantity: '',
              min_stock_level: '5'
            });
          }
        }}
        title={editingProduct ? "Edit Product" : "Add New Product"}
        description={editingProduct ? "Update product details" : "Fill in the product details to add it to inventory"}
        primaryAction={{
          label: editingProduct ? "Update Product" : "Add Product",
          onClick: handleAddProduct
        }}
        secondaryAction={{
          label: "Cancel",
          onClick: () => {
            setShowAddProduct(false);
            setEditingProduct(null);
          }
        }}
      >
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="product-name">Product Name</Label>
            <Input
              id="product-name"
              value={newProduct.name}
              onChange={(e) => setNewProduct(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Enter product name"
            />
          </div>
          <div>
            <Label htmlFor="product-code">Product Code</Label>
            <Input
              id="product-code"
              value={newProduct.code}
              onChange={(e) => setNewProduct(prev => ({ ...prev, code: e.target.value }))}
              placeholder="Enter product code"
              disabled={!!editingProduct}
            />
          </div>
          <div>
            <Label htmlFor="selling-price">Selling Price</Label>
            <Input
              id="selling-price"
              type="number"
              step="0.01"
              value={newProduct.price}
              onChange={(e) => setNewProduct(prev => ({ ...prev, price: e.target.value }))}
              placeholder="0.00"
            />
          </div>
          <div>
            <Label htmlFor="cost-price">Cost Price</Label>
            <Input
              id="cost-price"
              type="number"
              step="0.01"
              value={newProduct.cost_price}
              onChange={(e) => setNewProduct(prev => ({ ...prev, cost_price: e.target.value }))}
              placeholder="0.00"
            />
          </div>
          <div>
            <Label htmlFor="stock-quantity">Initial Stock</Label>
            <Input
              id="stock-quantity"
              type="number"
              value={newProduct.stock_quantity}
              onChange={(e) => setNewProduct(prev => ({ ...prev, stock_quantity: e.target.value }))}
              placeholder="0"
            />
          </div>
          <div>
            <Label htmlFor="min-stock">Minimum Stock Level</Label>
            <Input
              id="min-stock"
              type="number"
              value={newProduct.min_stock_level}
              onChange={(e) => setNewProduct(prev => ({ ...prev, min_stock_level: e.target.value }))}
              placeholder="5"
            />
          </div>
        </div>
      </ActionModal>
    </div>
  );
};