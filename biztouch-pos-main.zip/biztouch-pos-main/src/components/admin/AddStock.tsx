import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit, Trash2, Package2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface StockEntry {
  id: string;
  product_name: string;
  product_code: string;
  quantity_added: number;
  supplier_name: string;
  cost_price: number;
  added_by: string;
  created_at: string;
}

export const AddStock = () => {
  const [stockEntries, setStockEntries] = useState<StockEntry[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    product_code: "",
    quantity: "",
    supplier_id: "",
    cost_price: "",
    department: "",
    sale_type: ""
  });
  const { toast } = useToast();

  useEffect(() => {
    // Mock data
    setStockEntries([
      {
        id: "1",
        product_name: "Product A",
        product_code: "PA001",
        quantity_added: 100,
        supplier_name: "ABC Suppliers",
        cost_price: 15.5,
        added_by: "Manager",
        created_at: new Date().toISOString()
      }
    ]);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Success", description: "Stock added successfully" });
    setIsDialogOpen(false);
    setFormData({
      product_code: "",
      quantity: "",
      supplier_id: "",
      cost_price: "",
      department: "",
      sale_type: ""
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Package2 className="h-4 w-4" />
          Add Stock
        </h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="h-3 w-3 mr-1" />
              Add Stock
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-sm">Add New Stock</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-3">

              <div>
                <Label htmlFor="product_code" className="text-xs">Product Code</Label>
                <Input
                  id="product_code"
                  value={formData.product_code}
                  onChange={(e) => setFormData({ ...formData, product_code: e.target.value })}
                  className="text-xs h-8"
                  placeholder="Scan or enter barcode"
                  required
                />
              </div>

              <div>
                <Label htmlFor="quantity" className="text-xs">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  className="text-xs h-8"
                  required
                />
              </div>

              <div>
                <Label htmlFor="supplier" className="text-xs">Supplier</Label>
                <Select onValueChange={(value) => setFormData({ ...formData, supplier_id: value })}>
                  <SelectTrigger className="text-xs h-8">
                    <SelectValue placeholder="Select supplier" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">ABC Suppliers</SelectItem>
                    <SelectItem value="2">XYZ Distributors</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* --- ADDED DEPARTMENT FIELD --- */}
              <div>
                <Label htmlFor="department" className="text-xs">Department</Label>
                <Select onValueChange={(value) => setFormData({ ...formData, department: value })}>
                  <SelectTrigger className="text-xs h-8">
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="grocery">Grocery</SelectItem>
                    <SelectItem value="electronics">Electronics</SelectItem>
                    <SelectItem value="services">Services</SelectItem>
                    <SelectItem value="drinks">Drinks</SelectItem>
                    <SelectItem value="furniture">Furniture</SelectItem>
                    <SelectItem value="utensils">Utensils</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* --- ADDED SALE TYPE FIELD --- */}
              <div>
                <Label htmlFor="sale_type" className="text-xs">Sale Type</Label>
                <Select onValueChange={(value) => setFormData({ ...formData, sale_type: value })}>
                  <SelectTrigger className="text-xs h-8">
                    <SelectValue placeholder="Is this Goods or a Service?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="goods">Goods Sale</SelectItem>
                    <SelectItem value="service">Service Sale</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="cost_price" className="text-xs">Cost Price</Label>
                <Input
                  id="cost_price"
                  type="number"
                  step="0.01"
                  value={formData.cost_price}
                  onChange={(e) => setFormData({ ...formData, cost_price: e.target.value })}
                  className="text-xs h-8"
                  required
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" size="sm" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" size="sm">Add Stock</Button>
              </div>

            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-3">
          <div className="overflow-auto max-h-64">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs">Product</TableHead>
                  <TableHead className="text-xs">Code</TableHead>
                  <TableHead className="text-xs">Quantity</TableHead>
                  <TableHead className="text-xs">Supplier</TableHead>
                  <TableHead className="text-xs">Cost</TableHead>
                  <TableHead className="text-xs">Date</TableHead>
                  <TableHead className="text-xs">Actions</TableHead>
                </TableRow>
              </TableHeader>

              <TableBody>
                {stockEntries.map((entry) => (
                  <TableRow key={entry.id}>
                    <TableCell className="text-xs font-medium">{entry.product_name}</TableCell>
                    <TableCell className="text-xs font-mono">{entry.product_code}</TableCell>
                    <TableCell className="text-xs">{entry.quantity_added}</TableCell>
                    <TableCell className="text-xs">{entry.supplier_name}</TableCell>
                    <TableCell className="text-xs">₹{entry.cost_price}</TableCell>
                    <TableCell className="text-xs">{new Date(entry.created_at).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" className="h-6 w-6 p-0">
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button size="sm" variant="outline" className="h-6 w-6 p-0">
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>

            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
