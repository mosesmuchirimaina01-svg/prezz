import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Users, Plus, Edit, Trash2, Shield, Eye, EyeOff } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface User {
  id: string;
  username: string;
  full_name: string;
  email: string;
  role: 'admin' | 'manager' | 'supervisor' | 'cashier';
  is_active: boolean;
  last_login: string;
  created_at: string;
  permissions: string[];
}

const UserManagement = () => {
  const { toast } = useToast();
  const [users, setUsers] = useState<User[]>([
    {
      id: '1',
      username: 'admin',
      full_name: 'System Administrator',
      email: 'admin@company.com',
      role: 'admin',
      is_active: true,
      last_login: '2024-01-20 09:30',
      created_at: '2024-01-01',
      permissions: ['all']
    },
    {
      id: '2',
      username: 'manager1',
      full_name: 'Store Manager',
      email: 'manager@company.com',
      role: 'manager',
      is_active: true,
      last_login: '2024-01-20 08:15',
      created_at: '2024-01-05',
      permissions: ['reports', 'inventory', 'users']
    },
    {
      id: '3',
      username: 'cashier1',
      full_name: 'John Doe',
      email: 'cashier1@company.com',
      role: 'cashier',
      is_active: true,
      last_login: '2024-01-20 07:45',
      created_at: '2024-01-10',
      permissions: ['sales', 'daily_reports']
    }
  ]);

  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newUser, setNewUser] = useState({
    username: '',
    full_name: '',
    email: '',
    role: 'cashier' as const,
    password: ''
  });

  const rolePermissions = {
    admin: ['Full system access', 'User management', 'All reports', 'System settings'],
    manager: ['All reports', 'Inventory management', 'User oversight', 'Sales analytics'],
    supervisor: ['Discount authorization', 'Refund processing', 'Shift oversight', 'Staff reports'],
    cashier: ['Process sales', 'Daily reports', 'Customer service', 'Basic inventory view']
  };

  const handleAddUser = () => {
    const user: User = {
      id: crypto.randomUUID(),
      ...newUser,
      is_active: true,
      last_login: 'Never',
      created_at: new Date().toISOString().split('T')[0],
      permissions: rolePermissions[newUser.role] || []
    };

    setUsers(prev => [...prev, user]);
    
    toast({
      title: "User Created",
      description: `${user.full_name} has been added to the system`,
    });

    setShowAddDialog(false);
    setNewUser({
      username: '',
      full_name: '',
      email: '',
      role: 'cashier',
      password: ''
    });
  };

  const handleToggleStatus = (id: string) => {
    setUsers(prev => prev.map(user => 
      user.id === id 
        ? { ...user, is_active: !user.is_active }
        : user
    ));
    
    toast({
      title: "User Status Updated",
      description: "User status has been changed successfully",
    });
  };

  const handleDeleteUser = (id: string) => {
    setUsers(prev => prev.filter(u => u.id !== id));
    toast({
      title: "User Deleted",
      description: "User has been removed from the system",
    });
  };

  const getRoleBadge = (role: string) => {
    const colors = {
      admin: "bg-red-100 text-red-800",
      manager: "bg-blue-100 text-blue-800",
      supervisor: "bg-purple-100 text-purple-800",
      cashier: "bg-green-100 text-green-800"
    };
    
    return <Badge className={`${colors[role as keyof typeof colors]} text-xs`}>{role}</Badge>;
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Users className="h-4 w-4" />
          User Management & Permissions
        </h2>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="h-3 w-3 mr-1" />
              Add New User
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-sm">Create New User Account</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Username</Label>
                  <Input
                    value={newUser.username}
                    onChange={(e) => setNewUser(prev => ({ ...prev, username: e.target.value }))}
                    placeholder="username"
                    className="text-xs h-7"
                  />
                </div>
                <div>
                  <Label className="text-xs">Full Name</Label>
                  <Input
                    value={newUser.full_name}
                    onChange={(e) => setNewUser(prev => ({ ...prev, full_name: e.target.value }))}
                    placeholder="John Doe"
                    className="text-xs h-7"
                  />
                </div>
              </div>
              
              <div>
                <Label className="text-xs">Email</Label>
                <Input
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="user@company.com"
                  className="text-xs h-7"
                />
              </div>
              
              <div>
                <Label className="text-xs">Password</Label>
                <Input
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="Password"
                  className="text-xs h-7"
                />
              </div>
              
              <div>
                <Label className="text-xs">Role</Label>
                <Select value={newUser.role} onValueChange={(value: any) => setNewUser(prev => ({ ...prev, role: value }))}>
                  <SelectTrigger className="text-xs h-7">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cashier">Cashier</SelectItem>
                    <SelectItem value="supervisor">Supervisor</SelectItem>
                    <SelectItem value="manager">Manager</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Role Permissions Preview */}
              <div className="bg-muted p-2 rounded text-xs">
                <div className="font-medium mb-1">Role Permissions:</div>
                <ul className="list-disc list-inside space-y-1">
                  {rolePermissions[newUser.role].map((perm, idx) => (
                    <li key={idx}>{perm}</li>
                  ))}
                </ul>
              </div>
              
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => setShowAddDialog(false)} className="flex-1 text-xs h-7">
                  Cancel
                </Button>
                <Button size="sm" onClick={handleAddUser} className="flex-1 text-xs h-7">
                  <Shield className="h-2 w-2 mr-1" />
                  Create User
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-2">
        <Card>
          <CardContent className="p-2">
            <div className="text-center">
              <div className="text-lg font-bold">{users.length}</div>
              <div className="text-xs text-muted-foreground">Total Users</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="text-center">
              <div className="text-lg font-bold text-green-600">{users.filter(u => u.is_active).length}</div>
              <div className="text-xs text-muted-foreground">Active Users</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="text-center">
              <div className="text-lg font-bold text-blue-600">{users.filter(u => u.role === 'admin').length}</div>
              <div className="text-xs text-muted-foreground">Administrators</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-2">
            <div className="text-center">
              <div className="text-lg font-bold text-purple-600">{users.filter(u => u.role === 'cashier').length}</div>
              <div className="text-xs text-muted-foreground">Cashiers</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Role Descriptions */}
      <Card>
        <CardHeader className="p-2">
          <CardTitle className="text-sm">User Roles & Permissions</CardTitle>
        </CardHeader>
        <CardContent className="p-2">
          <div className="grid grid-cols-2 gap-4">
            {Object.entries(rolePermissions).map(([role, permissions]) => (
              <div key={role} className="border rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  {getRoleBadge(role)}
                  <span className="text-sm font-medium capitalize">{role}</span>
                </div>
                <ul className="text-xs text-muted-foreground space-y-1">
                  {permissions.map((perm, idx) => (
                    <li key={idx} className="flex items-center gap-1">
                      <Shield className="h-2 w-2" />
                      {perm}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardHeader className="p-2">
          <CardTitle className="text-sm">System Users</CardTitle>
        </CardHeader>
        <CardContent className="p-2">
          <div className="overflow-auto max-h-96">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs h-6">User</TableHead>
                  <TableHead className="text-xs h-6">Contact</TableHead>
                  <TableHead className="text-xs h-6">Role</TableHead>
                  <TableHead className="text-xs h-6">Status</TableHead>
                  <TableHead className="text-xs h-6">Last Login</TableHead>
                  <TableHead className="text-xs h-6">Created</TableHead>
                  <TableHead className="text-xs h-6">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="text-xs">
                      <div>
                        <div className="font-medium">{user.full_name}</div>
                        <div className="text-muted-foreground">@{user.username}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs">
                      <div>{user.email}</div>
                    </TableCell>
                    <TableCell className="text-xs">
                      {getRoleBadge(user.role)}
                    </TableCell>
                    <TableCell className="text-xs">
                      <div className="flex items-center gap-1">
                        <Switch 
                          checked={user.is_active}
                          onCheckedChange={() => handleToggleStatus(user.id)}
                          className="h-4 w-7"
                        />
                        <span className={user.is_active ? 'text-green-600' : 'text-red-600'}>
                          {user.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs">{user.last_login}</TableCell>
                    <TableCell className="text-xs">{user.created_at}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline" className="h-5 text-xs px-1">
                          <Edit className="h-2 w-2" />
                        </Button>
                        <Button size="sm" variant="outline" className="h-5 text-xs px-1">
                          {user.is_active ? <EyeOff className="h-2 w-2" /> : <Eye className="h-2 w-2" />}
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive" 
                          onClick={() => handleDeleteUser(user.id)}
                          className="h-5 text-xs px-1"
                        >
                          <Trash2 className="h-2 w-2" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserManagement;