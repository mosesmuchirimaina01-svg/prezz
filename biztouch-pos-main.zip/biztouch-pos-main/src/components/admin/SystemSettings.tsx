import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Save, RefreshCw } from 'lucide-react';
import { SystemPasswordDialog } from '@/components/SystemPasswordDialog';

interface SystemSetting {
  id: string;
  key: string;
  value: string;
  description: string | null;
}

export const SystemSettings: React.FC = () => {
  const [settings, setSettings] = useState<SystemSetting[]>([]);
  const [loading, setLoading] = useState(false);
  const [newSetting, setNewSetting] = useState({ key: '', value: '', description: '' });
  const [showPasswordDialog, setShowPasswordDialog] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('system_settings')
        .select('*')
        .order('key');
      
      if (error) throw error;
      setSettings(data || []);
    } catch (error) {
      console.error('Error fetching settings:', error);
      toast({
        title: "Error",
        description: "Failed to load system settings",
        variant: "destructive",
      });
    }
  };

  const updateSetting = async (id: string, value: string) => {
    try {
      const { error } = await supabase
        .from('system_settings')
        .update({ value })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Setting updated successfully",
      });

      fetchSettings();
    } catch (error) {
      console.error('Error updating setting:', error);
      toast({
        title: "Error",
        description: "Failed to update setting",
        variant: "destructive",
      });
    }
  };

  const addNewSetting = async () => {
    if (!newSetting.key || !newSetting.value) {
      toast({
        title: "Validation Error",
        description: "Key and value are required",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('system_settings')
        .insert({
          key: newSetting.key,
          value: newSetting.value,
          description: newSetting.description || null
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "New setting added successfully",
      });

      setNewSetting({ key: '', value: '', description: '' });
      fetchSettings();
    } catch (error) {
      console.error('Error adding setting:', error);
      toast({
        title: "Error",
        description: "Failed to add setting",
        variant: "destructive",
      });
    }
  };

  if (!isAuthenticated) {
    return (
      <SystemPasswordDialog
        open={showPasswordDialog}
        onOpenChange={(open) => {
          if (!open) {
            // User closed dialog without authenticating
            setShowPasswordDialog(false);
          }
        }}
        onSuccess={() => {
          setIsAuthenticated(true);
          setShowPasswordDialog(false);
          fetchSettings();
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">System Settings</h2>
        <Button onClick={() => { setLoading(true); fetchSettings().finally(() => setLoading(false)); }}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Current Settings */}
        <Card>
          <CardHeader>
            <CardTitle>Current Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {settings.map((setting) => (
              <div key={setting.id} className="space-y-2">
                <Label htmlFor={`setting-${setting.id}`} className="text-sm font-medium">
                  {setting.key}
                </Label>
                {setting.description && (
                  <p className="text-xs text-gray-500">{setting.description}</p>
                )}
                <div className="flex gap-2">
                  <Input
                    id={`setting-${setting.id}`}
                    value={setting.value}
                    onChange={(e) => {
                      const newSettings = settings.map(s => 
                        s.id === setting.id ? { ...s, value: e.target.value } : s
                      );
                      setSettings(newSettings);
                    }}
                  />
                  <Button
                    size="sm"
                    onClick={() => updateSetting(setting.id, setting.value)}
                  >
                    <Save className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Add New Setting */}
        <Card>
          <CardHeader>
            <CardTitle>Add New Setting</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="new-key">Setting Key</Label>
              <Input
                id="new-key"
                placeholder="e.g., store_name"
                value={newSetting.key}
                onChange={(e) => setNewSetting({ ...newSetting, key: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="new-value">Setting Value</Label>
              <Input
                id="new-value"
                placeholder="e.g., My Store"
                value={newSetting.value}
                onChange={(e) => setNewSetting({ ...newSetting, value: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="new-description">Description (Optional)</Label>
              <Textarea
                id="new-description"
                placeholder="Description of what this setting does"
                value={newSetting.description}
                onChange={(e) => setNewSetting({ ...newSetting, description: e.target.value })}
              />
            </div>
            <Button onClick={addNewSetting} className="w-full">
              Add Setting
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};