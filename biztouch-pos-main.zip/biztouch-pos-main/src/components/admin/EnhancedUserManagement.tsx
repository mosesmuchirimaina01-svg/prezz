import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Users, Plus, Edit, Trash2, Shield } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface UserPermission {
  key: string;
  label: string;
  description: string;
}

const AVAILABLE_PERMISSIONS: Record<string, UserPermission[]> = {
  cashier: [
    { key: 'can_delete_items', label: 'Delete Items', description: 'Remove items from cart' },
    { key: 'can_process_expenses', label: 'Process Expenses', description: 'Record cash expenses' },
    { key: 'can_hold_bills', label: 'Hold Bills', description: 'Hold transactions for later' },
    { key: 'can_unhold_bills', label: 'Unhold Bills', description: 'Resume held transactions' },
    { key: 'can_clear_bills', label: 'Clear Bills', description: 'Clear/cancel bills' },
  ],
  supervisor: [
    { key: 'can_view_backoffice', label: 'View Back-office', description: 'Access back-office tabs' },
    { key: 'can_manage_stock', label: 'Manage Stock', description: 'Stock adjustments' },
    { key: 'can_view_reports', label: 'View Reports', description: 'Access reports' },
    { key: 'can_view_expenses', label: 'View Expenses', description: 'View expense records' },
  ],
  admin: [],
  manager: [],
};

const EnhancedUserManagement = () => {
  const { toast } = useToast();
  const { profile, selectedCompany } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newUser, setNewUser] = useState({
    username: '',
    full_name: '',
    email: '',
    password: '',
    role: 'cashier' as 'admin' | 'manager' | 'supervisor' | 'cashier',
    phone_number: '',
    id_number: '',
  });
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);

  useEffect(() => {
    fetchUsers();
  }, [selectedCompany]);

  const fetchUsers = async () => {
    if (!selectedCompany) return;
    
    setLoading(true);
    try {
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('*')
        .eq('company_id', selectedCompany.id);

      if (profilesError) throw profilesError;

      const usersWithRoles = await Promise.all(
        (profilesData || []).map(async (p) => {
          const { data: rolesData } = await supabase
            .from('user_roles')
            .select('role')
            .eq('user_id', p.user_id);

          const { data: permsData } = await supabase
            .from('user_permissions')
            .select('permission_key, enabled')
            .eq('user_id', p.user_id)
            .eq('enabled', true);

          return {
            ...p,
            roles: rolesData?.map(r => r.role) || [],
            permissions: permsData?.map(p => p.permission_key) || []
          };
        })
      );

      setUsers(usersWithRoles);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddUser = async () => {
    if (!selectedCompany) {
      toast({ title: "Error", description: "No company selected", variant: "destructive" });
      return;
    }

    // Validate required fields
    if (!newUser.full_name || !newUser.username || !newUser.email || !newUser.password || !newUser.phone_number || !newUser.id_number) {
      toast({ title: "Error", description: "Please fill in all required fields", variant: "destructive" });
      return;
    }

    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newUser.email,
        password: newUser.password,
        options: {
          data: {
            username: newUser.username,
            full_name: newUser.full_name,
            role: newUser.role,
            company_id: selectedCompany.id,
            phone_number: newUser.phone_number,
            id_number: newUser.id_number,
          }
        }
      });

      if (authError) throw authError;
      if (!authData.user) throw new Error('User creation failed');

      const { error: roleError } = await supabase
        .from('user_roles')
        .insert({
          user_id: authData.user.id,
          role: newUser.role
        });

      if (roleError) throw roleError;

      if (selectedPermissions.length > 0) {
        const permissionsToInsert = selectedPermissions.map(key => ({
          user_id: authData.user.id,
          permission_key: key,
          enabled: true
        }));

        const { error: permError } = await supabase
          .from('user_permissions')
          .insert(permissionsToInsert);

        if (permError) throw permError;
      }

      toast({
        title: "Success",
        description: `User ${newUser.full_name} created successfully with ID: ${newUser.id_number}`
      });

      setShowAddDialog(false);
      resetForm();
      fetchUsers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleToggleStatus = async (userId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_active: !currentStatus })
        .eq('id', userId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "User status updated"
      });

      fetchUsers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user?')) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', userId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "User deleted"
      });

      fetchUsers();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setNewUser({
      username: '',
      full_name: '',
      email: '',
      password: '',
      role: 'cashier',
      phone_number: '',
      id_number: '',
    });
    setSelectedPermissions([]);
  };

  const togglePermission = (key: string) => {
    setSelectedPermissions(prev =>
      prev.includes(key)
        ? prev.filter(k => k !== key)
        : [...prev, key]
    );
  };

  const getRoleBadge = (roles: string[]) => {
    if (!roles || roles.length === 0) return <Badge variant="outline">No Role</Badge>;
    
    const role = roles[0];
    const colors: Record<string, string> = {
      admin: "bg-destructive text-destructive-foreground",
      manager: "bg-primary text-primary-foreground",
      supervisor: "bg-secondary text-secondary-foreground",
      cashier: "bg-accent text-accent-foreground"
    };
    
    return <Badge className={colors[role]}>{role}</Badge>;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Users className="h-6 w-6" />
          User Management
        </h2>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add User
        </Button>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{users.length}</div>
              <div className="text-sm text-muted-foreground">Total Users</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">{users.filter(u => u.is_active).length}</div>
              <div className="text-sm text-muted-foreground">Active</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-destructive">
                {users.filter(u => u.roles?.includes('admin')).length}
              </div>
              <div className="text-sm text-muted-foreground">Admins</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-accent-foreground">
                {users.filter(u => u.roles?.includes('cashier')).length}
              </div>
              <div className="text-sm text-muted-foreground">Cashiers</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Users</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Permissions</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{user.full_name}</div>
                      <div className="text-sm text-muted-foreground">@{user.username}</div>
                    </div>
                  </TableCell>
                  <TableCell>{user.email || 'N/A'}</TableCell>
                  <TableCell>{getRoleBadge(user.roles)}</TableCell>
                  <TableCell>
                    <div className="text-xs text-muted-foreground">
                      {user.permissions?.length || 0} custom permissions
                    </div>
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={user.is_active}
                      onCheckedChange={() => handleToggleStatus(user.id, user.is_active)}
                    />
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDeleteUser(user.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Full Name</Label>
                <Input
                  value={newUser.full_name}
                  onChange={(e) => setNewUser(prev => ({ ...prev, full_name: e.target.value }))}
                  placeholder="John Doe"
                />
              </div>
              <div>
                <Label>Username</Label>
                <Input
                  value={newUser.username}
                  onChange={(e) => setNewUser(prev => ({ ...prev, username: e.target.value }))}
                  placeholder="johndoe"
                />
              </div>
            </div>

            <div>
              <Label>Email</Label>
              <Input
                type="email"
                value={newUser.email}
                onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                placeholder="john@company.com"
              />
            </div>

            <div>
              <Label>Password</Label>
              <Input
                type="password"
                value={newUser.password}
                onChange={(e) => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                placeholder="••••••••"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Phone Number</Label>
                <Input
                  value={newUser.phone_number}
                  onChange={(e) => setNewUser(prev => ({ ...prev, phone_number: e.target.value }))}
                  placeholder="+1234567890"
                />
              </div>
              <div>
                <Label>ID Number</Label>
                <Input
                  value={newUser.id_number}
                  onChange={(e) => setNewUser(prev => ({ ...prev, id_number: e.target.value }))}
                  placeholder="ID123456"
                />
              </div>
            </div>

            <div>
              <Label>User Role</Label>
              <Select value={newUser.role} onValueChange={(value: any) => setNewUser(prev => ({ ...prev, role: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cashier">Cashier</SelectItem>
                  <SelectItem value="supervisor">Supervisor</SelectItem>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(newUser.role === 'cashier' || newUser.role === 'supervisor') && (
              <div className="border rounded-lg p-4 space-y-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  Custom Permissions for {newUser.role}
                </h3>
                <div className="space-y-2">
                  {AVAILABLE_PERMISSIONS[newUser.role]?.map((perm) => (
                    <div key={perm.key} className="flex items-start gap-3">
                      <Checkbox
                        id={perm.key}
                        checked={selectedPermissions.includes(perm.key)}
                        onCheckedChange={() => togglePermission(perm.key)}
                      />
                      <div className="flex-1">
                        <Label htmlFor={perm.key} className="font-medium cursor-pointer">
                          {perm.label}
                        </Label>
                        <p className="text-sm text-muted-foreground">{perm.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => { setShowAddDialog(false); resetForm(); }}>
                Cancel
              </Button>
              <Button onClick={handleAddUser}>
                <Shield className="h-4 w-4 mr-2" />
                Create User
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default EnhancedUserManagement;
