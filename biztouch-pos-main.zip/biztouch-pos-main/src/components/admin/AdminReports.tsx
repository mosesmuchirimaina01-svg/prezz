import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts";
import { TrendingUp, DollarSign, Users, Package } from "lucide-react";
import { useEffect } from "react";

export const AdminReports = () => {
  const [reportPeriod, setReportPeriod] = useState("daily");
  const [salesData, setSalesData] = useState<any[]>([]);
  const [supplierBalances, setSupplierBalances] = useState<any[]>([]);

  useEffect(() => {
    // Data will be fetched from database based on actual sales
    setSalesData([]);
    setSupplierBalances([]);
  }, [reportPeriod]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <TrendingUp className="h-4 w-4" />
          Admin Reports & Analytics
        </h3>
        <Select value={reportPeriod} onValueChange={setReportPeriod}>
          <SelectTrigger className="w-32 text-xs h-8">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="daily">Daily</SelectItem>
            <SelectItem value="weekly">Weekly</SelectItem>
            <SelectItem value="monthly">Monthly</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <Card>
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Total Sales</p>
                <p className="text-lg font-bold">₹0</p>
              </div>
              <DollarSign className="h-6 w-6 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Total Users</p>
                <p className="text-lg font-bold">0</p>
              </div>
              <Users className="h-6 w-6 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Products</p>
                <p className="text-lg font-bold">0</p>
              </div>
              <Package className="h-6 w-6 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Profit</p>
                <p className="text-lg font-bold">₹0</p>
              </div>
              <TrendingUp className="h-6 w-6 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardHeader className="p-3">
            <CardTitle className="text-sm">Sales Overview</CardTitle>
          </CardHeader>
          <CardContent className="p-3">
            {salesData.length === 0 ? (
              <div className="text-center py-20 text-muted-foreground text-sm">
                No sales data available
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={salesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Bar dataKey="sales" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="p-3">
            <CardTitle className="text-sm">Supplier Balances</CardTitle>
          </CardHeader>
          <CardContent className="p-3">
          <div className="overflow-auto max-h-52">
              {supplierBalances.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  No supplier data available
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">Supplier</TableHead>
                      <TableHead className="text-xs">Balance</TableHead>
                      <TableHead className="text-xs">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {supplierBalances.map((supplier) => (
                      <TableRow key={supplier.id}>
                        <TableCell className="text-xs">{supplier.name}</TableCell>
                        <TableCell className={`text-xs ${supplier.balance < 0 ? 'text-red-600' : 'text-green-600'}`}>
                          ₹{Math.abs(supplier.balance).toLocaleString()}
                        </TableCell>
                        <TableCell className="text-xs">
                          <span className={supplier.status === 'Active' ? 'text-green-600' : 'text-red-600'}>
                            {supplier.status}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};