import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart3, TrendingUp, Package, Users, Calendar, Filter, Download } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface AnalyticsData {
  revenue_trends: { period: string; revenue: number; growth: number }[];
  top_products: { name: string; sales: number; revenue: number; profit: number }[];
  customer_insights: { metric: string; value: number; change: number }[];
  inventory_turnover: { product: string; turnover_rate: number; days_to_sell: number; status: string }[];
  seasonal_analysis: { season: string; revenue: number; top_category: string; growth: number }[];
}

const AnalyticsDashboard = () => {
  const { toast } = useToast();
  const [selectedPeriod, setSelectedPeriod] = useState('monthly');
  
  // Empty analytics data - will be populated from actual database queries
  const analyticsData: AnalyticsData = {
    revenue_trends: [],
    top_products: [],
    customer_insights: [],
    inventory_turnover: [],
    seasonal_analysis: []
  };

  const handleExportData = (type: string) => {
    toast({
      title: "Export Started",
      description: `${type} analytics data is being prepared for download`,
    });
  };

  const getGrowthBadge = (growth: number) => {
    if (growth > 5) return <Badge className="bg-green-100 text-green-800 text-xs">+{growth}%</Badge>;
    if (growth > 0) return <Badge className="bg-blue-100 text-blue-800 text-xs">+{growth}%</Badge>;
    return <Badge className="bg-red-100 text-red-800 text-xs">{growth}%</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      excellent: "bg-green-100 text-green-800",
      good: "bg-blue-100 text-blue-800",
      average: "bg-yellow-100 text-yellow-800",
      slow: "bg-red-100 text-red-800"
    };
    
    return <Badge className={`${colors[status as keyof typeof colors]} text-xs`}>{status}</Badge>;
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <BarChart3 className="h-4 w-4" />
          Business Analytics Dashboard
        </h2>
        <div className="flex gap-2">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-32 h-7 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="yearly">Yearly</SelectItem>
            </SelectContent>
          </Select>
          <Button size="sm" variant="outline" onClick={() => handleExportData('All')}>
            <Download className="h-3 w-3 mr-1" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-4 gap-2">
        {analyticsData.customer_insights.length === 0 ? (
          <div className="col-span-4 text-center py-8 text-muted-foreground text-sm">
            No analytics data available. Data will appear once you have sales.
          </div>
        ) : (
          analyticsData.customer_insights.map((insight, idx) => (
            <Card key={idx}>
              <CardContent className="p-2">
                <div className="text-center">
                  <div className="text-lg font-bold">
                    {insight.metric.includes('Average') ? `KES ${insight.value.toLocaleString()}` : 
                     insight.metric.includes('Retention') ? `${insight.value}%` : insight.value}
                  </div>
                  <div className="text-xs text-muted-foreground">{insight.metric}</div>
                  <div className="mt-1">
                    {getGrowthBadge(insight.change)}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Revenue Trends */}
      <Card>
        <CardHeader className="p-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="h-3 w-3" />
            Revenue Trends Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="p-2">
          <div className="overflow-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs h-6">Period</TableHead>
                  <TableHead className="text-xs h-6">Revenue (KES)</TableHead>
                  <TableHead className="text-xs h-6">Growth Rate</TableHead>
                  <TableHead className="text-xs h-6">Trend</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {analyticsData.revenue_trends.map((trend, idx) => (
                  <TableRow key={idx}>
                    <TableCell className="text-xs font-medium">{trend.period}</TableCell>
                    <TableCell className="text-xs">KES {trend.revenue.toLocaleString()}</TableCell>
                    <TableCell className="text-xs">{getGrowthBadge(trend.growth)}</TableCell>
                    <TableCell className="text-xs">
                      <TrendingUp className={`h-3 w-3 inline ${trend.growth > 0 ? 'text-green-600' : 'text-red-600'}`} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        {/* Top Performing Products */}
        <Card>
          <CardHeader className="p-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Package className="h-3 w-3" />
              Top Performing Products
            </CardTitle>
          </CardHeader>
          <CardContent className="p-2">
            <div className="overflow-auto max-h-64">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs h-6">Product</TableHead>
                    <TableHead className="text-xs h-6">Sales</TableHead>
                    <TableHead className="text-xs h-6">Revenue</TableHead>
                    <TableHead className="text-xs h-6">Profit</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {analyticsData.top_products.map((product, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="text-xs font-medium">{product.name}</TableCell>
                      <TableCell className="text-xs">{product.sales}</TableCell>
                      <TableCell className="text-xs">KES {product.revenue.toLocaleString()}</TableCell>
                      <TableCell className="text-xs text-green-600">KES {product.profit.toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Inventory Turnover */}
        <Card>
          <CardHeader className="p-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Package className="h-3 w-3" />
              Inventory Turnover Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="p-2">
            <div className="overflow-auto max-h-64">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs h-6">Category</TableHead>
                    <TableHead className="text-xs h-6">Turnover Rate</TableHead>
                    <TableHead className="text-xs h-6">Days to Sell</TableHead>
                    <TableHead className="text-xs h-6">Performance</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {analyticsData.inventory_turnover.map((item, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="text-xs font-medium">{item.product}</TableCell>
                      <TableCell className="text-xs">{item.turnover_rate}x</TableCell>
                      <TableCell className="text-xs">{item.days_to_sell} days</TableCell>
                      <TableCell className="text-xs">
                        {getStatusBadge(item.status)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Seasonal Analysis */}
      <Card>
        <CardHeader className="p-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Calendar className="h-3 w-3" />
            Seasonal Analysis & Insights
          </CardTitle>
        </CardHeader>
        <CardContent className="p-2">
          <div className="overflow-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs h-6">Season/Quarter</TableHead>
                  <TableHead className="text-xs h-6">Revenue (KES)</TableHead>
                  <TableHead className="text-xs h-6">Top Category</TableHead>
                  <TableHead className="text-xs h-6">Growth Rate</TableHead>
                  <TableHead className="text-xs h-6">Performance</TableHead>
                  <TableHead className="text-xs h-6">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {analyticsData.seasonal_analysis.map((season, idx) => (
                  <TableRow key={idx}>
                    <TableCell className="text-xs font-medium">{season.season}</TableCell>
                    <TableCell className="text-xs">KES {season.revenue.toLocaleString()}</TableCell>
                    <TableCell className="text-xs">
                      <Badge variant="outline" className="text-xs">{season.top_category}</Badge>
                    </TableCell>
                    <TableCell className="text-xs">{getGrowthBadge(season.growth)}</TableCell>
                    <TableCell className="text-xs">
                      {season.growth > 8 ? 
                        <Badge className="bg-green-100 text-green-800 text-xs">Excellent</Badge> :
                        season.growth > 5 ?
                        <Badge className="bg-blue-100 text-blue-800 text-xs">Good</Badge> :
                        <Badge className="bg-yellow-100 text-yellow-800 text-xs">Average</Badge>
                      }
                    </TableCell>
                    <TableCell>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => handleExportData(season.season)}
                        className="h-5 text-xs px-1"
                      >
                        <Download className="h-2 w-2" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Performance Summary */}
      <Card>
        <CardHeader className="p-2">
          <CardTitle className="text-sm">Key Business Insights</CardTitle>
        </CardHeader>
        <CardContent className="p-2">
          <div className="grid grid-cols-3 gap-4 text-xs">
            <div className="bg-green-50 p-2 rounded">
              <div className="font-medium text-green-800">Best Performing</div>
              <div className="text-green-600">Beverages category with 12.5x turnover rate</div>
            </div>
            <div className="bg-yellow-50 p-2 rounded">
              <div className="font-medium text-yellow-800">Needs Attention</div>
              <div className="text-yellow-600">Personal Care items with slow turnover</div>
            </div>
            <div className="bg-blue-50 p-2 rounded">
              <div className="font-medium text-blue-800">Growth Opportunity</div>
              <div className="text-blue-600">Q2 showing strongest revenue growth</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AnalyticsDashboard;