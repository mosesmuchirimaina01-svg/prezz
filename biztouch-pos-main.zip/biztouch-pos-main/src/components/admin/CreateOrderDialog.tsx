import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Trash2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface Supplier {
  id: string;
  name: string;
  contact_person: string;
  phone: string;
}

interface Product {
  id: string;
  name: string;
  code: string;
  cost_price: number;
}

interface OrderItem {
  product_id: string;
  product_name: string;
  product_code: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

interface CreateOrderDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export const CreateOrderDialog: React.FC<CreateOrderDialogProps> = ({
  open,
  onOpenChange,
  onSuccess
}) => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedSupplierId, setSelectedSupplierId] = useState('');
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unitPrice, setUnitPrice] = useState('');
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [expectedDelivery, setExpectedDelivery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingSuppliers, setLoadingSuppliers] = useState(true);
  const [loadingProducts, setLoadingProducts] = useState(false);
  
  const { toast } = useToast();
  const { selectedCompany } = useAuth();

  useEffect(() => {
    if (open) {
      fetchSuppliers();
    }
  }, [open]);

  useEffect(() => {
    if (selectedSupplierId) {
      fetchProductsForSupplier();
    } else {
      setProducts([]);
    }
  }, [selectedSupplierId]);

  const fetchSuppliers = async () => {
    try {
      setLoadingSuppliers(true);
      
      // Get current user's company_id from profile
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
      const { data: profile } = await supabase
        .from('profiles')
        .select('company_id')
        .eq('user_id', user.id)
        .single();
      
      if (!profile?.company_id) return;
      
      const { data, error } = await supabase
        .from('suppliers')
        .select('id, name, contact_person, phone')
        .eq('company_id', profile.company_id)
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setSuppliers(data || []);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch suppliers",
        variant: "destructive",
      });
    } finally {
      setLoadingSuppliers(false);
    }
  };

  const fetchProductsForSupplier = async () => {
    try {
      setLoadingProducts(true);
      
      // Fetch ALL active products from inventory for the company
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
      const { data: profile } = await supabase
        .from('profiles')
        .select('company_id')
        .eq('user_id', user.id)
        .single();
      
      if (!profile?.company_id) return;

      const { data, error } = await supabase
        .from('products')
        .select('id, name, code, cost_price')
        .eq('company_id', profile.company_id)
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast({
        title: "Error",
        description: "Failed to load products",
        variant: "destructive",
      });
    } finally {
      setLoadingProducts(false);
    }
  };

  const addOrderItem = () => {
    const product = products.find(p => p.id === selectedProductId);
    if (!product || !quantity || !unitPrice) {
      toast({
        title: "Error",
        description: "Please select a product and enter quantity and unit price",
        variant: "destructive",
      });
      return;
    }

    const quantityNum = parseInt(quantity);
    const unitPriceNum = parseFloat(unitPrice);

    if (isNaN(quantityNum) || isNaN(unitPriceNum) || quantityNum <= 0 || unitPriceNum <= 0) {
      toast({
        title: "Error",
        description: "Please enter valid quantity and unit price",
        variant: "destructive",
      });
      return;
    }

    const newItem: OrderItem = {
      product_id: product.id,
      product_name: product.name,
      product_code: product.code,
      quantity: quantityNum,
      unit_price: unitPriceNum,
      total_price: quantityNum * unitPriceNum
    };

    setOrderItems(prev => [...prev, newItem]);
    setSelectedProductId('');
    setQuantity('');
    setUnitPrice('');
  };

  const removeOrderItem = (index: number) => {
    setOrderItems(prev => prev.filter((_, i) => i !== index));
  };

  const totalAmount = orderItems.reduce((sum, item) => sum + item.total_price, 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (!selectedSupplierId || orderItems.length === 0) {
        throw new Error('Please select a supplier and add at least one item');
      }

      if (!selectedCompany?.id) throw new Error('No company selected');

      // Create purchase order
      const { data: orderData, error: orderError } = await supabase
        .from('purchase_orders')
        .insert({
          supplier_id: selectedSupplierId,
          total_amount: totalAmount,
          expected_delivery: expectedDelivery || null,
          status: 'pending',
          company_id: selectedCompany.id
        })
        .select()
        .single();

      if (orderError) throw orderError;

      // Create order items
      const orderItemsData = orderItems.map(item => ({
        order_id: orderData.id,
        product_id: item.product_id,
        quantity: item.quantity,
        unit_price: item.unit_price,
        total_price: item.total_price
      }));

      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItemsData);

      if (itemsError) throw itemsError;

      toast({
        title: "Success",
        description: `Purchase order ${orderData.order_number} created successfully`,
      });

      // Reset form
      setSelectedSupplierId('');
      setOrderItems([]);
      setExpectedDelivery('');
      
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      console.error('Error creating order:', error);
      toast({
        title: "Error",
        description: "Failed to create purchase order",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setSelectedSupplierId('');
    setOrderItems([]);
    setExpectedDelivery('');
    setSelectedProductId('');
    setQuantity('');
    setUnitPrice('');
    onOpenChange(false);
  };

  const selectedProduct = products.find(p => p.id === selectedProductId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Purchase Order</DialogTitle>
          <DialogDescription>
            Choose supplier and add items to create a new purchase order.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Supplier Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Supplier Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="supplier-select">Select Supplier</Label>
                {loadingSuppliers ? (
                  <div className="text-sm text-muted-foreground">Loading suppliers...</div>
                ) : (
                  <Select value={selectedSupplierId} onValueChange={setSelectedSupplierId} required>
                    <SelectTrigger id="supplier-select">
                      <SelectValue placeholder="Choose a supplier..." />
                    </SelectTrigger>
                    <SelectContent>
                      {suppliers.map((supplier) => (
                        <SelectItem key={supplier.id} value={supplier.id}>
                          {supplier.name} - {supplier.contact_person} ({supplier.phone})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="expected-delivery">Expected Delivery Date</Label>
                <Input
                  id="expected-delivery"
                  type="date"
                  value={expectedDelivery}
                  onChange={(e) => setExpectedDelivery(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Add Items */}
          {selectedSupplierId && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Add Items</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="product-select">Product</Label>
                    {loadingProducts ? (
                      <div className="text-sm text-muted-foreground">Loading...</div>
                    ) : (
                      <Select value={selectedProductId} onValueChange={(value) => {
                        setSelectedProductId(value);
                        const product = products.find(p => p.id === value);
                        if (product) {
                          setUnitPrice(product.cost_price?.toString() || '');
                        }
                      }}>
                        <SelectTrigger id="product-select">
                          <SelectValue placeholder="Choose product..." />
                        </SelectTrigger>
                        <SelectContent>
                          {products.map((product) => (
                            <SelectItem key={product.id} value={product.id}>
                              {product.code} - {product.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantity</Label>
                    <Input
                      id="quantity"
                      type="number"
                      min="1"
                      placeholder="Qty"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="unit-price">Unit Price</Label>
                    <Input
                      id="unit-price"
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      value={unitPrice}
                      onChange={(e) => setUnitPrice(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>&nbsp;</Label>
                    <Button 
                      type="button" 
                      onClick={addOrderItem}
                      disabled={!selectedProductId || !quantity || !unitPrice}
                      className="w-full"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Item
                    </Button>
                  </div>
                </div>

                {selectedProduct && (
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="text-sm">
                      <strong>Cost Price:</strong> ₹{selectedProduct.cost_price || 0}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Order Items */}
          {orderItems.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Order Items</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product Code</TableHead>
                      <TableHead>Product Name</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Unit Price</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orderItems.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-mono">{item.product_code}</TableCell>
                        <TableCell>{item.product_name}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>₹{item.unit_price.toFixed(2)}</TableCell>
                        <TableCell>₹{item.total_price.toFixed(2)}</TableCell>
                        <TableCell>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => removeOrderItem(index)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                <div className="mt-4 flex justify-end">
                  <div className="text-lg font-semibold">
                    Total Amount: ₹{totalAmount.toFixed(2)}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isLoading || !selectedSupplierId || orderItems.length === 0}
            >
              {isLoading ? "Creating..." : "Create Order"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};