import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Edit, Plus, Trash2, Package, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface Product {
  id: string;
  name: string;
  code: string;
  price: number;
  cost_price: number | null;
  stock_quantity: number;
  min_stock_level: number | null;
  is_active: boolean;
  blocked_from_selling: boolean;
  categories?: { name: string };
}

interface Category {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
}

export const CatalogueStockEdit: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editForm, setEditForm] = useState({
    name: '',
    code: '',
    price: '',
    cost_price: '',
    stock_quantity: '',
    min_stock_level: '',
    category_id: '',
    is_active: true,
    blocked_from_selling: false
  });
  const { toast } = useToast();
  const { selectedCompany } = useAuth();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    await Promise.all([fetchProducts(), fetchCategories()]);
  };

  const fetchProducts = async () => {
    try {
      if (!selectedCompany?.id) return;

      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          categories(name)
        `)
        .eq('company_id', selectedCompany.id)
        .order('name');
      
      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast({
        title: "Error",
        description: "Failed to load products",
        variant: "destructive",
      });
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const openEditDialog = (product: Product) => {
    setSelectedProduct(product);
    setEditForm({
      name: product.name,
      code: product.code,
      price: product.price.toString(),
      cost_price: product.cost_price?.toString() || '',
      stock_quantity: product.stock_quantity.toString(),
      min_stock_level: product.min_stock_level?.toString() || '',
      category_id: '',
      is_active: product.is_active,
      blocked_from_selling: product.blocked_from_selling
    });
    setIsEditDialogOpen(true);
  };

  const updateProduct = async () => {
    if (!selectedProduct) return;

    try {
      const { error } = await supabase
        .from('products')
        .update({
          name: editForm.name,
          code: editForm.code,
          price: parseFloat(editForm.price),
          cost_price: editForm.cost_price ? parseFloat(editForm.cost_price) : null,
          stock_quantity: parseInt(editForm.stock_quantity),
          min_stock_level: editForm.min_stock_level ? parseInt(editForm.min_stock_level) : null,
          is_active: editForm.is_active,
          blocked_from_selling: editForm.blocked_from_selling
        })
        .eq('id', selectedProduct.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Product updated successfully",
      });

      setIsEditDialogOpen(false);
      fetchProducts();
    } catch (error) {
      console.error('Error updating product:', error);
      toast({
        title: "Error",
        description: "Failed to update product",
        variant: "destructive",
      });
    }
  };

  const addProduct = async () => {
    try {
      if (!selectedCompany?.id) {
        toast({
          title: "Error",
          description: "Please select a company first",
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from('products')
        .insert({
          name: editForm.name,
          code: editForm.code,
          price: parseFloat(editForm.price),
          cost_price: editForm.cost_price ? parseFloat(editForm.cost_price) : null,
          stock_quantity: parseInt(editForm.stock_quantity),
          min_stock_level: editForm.min_stock_level ? parseInt(editForm.min_stock_level) : null,
          category_id: editForm.category_id || null,
          is_active: editForm.is_active,
          blocked_from_selling: editForm.blocked_from_selling,
          company_id: selectedCompany.id
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Product added successfully",
      });

      setIsAddDialogOpen(false);
      setEditForm({
        name: '',
        code: '',
        price: '',
        cost_price: '',
        stock_quantity: '',
        min_stock_level: '',
        category_id: '',
        is_active: true,
        blocked_from_selling: false
      });
      fetchProducts();
    } catch (error) {
      console.error('Error adding product:', error);
      toast({
        title: "Error",
        description: "Failed to add product",
        variant: "destructive",
      });
    }
  };

  const lowStockProducts = products.filter(p => 
    p.min_stock_level && p.stock_quantity <= p.min_stock_level
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Catalogue & Stock Management</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Product
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Product</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="add-name">Product Name</Label>
                  <Input
                    id="add-name"
                    value={editForm.name}
                    onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="add-code">Product Code</Label>
                  <Input
                    id="add-code"
                    value={editForm.code}
                    onChange={(e) => setEditForm({...editForm, code: e.target.value})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="add-price">Selling Price</Label>
                  <Input
                    id="add-price"
                    type="number"
                    step="0.01"
                    value={editForm.price}
                    onChange={(e) => setEditForm({...editForm, price: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="add-cost">Cost Price</Label>
                  <Input
                    id="add-cost"
                    type="number"
                    step="0.01"
                    value={editForm.cost_price}
                    onChange={(e) => setEditForm({...editForm, cost_price: e.target.value})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="add-stock">Stock Quantity</Label>
                  <Input
                    id="add-stock"
                    type="number"
                    value={editForm.stock_quantity}
                    onChange={(e) => setEditForm({...editForm, stock_quantity: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="add-min-stock">Min Stock Level</Label>
                  <Input
                    id="add-min-stock"
                    type="number"
                    value={editForm.min_stock_level}
                    onChange={(e) => setEditForm({...editForm, min_stock_level: e.target.value})}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="add-category">Category</Label>
                <Select value={editForm.category_id} onValueChange={(value) => setEditForm({...editForm, category_id: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={addProduct}>Add Product</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Low Stock Alert */}
      {lowStockProducts.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="text-orange-800 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Low Stock Alert
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {lowStockProducts.map((product) => (
                <div key={product.id} className="flex justify-between items-center">
                  <span className="font-medium">{product.name}</span>
                  <Badge variant="destructive">
                    {product.stock_quantity} / {product.min_stock_level} remaining
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Products Inventory
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Stock</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((product) => (
                <TableRow key={product.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{product.name}</div>
                      {product.cost_price && (
                        <div className="text-sm text-gray-500">
                          Cost: KES {Number(product.cost_price).toFixed(2)}
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{product.code}</TableCell>
                  <TableCell>{product.categories?.name || '-'}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span>{product.stock_quantity}</span>
                      {product.min_stock_level && product.stock_quantity <= product.min_stock_level && (
                        <AlertTriangle className="h-4 w-4 text-orange-500" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell>KES {Number(product.price).toFixed(2)}</TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <Badge variant={product.is_active ? "default" : "secondary"}>
                        {product.is_active ? "Active" : "Inactive"}
                      </Badge>
                      {product.blocked_from_selling && (
                        <Badge variant="destructive">Blocked</Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openEditDialog(product)}
                    >
                      <Edit className="h-3 w-3" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Product Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Product</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-name">Product Name</Label>
                <Input
                  id="edit-name"
                  value={editForm.name}
                  onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit-code">Product Code</Label>
                <Input
                  id="edit-code"
                  value={editForm.code}
                  onChange={(e) => setEditForm({...editForm, code: e.target.value})}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-price">Selling Price</Label>
                <Input
                  id="edit-price"
                  type="number"
                  step="0.01"
                  value={editForm.price}
                  onChange={(e) => setEditForm({...editForm, price: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit-cost">Cost Price</Label>
                <Input
                  id="edit-cost"
                  type="number"
                  step="0.01"
                  value={editForm.cost_price}
                  onChange={(e) => setEditForm({...editForm, cost_price: e.target.value})}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-stock">Stock Quantity</Label>
                <Input
                  id="edit-stock"
                  type="number"
                  value={editForm.stock_quantity}
                  onChange={(e) => setEditForm({...editForm, stock_quantity: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit-min-stock">Min Stock Level</Label>
                <Input
                  id="edit-min-stock"
                  type="number"
                  value={editForm.min_stock_level}
                  onChange={(e) => setEditForm({...editForm, min_stock_level: e.target.value})}
                />
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="edit-active"
                checked={editForm.is_active}
                onChange={(e) => setEditForm({...editForm, is_active: e.target.checked})}
              />
              <Label htmlFor="edit-active">Active</Label>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="edit-blocked"
                checked={editForm.blocked_from_selling}
                onChange={(e) => setEditForm({...editForm, blocked_from_selling: e.target.checked})}
              />
              <Label htmlFor="edit-blocked">Blocked from selling</Label>
            </div>
            <Button onClick={updateProduct}>Update Product</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};