import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface SupervisorPasswordDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  action: string;
}

export const SupervisorPasswordDialog: React.FC<SupervisorPasswordDialogProps> = ({
  open,
  onOpenChange,
  onSuccess,
  action
}) => {
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Get supervisor password from system settings
      const { data: settings, error } = await supabase
        .from('system_settings')
        .select('value')
        .eq('key', 'supervisor_password')
        .single();

      if (error) {
        throw error;
      }

      if (password === settings.value) {
        toast({
          title: "Access Granted",
          description: `You can now ${action.toLowerCase()}.`,
        });
        onSuccess();
        onOpenChange(false);
        setPassword('');
      } else {
        toast({
          title: "Access Denied",
          description: "Invalid supervisor password.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error verifying password:', error);
      toast({
        title: "Error",
        description: "Failed to verify supervisor password.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Supervisor Authorization Required</DialogTitle>
          <DialogDescription>
            Please enter the supervisor password to {action.toLowerCase()}.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="supervisor-password">Supervisor Password</Label>
            <Input
              id="supervisor-password"
              type="password"
              placeholder="Enter supervisor password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          
          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Verifying..." : "Authorize"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};