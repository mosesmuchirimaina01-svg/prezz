import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertCircle, Wifi, WifiOff, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const CURRENT_VERSION = "0.1";

interface UpdateCheckProps {
  className?: string;
}

interface VersionInfo {
  version: string;
  releaseNotes?: string;
  notesUrl?: string;
  description?: string;
}

export function UpdateCheck({ className }: UpdateCheckProps) {
  const [isChecking, setIsChecking] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const [updateStatus, setUpdateStatus] = useState<{
    hasUpdate: boolean;
    latest?: VersionInfo;
    error?: string;
  } | null>(null);
  const { toast } = useToast();

  const checkForUpdates = async () => {
    setIsChecking(true);
    setShowDialog(true);
    
    try {
      // Simulate checking for updates - replace with actual version endpoint
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Try to fetch from version endpoint
      try {
        const response = await fetch('/version.json');
        if (response.ok) {
          const versionData: VersionInfo = await response.json();
          const hasUpdate = versionData.version !== CURRENT_VERSION;
          setUpdateStatus({
            hasUpdate,
            latest: versionData
          });
        } else {
          throw new Error('Version endpoint not available');
        }
      } catch (fetchError) {
        // Fallback - simulate no updates available
        setUpdateStatus({
          hasUpdate: false,
          latest: {
            version: CURRENT_VERSION,
            description: "Current version is up to date"
          }
        });
      }
    } catch (error) {
      setUpdateStatus({
        hasUpdate: false,
        error: "Couldn't check for updates. You're on v" + CURRENT_VERSION
      });
    } finally {
      setIsChecking(false);
    }
  };

  const renderDialogContent = () => {
    if (isChecking) {
      return (
        <>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Wifi className="h-4 w-4 animate-pulse" />
              Checking for Updates...
            </DialogTitle>
            <DialogDescription>
              Connecting to update server...
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          </div>
        </>
      );
    }

    if (updateStatus?.error) {
      return (
        <>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <WifiOff className="h-4 w-4 text-muted-foreground" />
              Update Check Failed
            </DialogTitle>
            <DialogDescription>
              {updateStatus.error}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="flex items-center justify-center gap-2 p-4 bg-muted/50 rounded-lg">
              <Badge variant="outline">Current: v{CURRENT_VERSION}</Badge>
            </div>
          </div>
        </>
      );
    }

    if (updateStatus?.hasUpdate && updateStatus.latest) {
      return (
        <>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-blue-500" />
              New Version Available
            </DialogTitle>
            <DialogDescription>
              A newer version of the system is available for download.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div>
                <div className="font-medium">Current Version</div>
                <Badge variant="outline">v{CURRENT_VERSION}</Badge>
              </div>
              <div className="text-right">
                <div className="font-medium">Latest Version</div>
                <Badge className="bg-blue-500">v{updateStatus.latest.version}</Badge>
              </div>
            </div>
            {updateStatus.latest.description && (
              <div className="p-3 bg-muted/50 rounded-md">
                <p className="text-sm text-muted-foreground">
                  {updateStatus.latest.description}
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            {updateStatus.latest.notesUrl && (
              <Button variant="outline" asChild>
                <a href={updateStatus.latest.notesUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Release Notes
                </a>
              </Button>
            )}
            <Button onClick={() => setShowDialog(false)}>
              Got It
            </Button>
          </DialogFooter>
        </>
      );
    }

    // Up to date
    return (
      <>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-500" />
            You're Up to Date
          </DialogTitle>
          <DialogDescription>
            You're running the latest version of the system.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <div className="flex items-center justify-center gap-2 p-4 bg-green-50 rounded-lg border border-green-200">
            <Badge className="bg-green-500">v{CURRENT_VERSION}</Badge>
            <span className="text-sm text-green-700">Latest Version</span>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={() => setShowDialog(false)}>
            Close
          </Button>
        </DialogFooter>
      </>
    );
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={checkForUpdates}
        disabled={isChecking}
        className={className}
      >
        {isChecking ? (
          <>
            <div className="animate-spin rounded-full h-3 w-3 border-b border-current mr-2"></div>
            Checking...
          </>
        ) : (
          `Check for Updates — v${CURRENT_VERSION}`
        )}
      </Button>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-md">
          {renderDialogContent()}
        </DialogContent>
      </Dialog>
    </>
  );
}