import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface Column<T> {
  key: keyof T | string;
  header: string | React.ReactNode;
  cell?: (item: T) => React.ReactNode;
  className?: string;
  sortable?: boolean;
}

interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  className?: string;
  maxHeight?: string;
  stickyHeader?: boolean;
  striped?: boolean;
  hover?: boolean;
  compact?: boolean;
  emptyMessage?: string;
}

export function DataTable<T extends Record<string, any>>({
  data,
  columns,
  className,
  maxHeight = "500px",
  stickyHeader = true,
  striped = true,
  hover = true,
  compact = false,
  emptyMessage = "No data available"
}: DataTableProps<T>) {
  const getValue = (item: T, key: keyof T | string): any => {
    if (typeof key === 'string' && key.includes('.')) {
      // Handle nested properties like 'user.name'
      return key.split('.').reduce((obj, k) => obj?.[k], item);
    }
    return item[key as keyof T];
  };

  const tableContent = (
    <Table className={cn("w-full", className)}>
      <TableHeader className={stickyHeader ? "sticky top-0 z-10 bg-background" : ""}>
        <TableRow className="border-b bg-muted/50">
          {columns.map((column, index) => (
            <TableHead
              key={index}
              className={cn(
                "font-semibold text-foreground",
                compact ? "px-2 py-2 text-xs" : "px-4 py-3 text-sm",
                column.className
              )}
            >
              {column.header}
            </TableHead>
          ))}
        </TableRow>
      </TableHeader>
      <TableBody>
        {data.length === 0 ? (
          <TableRow>
            <TableCell
              colSpan={columns.length}
              className="text-center py-8 text-muted-foreground"
            >
              {emptyMessage}
            </TableCell>
          </TableRow>
        ) : (
          data.map((item, rowIndex) => (
            <TableRow
              key={rowIndex}
              className={cn(
                "border-b",
                striped && rowIndex % 2 === 0 && "bg-muted/25",
                hover && "hover:bg-muted/50 transition-colors"
              )}
            >
              {columns.map((column, colIndex) => (
                <TableCell
                  key={colIndex}
                  className={cn(
                    compact ? "px-2 py-1.5 text-xs" : "px-4 py-2.5 text-sm",
                    column.className
                  )}
                >
                  {column.cell
                    ? column.cell(item)
                    : String(getValue(item, column.key) || '-')
                  }
                </TableCell>
              ))}
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  );

  if (maxHeight && stickyHeader) {
    return (
      <div
        className={cn(
          "rounded-lg border bg-card shadow-sm overflow-hidden",
          className
        )}
        style={{ maxHeight }}
      >
        <ScrollArea className="h-full">
          {tableContent}
        </ScrollArea>
      </div>
    );
  }

  return (
    <div className={cn("rounded-lg border bg-card shadow-sm overflow-auto", className)}>
      {tableContent}
    </div>
  );
}