import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface ExpenseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  authorizedBy?: string;
}

export const ExpenseDialog: React.FC<ExpenseDialogProps> = ({
  open,
  onOpenChange,
  onSuccess,
  authorizedBy
}) => {
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [description, setDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { profile, selectedCompany } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    setIsLoading(true);

    try {
      if (!selectedCompany?.id) {
        toast({
          title: "Error",
          description: "Please select a company first",
          variant: "destructive",
        });
        return;
      }

      // Get current open shift
      const { data: shift } = await supabase
        .from('shifts')
        .select('id')
        .eq('cashier_id', profile.id)
        .eq('status', 'open')
        .single();

      const { error } = await supabase
        .from('expenses')
        .insert({
          cashier_id: profile.id,
          authorized_by: authorizedBy || profile.id,
          shift_id: shift?.id,
          amount: parseFloat(amount),
          reason,
          description,
          company_id: selectedCompany.id
        });

      if (error) throw error;

      toast({
        title: "Expense Recorded",
        description: `Expense of KES ${amount} has been recorded.`,
      });

      onSuccess();
      onOpenChange(false);
      
      // Reset form
      setAmount('');
      setReason('');
      setDescription('');
    } catch (error) {
      console.error('Error recording expense:', error);
      toast({
        title: "Error",
        description: "Failed to record expense.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const predefinedReasons = [
    'Office Supplies',
    'Maintenance',
    'Utilities',
    'Petty Cash',
    'Emergency Repair',
    'Other'
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Record Expense</DialogTitle>
          <DialogDescription>
            Enter the details of the expense to be recorded.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="amount">Amount (KES)</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
              autoComplete="off"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="reason">Reason</Label>
            <Input
              id="reason"
              placeholder="What is this expense for?"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              autoComplete="off"
            />
            <div className="flex flex-wrap gap-1 mt-2">
              {predefinedReasons.map((predefinedReason) => (
                <Button
                  key={predefinedReason}
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setReason(predefinedReason)}
                  className="text-xs"
                >
                  {predefinedReason}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              placeholder="Additional details about the expense"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>
          
          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Recording..." : "Record Expense"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};