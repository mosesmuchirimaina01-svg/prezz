import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Building2, Database } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface CompanySelectorProps {
  onCompanySelect: (companyId: string) => void;
  selectedCompanyId?: string;
}

export const CompanySelector: React.FC<CompanySelectorProps> = ({ 
  onCompanySelect, 
  selectedCompanyId 
}) => {
  const { companies } = useAuth();

  if (companies.length === 0) {
    return (
      <Card className="w-full max-w-md">
        <CardContent className="p-4 text-center">
          <p className="text-sm text-muted-foreground">No active companies available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Building2 className="h-4 w-4" />
          Select Company Database
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Choose which company's POS system to access
        </p>
      </CardHeader>
      <CardContent className="space-y-2">
        {companies.map((company) => (
          <div
            key={company.id}
            className={`border rounded-lg p-3 cursor-pointer transition-colors hover:bg-muted/50 ${
              selectedCompanyId === company.id 
                ? 'border-primary bg-primary/5' 
                : 'border-border'
            }`}
            onClick={() => onCompanySelect(company.id)}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h4 className="text-sm font-medium">{company.name}</h4>
                <div className="flex items-center gap-1 mt-1">
                  <Database className="h-3 w-3 text-muted-foreground" />
                  <code className="text-xs bg-muted px-1 rounded">
                    {company.database_name}
                  </code>
                </div>
              </div>
              <Badge 
                variant={company.status === 'active' ? 'default' : 'secondary'}
                className="text-xs"
              >
                {company.status}
              </Badge>
            </div>
          </div>
        ))}
        
        <div className="pt-2 border-t">
          <p className="text-xs text-muted-foreground text-center">
            Each company has its own isolated database and data
          </p>
        </div>
      </CardContent>
    </Card>
  );
};