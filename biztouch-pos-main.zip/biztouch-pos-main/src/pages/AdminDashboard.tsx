import { Helmet } from "react-helmet-async";
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";

const Card: React.FC<{ title: string; description: string; to: string }> = ({ title, description, to }) => (
  <Link to={to} aria-label={title} className="group">
    <article className="rounded-lg border bg-card p-6 shadow-sm transition hover:shadow-md">
      <h2 className="text-xl font-semibold">{title}</h2>
      <p className="mt-1 text-sm text-muted-foreground">{description}</p>
      <div className="mt-4">
        <Button>{title}</Button>
      </div>
    </article>
  </Link>
);

const AdminDashboard: React.FC = () => {
  const { profile, signOut } = useAuth();
  const dateStr = new Date().toLocaleString();
  const modules = [
    { label: "System Settings", slug: "system-settings" },
    { label: "Admin Settings", slug: "admin-settings" },
    { label: "Catalogue & Stock Edit", slug: "catalogue-stock-edit" },
    { label: "Expense View", slug: "expense-view" },
    { label: "Database Access", slug: "database-access" },
    { label: "Sales Report", slug: "sales-report" },
    { label: "Users & Rights", slug: "users-rights" },
    { label: "Stock Input", slug: "stock-input" },
    { label: "Open Shift", slug: "open-shift" },
    { label: "Close Shift", slug: "close-shift" },
    { label: "Price Change", slug: "price-change" },
    { label: "M-Pesa Messages", slug: "mpesa-messages" },
    { label: "Sales Analysis & Graphs", slug: "sales-analysis" },
    { label: "User Settings & Passwords", slug: "user-settings" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Helmet>
        <title>Admin Dashboard | Modern POS</title>
        <meta name="description" content="Advanced admin dashboard for Modern POS: settings, reports, users, and comprehensive management tools." />
        <link rel="canonical" href={typeof window !== 'undefined' ? window.location.href : '/admin'} />
      </Helmet>

      <header className="border-b bg-white shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-sm text-gray-600">
              {profile?.full_name} • {profile?.role?.toUpperCase()} • {dateStr}
            </p>
          </div>
          <div className="flex gap-2">
            <Link to="/cashier"><Button variant="outline">Cashier</Button></Link>
            <Link to="/backoffice"><Button variant="outline">Backoffice</Button></Link>
            <Link to="/"><Button variant="ghost">Home</Button></Link>
            <Button variant="destructive" onClick={signOut}>Logout</Button>
          </div>
        </div>
      </header>

      <main className="container py-6">
        <section aria-labelledby="modules-heading">
          <h2 id="modules-heading" className="sr-only">Admin Modules</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {modules.map((m) => (
              <Card key={m.slug} title={m.label} description="Open module" to={`/admin/${m.slug}`} />
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};

export default AdminDashboard;
