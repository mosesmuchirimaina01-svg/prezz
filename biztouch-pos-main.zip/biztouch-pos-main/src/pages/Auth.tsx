import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { CompanySelector } from '@/components/auth/CompanySelector';

const Auth = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [selectedCompanyId, setSelectedCompanyId] = useState('');
  const [showCompanySelector, setShowCompanySelector] = useState(true);
  const [showSystemPassword, setShowSystemPassword] = useState(false);
  const [systemPassword, setSystemPassword] = useState('');
  
  const { signIn, user, companies, fetchCompanies } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate('/');
    }
    fetchCompanies();
  }, [user, navigate, fetchCompanies]);

  const handleCompanySelect = (companyId: string) => {
    setSelectedCompanyId(companyId);
    setShowSystemPassword(true);
  };

  const handleSystemPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (systemPassword === '28132813') {
      setShowSystemPassword(false);
      setShowCompanySelector(false);
      toast({
        title: "System Access Granted",
        description: "You can now proceed to login.",
      });
    } else {
      toast({
        title: "Access Denied",
        description: "Invalid system password.",
        variant: "destructive",
      });
      setSystemPassword('');
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCompanyId) {
      toast({
        title: "Company Required",
        description: "Please select a company to sign in to.",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);

    // For username-based login, we need to find the user by username
    // Since we're using username instead of email, we'll use the username as email for now
    const { error } = await signIn(username + '@company.local', password, selectedCompanyId);

    if (error) {
      toast({
        title: "Sign In Failed",
        description: "Invalid username or password.",
        variant: "destructive",
      });
    } else {
      const selectedCompany = companies.find(c => c.id === selectedCompanyId);
      toast({
        title: "Welcome back!",
        description: `Signed in to ${selectedCompany?.name || 'company'} POS system.`,
      });
    }

    setIsLoading(false);
  };


  return (
    <>
      <Helmet>
        <title>GB PAWA POS - Login</title>
        <meta name="description" content="Sign in to GB PAWA POS - Professional Point of Sale System" />
      </Helmet>
      
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20 p-4">
        <div className="w-full max-w-md space-y-4">
          {/* Company Selection */}
          {showCompanySelector && !showSystemPassword && (
            <div className="space-y-4">
              <CompanySelector 
                onCompanySelect={handleCompanySelect} 
                selectedCompanyId={selectedCompanyId}
              />
            </div>
          )}

          {/* System Password */}
          {showSystemPassword && (
            <Card className="w-full">
              <CardHeader className="text-center">
                <CardTitle className="text-xl font-bold">System Access</CardTitle>
                <CardDescription>
                  Enter system password to continue
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSystemPasswordSubmit} className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="system-password" className="text-xs">System Password</Label>
                    <Input
                      id="system-password"
                      type="password"
                      placeholder="Enter system password"
                      value={systemPassword}
                      onChange={(e) => setSystemPassword(e.target.value)}
                      required
                      className="h-8 text-xs"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => {
                        setShowSystemPassword(false);
                        setSelectedCompanyId('');
                        setSystemPassword('');
                      }}
                      className="flex-1 h-8 text-xs"
                    >
                      Back
                    </Button>
                    <Button type="submit" className="flex-1 h-8 text-xs">
                      Continue
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          {/* Authentication Forms */}
          {!showCompanySelector && (
            <Card className="w-full">
              <CardHeader className="text-center">
                <CardTitle className="text-xl font-bold">GB PAWA POS</CardTitle>
                <CardDescription>
                  <span>Multi-Tenant Point of Sale System</span>
                  {selectedCompanyId && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setShowCompanySelector(true)}
                      className="text-xs mt-2"
                    >
                      Change Company
                    </Button>
                  )}
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-4">
                  <form onSubmit={handleSignIn} className="space-y-3">
                    <div className="space-y-2">
                      <Label htmlFor="signin-username" className="text-xs">Username</Label>
                      <Input
                        id="signin-username"
                        type="text"
                        placeholder="Enter your username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                        className="h-8 text-xs"
                        autoComplete="off"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="signin-password" className="text-xs">Password</Label>
                      <Input
                        id="signin-password"
                        type="password"
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="h-8 text-xs"
                        autoComplete="off"
                      />
                    </div>
                    
                    <Button type="submit" className="w-full h-8 text-xs" disabled={isLoading}>
                      {isLoading ? "Signing in..." : "Sign In"}
                    </Button>
                  </form>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </>
  );
};

export default Auth;