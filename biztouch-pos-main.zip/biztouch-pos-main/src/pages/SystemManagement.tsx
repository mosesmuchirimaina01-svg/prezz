import React from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CompanyManagement } from "@/components/system/CompanyManagement";
import { ArrowLeft } from "lucide-react";

const SystemManagement: React.FC = () => {
  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      <Helmet>
        <title>GB PAWA POS - System Management</title>
        <meta name="description" content="GB PAWA POS System Management Dashboard" />
      </Helmet>

      {/* Header */}
      <header className="bg-yellow-50 border-b p-2 shrink-0">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold">GB PAWA POS - System Management</h1>
            <p className="text-sm text-muted-foreground">
              Multi-Company Management Dashboard • {new Date().toLocaleDateString()}
            </p>
          </div>
          <div className="flex gap-1">
            <Button size="sm" variant="outline" asChild>
              <Link to="/">
                <ArrowLeft className="h-3 w-3 mr-1" />
                Home
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full p-4 overflow-auto">
          <CompanyManagement />
        </div>
      </div>
    </div>
  );
};

export default SystemManagement;