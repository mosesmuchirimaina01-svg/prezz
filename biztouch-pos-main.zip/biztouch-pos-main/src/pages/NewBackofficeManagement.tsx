import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UpdateCheck } from "@/components/ui/update-check";

// Backoffice components
import { StockInput } from "@/components/admin/StockInput";
import { SystemSettings } from "@/components/admin/SystemSettings";
import { InventoryManagement } from "@/components/admin/InventoryManagement";
import { SupplierManagement } from "@/components/admin/SupplierManagement";
import { OrderManagement } from "@/components/admin/OrderManagement";
import { StockAdjustments } from "@/components/admin/StockAdjustments";
import { StockMovements } from "@/components/admin/StockMovements";
import { AddStock } from "@/components/admin/AddStock";
import { BackofficeReports } from "@/components/admin/BackofficeReports";
import { SalesReports as AdminSalesReports } from "@/components/admin/SalesReports";
import AnalyticsDashboard from "@/components/admin/AnalyticsDashboard";
import { AdminUserManagement } from "@/components/admin/AdminUserManagement";
import { CompanyHeader } from "@/components/shared/CompanyHeader";
import { PriceChangeManagement } from "@/components/backoffice/PriceChangeManagement";
import { SupplierManagement as BackofficeSupplierManagement } from "@/components/backoffice/SupplierManagement";

const StockAdjustment = () => (
  <div className="space-y-4">
    <h2 className="text-2xl font-bold">Stock Adjustment</h2>
    <p className="text-muted-foreground">Adjust stock levels based on physical counts and reconciliation.</p>
    <StockInput />
  </div>
);


const Orders = () => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div>
        <OrderManagement />
      </div>
      <div>
        <SupplierManagement />
      </div>
    </div>
  </div>
);





const NewBackofficeManagement: React.FC = () => {
  const { profile, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState("inventory");

  const backofficeModules = [
    { id: "inventory", label: "Inventory", component: InventoryManagement },
    { id: "stock-adjustment", label: "Adjustments", component: StockAdjustment },
    { id: "orders", label: "Orders", component: Orders },
    { id: "suppliers", label: "Suppliers", component: BackofficeSupplierManagement },
    { id: "price-change", label: "Price Change", component: PriceChangeManagement },
    { id: "stock-movement", label: "Movements", component: StockMovements },
    { id: "new-stock", label: "Add Stock", component: AddStock },
    { id: "sales-reports", label: "Reports", component: AdminSalesReports },
    { id: "users", label: "Users", component: AdminUserManagement },
    { id: "analytics", label: "Analytics", component: AnalyticsDashboard },
    { id: "settings", label: "Settings", component: SystemSettings },
  ];

  const ActiveComponent = backofficeModules.find(module => module.id === activeTab)?.component || InventoryManagement;

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      <Helmet>
        <title>GB PAWA POS - Backoffice</title>
        <meta name="description" content="GB PAWA POS Backoffice Management System" />
      </Helmet>

      {/* Header */}
      <header className="shrink-0">
        <CompanyHeader title="GB PAWA POS - Backoffice" />
        <div className="border-b p-2 flex items-center justify-end gap-1">
          <UpdateCheck />
          <Button size="sm" variant="outline" asChild>
            <Link to="/cashier">Cashier</Link>
          </Button>
          <Button size="sm" variant="outline" asChild>
            <Link to="/cashier">Sales</Link>
          </Button>
          <Button size="sm" variant="destructive" onClick={signOut}>
            Logout
          </Button>
        </div>
      </header>

      {/* Backoffice modules navigation with blue background */}
      <div className="bg-blue-500 text-white shrink-0">
        <div className="p-2">
          <div className="flex flex-wrap gap-1">
            {backofficeModules.map((module) => (
              <Button
                key={module.id}
                size="sm"
                variant={activeTab === module.id ? "secondary" : "ghost"}
                onClick={() => setActiveTab(module.id)}
                className={`${
                  activeTab === module.id 
                    ? "bg-white text-blue-500" 
                    : "text-white hover:bg-blue-600"
                }`}
              >
                {module.label}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Main content area */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full p-4 overflow-auto">
          <ActiveComponent />
        </div>
      </div>
    </div>
  );
};

export default NewBackofficeManagement;