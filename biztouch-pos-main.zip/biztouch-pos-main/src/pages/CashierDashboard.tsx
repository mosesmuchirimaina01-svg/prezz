import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Scan, Search, Plus, Trash2, Calculator, Users, Clock, Receipt, Banknote, Pause } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { PaymentDialog } from "@/components/PaymentDialog";
import { SupervisorPasswordDialog } from "@/components/SupervisorPasswordDialog";
import { ExpenseDialog } from "@/components/ExpenseDialog";

type Row = {
  id: string;
  itemName: string;
  itemId?: string;
  code?: string;
  price: number;
  qty: number;
  selected?: boolean;
};

type Product = {
  id: string;
  code: string;
  name: string;
  price: number;
  stock_quantity: number;
  is_active: boolean;
  blocked_from_selling: boolean;
};

type Shift = {
  id: string;
  status: 'open' | 'closed';
  opening_cash: number;
  cashier_id: string;
  opened_at: string;
};

const newRow = (): Row => ({ id: crypto.randomUUID(), itemName: "", price: 0, qty: 1, selected: false });

const CashierDashboard: React.FC = () => {
  const { user, profile, signOut } = useAuth();
  const { toast } = useToast();
  const [rows, setRows] = useState<Row[]>([newRow()]);
  const [products, setProducts] = useState<Product[]>([]);
  const [currentShift, setCurrentShift] = useState<Shift | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [barcodeInput, setBarcodeInput] = useState("");
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showSupervisorDialog, setShowSupervisorDialog] = useState(false);
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);
  const [supervisorAction, setSupervisorAction] = useState("");
  const [todaysSales, setTodaysSales] = useState(0);
  const [todaysTransactions, setTodaysTransactions] = useState(0);
  
  const total = rows.reduce((sum, r) => sum + r.price * r.qty, 0);
  const dateStr = new Date().toLocaleDateString();
  const timeStr = new Date().toLocaleTimeString();

  // Fetch products and current shift on mount
  useEffect(() => {
    fetchProducts();
    fetchCurrentShift();
    fetchTodaysSummary();
  }, [profile]);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast({
        title: "Error",
        description: "Failed to load products",
        variant: "destructive",
      });
    }
  };

  const fetchCurrentShift = async () => {
    if (!profile) return;
    
    try {
      const { data, error } = await supabase
        .from('shifts')
        .select('*')
        .eq('cashier_id', profile.id)
        .eq('status', 'open')
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      setCurrentShift(data);
    } catch (error) {
      console.error('Error fetching shift:', error);
    }
  };

  const fetchTodaysSummary = async () => {
    if (!profile) return;
    
    try {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('sales')
        .select('total_amount')
        .eq('cashier_id', profile.id)
        .gte('created_at', `${today}T00:00:00`)
        .lte('created_at', `${today}T23:59:59`);
      
      if (error) throw error;
      
      const totalSales = data?.reduce((sum, sale) => sum + Number(sale.total_amount), 0) || 0;
      setTodaysSales(totalSales);
      setTodaysTransactions(data?.length || 0);
    } catch (error) {
      console.error('Error fetching today summary:', error);
    }
  };

  const updateRow = (id: string, patch: Partial<Row>) => {
    setRows((rs) => rs.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  };

  const findProductByNameOrCode = (value: string) => {
    return products.find((p) => 
      p.name.toLowerCase().includes(value.toLowerCase()) ||
      p.code.toLowerCase() === value.toLowerCase()
    );
  };

  const onItemChange = (id: string, value: string) => {
    const found = findProductByNameOrCode(value);
    if (found) {
      if (found.blocked_from_selling) {
        toast({
          title: "Product Blocked",
          description: "This product is blocked from selling",
          variant: "destructive",
        });
        return;
      }
      updateRow(id, { 
        itemName: found.name, 
        itemId: found.id, 
        code: found.code,
        price: Number(found.price) 
      });
    } else {
      updateRow(id, { itemName: value });
    }
  };

  const handleBarcodeScanner = () => {
    if (!barcodeInput.trim()) return;
    
    const found = findProductByNameOrCode(barcodeInput);
    if (found) {
      // Add to first empty row or create new row
      const emptyRowIndex = rows.findIndex(r => !r.itemName);
      if (emptyRowIndex >= 0) {
        onItemChange(rows[emptyRowIndex].id, barcodeInput);
      } else {
        const newRowId = crypto.randomUUID();
        setRows(prev => [...prev, { 
          id: newRowId, 
          itemName: found.name,
          itemId: found.id,
          code: found.code,
          price: Number(found.price),
          qty: 1,
          selected: false 
        }]);
      }
      setBarcodeInput("");
    } else {
      toast({
        title: "Product Not Found",
        description: "No product found with that code",
        variant: "destructive",
      });
    }
  };

  const deleteSelected = () => {
    setRows((rs) => rs.filter((r) => !r.selected));
  };

  const clearAll = () => setRows([newRow()]);

  const handlePayment = async (paymentMethod: 'cash' | 'mpesa' | 'bank', amountReceived: number) => {
    if (!currentShift || !profile) {
      toast({
        title: "No Active Shift",
        description: "Please open a shift before making sales",
        variant: "destructive",
      });
      return;
    }

    const validItems = rows.filter((r) => r.itemName && r.qty > 0 && r.price >= 0);
    if (validItems.length === 0) {
      toast({
        title: "No Items",
        description: "Add items to the bill before payment",
        variant: "destructive",
      });
      return;
    }

    try {
      // Create sale record
      const { data: sale, error: saleError } = await supabase
        .from('sales')
        .insert({
          cashier_id: profile.id,
          shift_id: currentShift.id,
          company_id: profile.company_id,
          total_amount: total,
          payment_method: paymentMethod,
          tax_amount: 0,
          discount_amount: 0
        })
        .select()
        .single();

      if (saleError) throw saleError;

      // Create sale items
      const saleItems = validItems.map(item => ({
        sale_id: sale.id,
        product_id: item.itemId || null,
        quantity: item.qty,
        unit_price: item.price,
        total_price: item.price * item.qty
      }));

      const { error: itemsError } = await supabase
        .from('sale_items')
        .insert(saleItems);

      if (itemsError) throw itemsError;

      // Update stock quantities
      for (const item of validItems) {
        if (item.itemId) {
          // Get current stock and update it
          const { data: currentProduct } = await supabase
            .from('products')
            .select('stock_quantity')
            .eq('id', item.itemId)
            .single();
          
          if (currentProduct) {
            const newStock = Math.max(0, currentProduct.stock_quantity - item.qty);
            const { error: stockError } = await supabase
              .from('products')
              .update({ stock_quantity: newStock })
              .eq('id', item.itemId);

            if (stockError) console.warn('Stock update failed:', stockError);
          }
        }
      }

      toast({
        title: "Payment Successful",
        description: `Sale completed. Total: KES ${total.toFixed(2)}`,
      });

      clearAll();
      fetchTodaysSummary();
    } catch (error) {
      console.error('Error processing payment:', error);
      toast({
        title: "Payment Failed",
        description: "Failed to process payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  const holdBill = () => {
    // TODO: Implement hold bill functionality with database
    const validItems = rows.filter((r) => r.itemName && r.qty > 0);
    if (validItems.length === 0) {
      toast({
        title: "No Items to Hold",
        description: "Add items to the bill before holding",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Bill Held",
      description: "Feature coming soon - bill holding",
    });
  };

  const openShift = async () => {
    if (!profile) return;
    
    try {
      const openingCash = parseFloat(prompt("Enter opening cash amount:") || "0");
      
      const { error } = await supabase
        .from('shifts')
        .insert({
          cashier_id: profile.id,
          company_id: profile.company_id,
          opening_cash: openingCash,
          status: 'open'
        });

      if (error) throw error;

      toast({
        title: "Shift Opened",
        description: `Shift opened with KES ${openingCash.toFixed(2)}`,
      });
      
      fetchCurrentShift();
    } catch (error) {
      console.error('Error opening shift:', error);
      toast({
        title: "Error",
        description: "Failed to open shift",
        variant: "destructive",
      });
    }
  };

  const closeShift = () => {
    setSupervisorAction("close shift");
    setShowSupervisorDialog(true);
  };

  const handleCloseShift = async () => {
    if (!currentShift) return;
    
    try {
      const closingCash = parseFloat(prompt("Enter closing cash amount:") || "0");
      
      const { error } = await supabase
        .from('shifts')
        .update({
          status: 'closed',
          closing_cash: closingCash,
          closed_at: new Date().toISOString()
        })
        .eq('id', currentShift.id);

      if (error) throw error;

      toast({
        title: "Shift Closed",
        description: `Shift closed with KES ${closingCash.toFixed(2)}`,
      });
      
      setCurrentShift(null);
    } catch (error) {
      console.error('Error closing shift:', error);
      toast({
        title: "Error",
        description: "Failed to close shift",
        variant: "destructive",
      });
    }
  };

  const handleExpenseLog = (amount: number, reason: string, description?: string) => {
    // The ExpenseDialog will handle the database operations
    fetchTodaysSummary();
  };

  const filteredProducts = products.filter(p => 
    searchTerm === "" || 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Helmet>
        <title>Cashier Dashboard | Modern POS</title>
        <meta name="description" content="Advanced cashier dashboard with barcode scanning, inventory management, and real-time sales." />
        <link rel="canonical" href={typeof window !== 'undefined' ? window.location.href : '/cashier'} />
      </Helmet>

      <header className="border-b bg-white shadow-sm">
        <div className="container flex flex-col gap-2 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Cashier Dashboard</h1>
            <p className="text-sm text-gray-600">
              {dateStr} • {timeStr} • {profile?.full_name || 'Cashier'}
              {currentShift && <Badge className="ml-2" variant="secondary">Shift Active</Badge>}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {(profile?.role === 'admin' || profile?.role === 'manager') && (
              <Link to="/admin"><Button variant="outline">Admin</Button></Link>
            )}
            <Link to="/"><Button variant="ghost">Home</Button></Link>
            <Button variant="destructive" onClick={signOut}>Logout</Button>
          </div>
        </div>
      </header>

      <main className="container space-y-6 py-6">
        {/* Today's Summary Cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Sales</CardTitle>
              <Banknote className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">KES {todaysSales.toFixed(2)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Transactions</CardTitle>
              <Receipt className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{todaysTransactions}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Shift Status</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {currentShift ? (
                  <Badge variant="default">Active</Badge>
                ) : (
                  <Badge variant="secondary">Closed</Badge>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Product Search & Barcode Scanner */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="h-5 w-5" />
                  Product Search
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Barcode Scanner</label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Scan or enter barcode..."
                      value={barcodeInput}
                      onChange={(e) => setBarcodeInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleBarcodeScanner()}
                    />
                    <Button onClick={handleBarcodeScanner} size="icon">
                      <Scan className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Search Products</label>
                  <Input
                    placeholder="Search by name or code..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div className="max-h-48 overflow-y-auto space-y-1">
                  {filteredProducts.slice(0, 10).map((product) => (
                    <div
                      key={product.id}
                      className="flex items-center justify-between p-2 border rounded cursor-pointer hover:bg-gray-50"
                      onClick={() => {
                        const emptyRowIndex = rows.findIndex(r => !r.itemName);
                        if (emptyRowIndex >= 0) {
                          onItemChange(rows[emptyRowIndex].id, product.name);
                        } else {
                          setRows(prev => [...prev, {
                            id: crypto.randomUUID(),
                            itemName: product.name,
                            itemId: product.id,
                            code: product.code,
                            price: Number(product.price),
                            qty: 1,
                            selected: false
                          }]);
                        }
                      }}
                    >
                      <div className="text-left">
                        <div className="font-medium text-sm">{product.name}</div>
                        <div className="text-xs text-gray-500">{product.code}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">KES {Number(product.price).toFixed(2)}</div>
                        <div className="text-xs text-gray-500">Stock: {product.stock_quantity}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* POS Table */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Sale Items</CardTitle>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" onClick={() => setRows((rs) => [...rs, newRow()])}>
                    <Plus className="h-4 w-4 mr-1" />
                    Add Row
                  </Button>
                  <Button size="sm" variant="outline" onClick={deleteSelected}>
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete Selected
                  </Button>
                  <Button size="sm" variant="outline" onClick={clearAll}>
                    Clear All
                  </Button>
                  <Button size="sm" variant="outline" onClick={holdBill}>
                    <Pause className="h-4 w-4 mr-1" />
                    Hold Bill
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <datalist id="product-options">
                  {products.map((product) => (
                    <option key={product.id} value={product.name} />
                  ))}
                </datalist>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">Select</TableHead>
                      <TableHead>Item Name</TableHead>
                      <TableHead>Code</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Qty</TableHead>
                      <TableHead>Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rows.map((r) => (
                      <TableRow key={r.id}>
                        <TableCell>
                          <input
                            type="checkbox"
                            className="h-4 w-4"
                            checked={!!r.selected}
                            onChange={(e) => updateRow(r.id, { selected: e.target.checked })}
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            list="product-options"
                            placeholder="Search item..."
                            value={r.itemName}
                            onChange={(e) => onItemChange(r.id, e.target.value)}
                            className="min-w-[200px]"
                          />
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-gray-500">{r.code || '-'}</span>
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            step="0.01"
                            value={r.price}
                            onChange={(e) => updateRow(r.id, { price: parseFloat(e.target.value || "0") })}
                            className="w-20"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            value={r.qty}
                            onChange={(e) => updateRow(r.id, { qty: parseInt(e.target.value || "0") })}
                            className="w-16"
                          />
                        </TableCell>
                        <TableCell className="font-medium">
                          KES {(r.price * r.qty).toFixed(2)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                <Separator className="my-4" />

                <div className="flex items-center justify-between">
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setShowExpenseDialog(true)}>
                      <Calculator className="h-4 w-4 mr-1" />
                      Log Expense
                    </Button>
                    <Button variant="outline" onClick={currentShift ? closeShift : openShift}>
                      <Clock className="h-4 w-4 mr-1" />
                      {currentShift ? 'Close Shift' : 'Open Shift'}
                    </Button>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-bold">Total: KES {total.toFixed(2)}</div>
                    <Button 
                      size="lg" 
                      onClick={() => setShowPaymentDialog(true)}
                      disabled={total <= 0 || !currentShift}
                      className="mt-2"
                    >
                      <Banknote className="h-4 w-4 mr-1" />
                      Process Payment
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <footer className="border-t bg-white">
        <div className="container py-3 text-sm text-gray-600">
          {currentShift ? (
            `Shift opened at ${new Date(currentShift.opened_at).toLocaleTimeString()} • Opening cash: KES ${Number(currentShift.opening_cash).toFixed(2)}`
          ) : (
            'No active shift'
          )}
        </div>
      </footer>

      {/* Dialogs */}
      <PaymentDialog
        open={showPaymentDialog}
        onOpenChange={setShowPaymentDialog}
        totalAmount={total}
        onPayment={handlePayment}
      />
      
      <SupervisorPasswordDialog
        open={showSupervisorDialog}
        onOpenChange={setShowSupervisorDialog}
        onSuccess={handleCloseShift}
        action={supervisorAction}
      />
      
      <ExpenseDialog
        open={showExpenseDialog}
        onOpenChange={setShowExpenseDialog}
        onSuccess={() => fetchTodaysSummary()}
      />
    </div>
  );
};

export default CashierDashboard;
