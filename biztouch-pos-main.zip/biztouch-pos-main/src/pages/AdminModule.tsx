import React from "react";
import { Helmet } from "react-helmet-async";
import { Link, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";

// Import all admin components
import { SystemSettings } from "@/components/admin/SystemSettings";
import { CatalogueStockEdit } from "@/components/admin/CatalogueStockEdit";
import { ExpenseView } from "@/components/admin/ExpenseView";
import { UsersRights } from "@/components/admin/UsersRights";
import { StockInput } from "@/components/admin/StockInput";

const moduleTitles: Record<string, string> = {
  "system-settings": "System Settings",
  "admin-settings": "Admin Settings",
  "catalogue-stock-edit": "Catalogue & Stock Edit",
  "expense-view": "Expense View",
  "database-access": "Database Access",
  "sales-report": "Sales Report",
  "users-rights": "Users & Rights",
  "stock-input": "Stock Input",
  "open-shift": "Open Shift",
  "close-shift": "Close Shift",
  "price-change": "Price Change",
  "mpesa-messages": "M-Pesa Messages",
  "sales-analysis": "Sales Analysis & Graphs",
  "user-settings": "User Settings & Passwords",
};

const AdminModule: React.FC = () => {
  const { module } = useParams<{ module: string }>();
  const { profile, signOut } = useAuth();
  const title = module ? moduleTitles[module] ?? module : "Module";

  const renderModuleContent = () => {
    switch (module) {
      case "system-settings":
        return <SystemSettings />;
      case "catalogue-stock-edit":
        return <CatalogueStockEdit />;
      case "expense-view":
        return <ExpenseView />;
      case "users-rights":
        return <UsersRights />;
      case "stock-input":
        return <StockInput />;
      case "admin-settings":
        return (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium text-gray-900">Admin Settings</h3>
            <p className="text-gray-500 mt-2">Advanced administrative configuration panel coming soon.</p>
          </div>
        );
      case "database-access":
        return (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium text-gray-900">Database Access</h3>
            <p className="text-gray-500 mt-2">Direct database management tools coming soon.</p>
          </div>
        );
      case "sales-report":
        return (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium text-gray-900">Sales Report</h3>
            <p className="text-gray-500 mt-2">Comprehensive sales reporting dashboard coming soon.</p>
          </div>
        );
      case "open-shift":
        return (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium text-gray-900">Open Shift</h3>
            <p className="text-gray-500 mt-2">Shift management tools coming soon.</p>
          </div>
        );
      case "close-shift":
        return (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium text-gray-900">Close Shift</h3>
            <p className="text-gray-500 mt-2">Shift closure tools coming soon.</p>
          </div>
        );
      case "price-change":
        return (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium text-gray-900">Price Change</h3>
            <p className="text-gray-500 mt-2">Bulk price management tools coming soon.</p>
          </div>
        );
      case "mpesa-messages":
        return (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium text-gray-900">M-Pesa Messages</h3>
            <p className="text-gray-500 mt-2">M-Pesa integration and message handling coming soon.</p>
          </div>
        );
      case "sales-analysis":
        return (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium text-gray-900">Sales Analysis & Graphs</h3>
            <p className="text-gray-500 mt-2">Advanced analytics and visualization tools coming soon.</p>
          </div>
        );
      case "user-settings":
        return (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium text-gray-900">User Settings & Passwords</h3>
            <p className="text-gray-500 mt-2">User account management tools coming soon.</p>
          </div>
        );
      default:
        return (
          <div className="text-center py-8">
            <h3 className="text-lg font-medium text-gray-900">Module Not Found</h3>
            <p className="text-gray-500 mt-2">The requested module is not available.</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Helmet>
        <title>{`${title} | Modern POS`}</title>
        <meta name="description" content={`Modern POS admin module: ${title}.`} />
        <link rel="canonical" href={typeof window !== 'undefined' ? window.location.href : '/admin'} />
      </Helmet>
      
      <header className="border-b bg-white shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
            <p className="text-sm text-gray-600">
              {profile?.full_name} • {profile?.role?.toUpperCase()}
            </p>
          </div>
          <div className="flex gap-2">
            <Link to="/admin">
              <Button variant="outline">Back to Admin</Button>
            </Link>
            <Link to="/cashier">
              <Button variant="outline">Cashier</Button>
            </Link>
            <Link to="/">
              <Button variant="ghost">Home</Button>
            </Link>
            <Button variant="destructive" onClick={signOut}>Logout</Button>
          </div>
        </div>
      </header>

      <main className="container py-6">
        {renderModuleContent()}
      </main>
    </div>
  );
};

export default AdminModule;
