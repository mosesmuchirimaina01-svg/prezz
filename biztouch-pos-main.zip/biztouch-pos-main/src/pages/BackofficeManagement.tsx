import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SupplierManagement } from "@/components/backoffice/SupplierManagement";
import { PriceChangeManagement } from "@/components/backoffice/PriceChangeManagement";
import { BackofficeReports } from "@/components/admin/BackofficeReports";
import EnhancedUserManagement from "@/components/admin/EnhancedUserManagement";
import ProductCreation from "@/components/admin/ProductCreation";
import InvoiceStockInput from "@/components/admin/InvoiceStockInput";
import { SystemSettings } from "@/components/admin/SystemSettings";
import { ArrowLeft } from "lucide-react";

const BackofficeManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState("users");

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      <Helmet>
        <title>GB PAWA POS - Back Office Management</title>
        <meta name="description" content="Comprehensive backoffice management system for inventory, sales, users, and analytics." />
      </Helmet>

      {/* Header */}
      <header className="bg-orange-50 border-b p-2 shrink-0">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold">GB PAWA POS - Back Office</h1>
            <p className="text-sm text-muted-foreground">
              Administrative Management • {new Date().toLocaleDateString()}
            </p>
          </div>
          <div className="flex gap-1">
            <Button size="sm" variant="outline" asChild>
              <Link to="/">
                <ArrowLeft className="h-3 w-3 mr-1" />
                Home
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-auto p-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
            <TabsList className="w-full justify-start shrink-0">
              <TabsTrigger value="users">User Management</TabsTrigger>
              <TabsTrigger value="products">Products</TabsTrigger>
              <TabsTrigger value="invoices">Invoice Stock</TabsTrigger>
              <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
              <TabsTrigger value="prices">Price Changes</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
            </TabsList>
            
            <div className="flex-1 overflow-auto mt-4">
              <TabsContent value="users" className="h-full m-0">
                <EnhancedUserManagement />
              </TabsContent>

              <TabsContent value="products" className="h-full m-0">
                <ProductCreation />
              </TabsContent>

              <TabsContent value="invoices" className="h-full m-0">
                <InvoiceStockInput />
              </TabsContent>
              
              <TabsContent value="suppliers" className="h-full m-0">
                <SupplierManagement />
              </TabsContent>
              
              <TabsContent value="prices" className="h-full m-0">
                <PriceChangeManagement />
              </TabsContent>

              <TabsContent value="settings" className="h-full m-0">
                <SystemSettings />
              </TabsContent>
              
              <TabsContent value="reports" className="h-full m-0">
                <BackofficeReports />
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default BackofficeManagement;
