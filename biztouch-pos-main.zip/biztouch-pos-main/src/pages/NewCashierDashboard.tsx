import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { BillHoldSystem } from "@/components/cashier/BillHoldSystem";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Scan, Trash2, Calculator, Pause, Banknote, Receipt, Clock, CreditCard, Smartphone } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { PaymentCalculator } from "@/components/PaymentCalculator";
import { SupervisorPasswordDialog } from "@/components/SupervisorPasswordDialog";
import { ExpenseDialog } from "@/components/ExpenseDialog";
import { AdminPasswordDialog } from "@/components/AdminPasswordDialog";
import { UpdateCheck } from "@/components/ui/update-check";
import { DataTable } from "@/components/ui/data-table";
import { useKeyboardShortcuts } from "@/hooks/useKeyboardShortcuts";
import { CompanyHeader } from "@/components/shared/CompanyHeader";
import { SaleCompleteDialog } from "@/components/cashier/SaleCompleteDialog";
import { EODManagement } from "@/components/cashier/EODManagement";
import { ModuleLoginDialog } from "@/components/connection/ModuleLoginDialog";

type Row = {
  id: string;
  itemName: string;
  itemId?: string;
  code?: string;
  price: number;
  qty: number;
  selected?: boolean;
};

type Product = {
  id: string;
  code: string;
  name: string;
  price: number;
  stock_quantity: number;
  is_active: boolean;
  blocked_from_selling: boolean;
};

type Sale = {
  id: string;
  total_amount: number;
  payment_method: string;
  created_at: string;
};

const newRow = (): Row => ({ id: crypto.randomUUID(), itemName: "", price: 0, qty: 1, selected: false });

const NewCashierDashboard: React.FC = () => {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginDialog, setShowLoginDialog] = useState(true);
  const [rows, setRows] = useState<Row[]>([newRow()]);
  const [products, setProducts] = useState<Product[]>([]);
  const [barcodeInput, setBarcodeInput] = useState("");
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showSupervisorDialog, setShowSupervisorDialog] = useState(false);
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);
  const [showAdminDialog, setShowAdminDialog] = useState(false);
  const [todaysSales, setTodaysSales] = useState(0);
  const [todaysTransactions, setTodaysTransactions] = useState<Sale[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'mpesa' | 'bank'>('cash');
  const [heldBills, setHeldBills] = useState<any[]>([]);
  const [showSaleCompleteDialog, setShowSaleCompleteDialog] = useState(false);
  const [activeTab, setActiveTab] = useState<"sales" | "eod">("eod");
  const [lastSaleDetails, setLastSaleDetails] = useState<{
    totalAmount: number;
    amountReceived: number;
    paymentMethod: string;
  } | null>(null);
  
  const total = rows.reduce((sum, r) => sum + r.price * r.qty, 0);

  // Keyboard shortcuts
  useKeyboardShortcuts({
    onF1: () => total > 0 && setShowPaymentDialog(true), // PAY
    onF2: () => total > 0 && holdBill(), // HOLD
    onF3: () => setShowExpenseDialog(true), // EXPENSE
    onM: () => {
      setPaymentMethod('mpesa');
      total > 0 && setShowPaymentDialog(true);
    },
    onB: () => {
      setPaymentMethod('bank');
      total > 0 && setShowPaymentDialog(true);
    },
    onC: () => {
      setPaymentMethod('cash');
      total > 0 && setShowPaymentDialog(true);
    },
    onEnd: () => {
      if (total > 0) {
        handlePayment(paymentMethod, total);
      }
    }
  });

  useEffect(() => {
    // Check if user is authenticated and has company selected
    if (user && profile?.company_id) {
      setIsLoggedIn(true);
      setShowLoginDialog(false);
      sessionStorage.setItem('cashier_logged_in', 'true');
    }
  }, [user, profile]);

  useEffect(() => {
    if (isLoggedIn) {
      fetchProducts();
      fetchTodaysSummary();
    }
  }, [profile, isLoggedIn]);

  const fetchProducts = async () => {
    if (!profile?.company_id) return;
    
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('is_active', true)
        .eq('company_id', profile.company_id)
        .order('name');
      
      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const fetchTodaysSummary = async () => {
    if (!profile?.company_id) return;
    
    try {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('sales')
        .select('id, total_amount, payment_method, created_at')
        .eq('cashier_id', profile.id)
        .eq('company_id', profile.company_id)
        .gte('created_at', `${today}T00:00:00`)
        .lte('created_at', `${today}T23:59:59`)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      const totalSales = data?.reduce((sum, sale) => sum + Number(sale.total_amount), 0) || 0;
      setTodaysSales(totalSales);
      setTodaysTransactions(data || []);
    } catch (error) {
      console.error('Error fetching today summary:', error);
    }
  };

  const updateRow = (id: string, patch: Partial<Row>) => {
    setRows((rs) => rs.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  };

  const findProductByCode = (code: string) => {
    return products.find((p) => p.code.toLowerCase() === code.toLowerCase());
  };

  const handleBarcodeScanner = () => {
    if (!barcodeInput.trim()) return;
    
    const found = findProductByCode(barcodeInput);
    if (found) {
      if (found.blocked_from_selling) {
        toast({
          title: "Product Blocked",
          description: "This product is blocked from selling",
          variant: "destructive",
        });
        return;
      }

      const emptyRowIndex = rows.findIndex(r => !r.itemName);
      if (emptyRowIndex >= 0) {
        updateRow(rows[emptyRowIndex].id, {
          itemName: found.name,
          itemId: found.id,
          code: found.code,
          price: Number(found.price)
        });
      } else {
        setRows(prev => [...prev, {
          id: crypto.randomUUID(),
          itemName: found.name,
          itemId: found.id,
          code: found.code,
          price: Number(found.price),
          qty: 1,
          selected: false
        }]);
      }
      setBarcodeInput("");
    } else {
      toast({
        title: "Product Not Found",
        description: "No product found with that barcode",
        variant: "destructive",
      });
    }
  };

  const deleteSelected = () => {
    setRows((rs) => rs.filter((r) => !r.selected));
  };

  const clearAll = () => setRows([newRow()]);

  const handlePayment = async (paymentMethod: 'cash' | 'mpesa' | 'bank', amountReceived: number) => {
    if (!profile?.company_id) {
      toast({
        title: "No Company",
        description: "Please connect to a company first",
        variant: "destructive",
      });
      return;
    }

    const validItems = rows.filter((r) => r.itemName && r.qty > 0 && r.price >= 0);
    if (validItems.length === 0) {
      toast({
        title: "No Items",
        description: "Add items to the bill before payment",
        variant: "destructive",
      });
      return;
    }

    try {
      const { data: sale, error: saleError } = await supabase
        .from('sales')
        .insert({
          cashier_id: profile.id,
          company_id: profile.company_id,
          shift_id: null, // No shift required
          total_amount: total,
          payment_method: paymentMethod,
          tax_amount: 0,
          discount_amount: 0
        })
        .select()
        .single();

      if (saleError) throw saleError;

      const saleItems = validItems.map(item => ({
        sale_id: sale.id,
        product_id: item.itemId || null,
        quantity: item.qty,
        unit_price: item.price,
        total_price: item.price * item.qty
      }));

      const { error: itemsError } = await supabase
        .from('sale_items')
        .insert(saleItems);

      if (itemsError) throw itemsError;

      // Best-effort stock update (ignore failures due to RLS)
      try {
        await Promise.allSettled(validItems.map(async (item) => {
          if (!item.itemId) return;
          const { data: currentProduct } = await supabase
            .from('products')
            .select('stock_quantity')
            .eq('id', item.itemId)
            .maybeSingle();
          if (currentProduct) {
            const newStock = Math.max(0, Number(currentProduct.stock_quantity) - item.qty);
            await supabase
              .from('products')
              .update({ stock_quantity: newStock })
              .eq('id', item.itemId);
          }
        }));
      } catch (e) {
        // Ignore stock update errors
        console.warn('Stock update skipped due to permissions or other issue:', e);
      }

      toast({
        title: "Payment Successful",
        description: `Sale completed. Balance: KES ${(amountReceived - total).toFixed(2)}`,
      });

      // Store sale details for the dialog
      setLastSaleDetails({
        totalAmount: total,
        amountReceived,
        paymentMethod,
      });
      
      // Show sale complete dialog
      setShowSaleCompleteDialog(true);
      
      fetchTodaysSummary();
    } catch (error) {
      console.error('Error processing payment:', error);
      toast({
        title: "Payment Failed",
        description: "Failed to process payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  const holdBill = (reason?: string) => {
    const validItems = rows.filter((r) => r.itemName && r.qty > 0 && r.price >= 0);
    if (validItems.length === 0) {
      toast({
        title: "No Items",
        description: "Add items to the bill before holding",
        variant: "destructive",
      });
      return;
    }

    const newHeldBill = {
      id: Date.now().toString(),
      bill_number: `HOLD-${Date.now()}`,
      items: validItems,
      total: total,
      hold_reason: reason || "Manual hold",
      held_at: new Date().toISOString()
    };

    setHeldBills(prev => [...prev, newHeldBill]);
    clearAll();
    toast({
      title: "Bill Held",
      description: `Bill ${newHeldBill.bill_number} held successfully`,
    });
  };

  const loadHeldBill = (bill: any) => {
    setRows(bill.items);
    toast({
      title: "Bill Loaded",
      description: `Bill ${bill.bill_number} loaded for completion`,
    });
  };

  const handleAdminAccess = () => {
    navigate('/admin');
  };

  const handleNextCustomer = () => {
    clearAll();
    setShowSaleCompleteDialog(false);
    setLastSaleDetails(null);
    toast({
      title: "Ready for Next Customer",
      description: "New bill started.",
    });
  };

  const handleCashierLogout = () => {
    // Clear cashier session
    sessionStorage.removeItem('cashier_logged_in');
    clearAll();
    toast({
      title: "Logged Out",
      description: "You have been logged out of the cashier module.",
    });
    // Navigate back to auth page
    navigate('/auth');
  };

  const handleLoginSuccess = () => {
    if (!profile?.company_id) {
      toast({
        title: "Company Required",
        description: "Please select a company first from the login page",
        variant: "destructive",
      });
      navigate('/auth');
      return;
    }
    sessionStorage.setItem('cashier_logged_in', 'true');
    setIsLoggedIn(true);
    setShowLoginDialog(false);
    toast({
      title: "Login Successful",
      description: "Welcome to Cashier Dashboard",
    });
  };

  // Redirect to auth if not logged in or no company selected
  if (!user || !profile?.company_id) {
    return (
      <>
        <Helmet>
          <title>Cashier Login - GB PAWA POS</title>
        </Helmet>
        <div className="min-h-screen flex items-center justify-center bg-background">
          <div className="text-center space-y-4">
            <h2 className="text-2xl font-bold">Access Restricted</h2>
            <p className="text-muted-foreground">Please login and select a company first.</p>
            <Button onClick={() => navigate('/auth')}>Go to Login</Button>
          </div>
        </div>
      </>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-background">
      <Helmet>
        <title>Cashier Dashboard - GB PAWA POS</title>
      </Helmet>

      {/* Header */}
      <header className="shrink-0">
        <CompanyHeader title="GB PAWA POS - Cashier" />
        <div className="border-b p-2 flex items-center justify-end gap-1">
          <UpdateCheck />
          <Button size="sm" variant="outline" onClick={() => setShowExpenseDialog(true)}>
            Expense
          </Button>
          <Button size="sm" variant="destructive" onClick={handleCashierLogout}>
            Logout from Cashier
          </Button>
        </div>
      </header>

      {/* Main content area with Tabs */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "sales" | "eod")} className="flex-1 flex flex-col overflow-hidden">
        {/* Tabs Navigation at Top */}
        <div className="shrink-0 bg-blue-600 px-3 py-2">
          <TabsList className="w-full grid grid-cols-2 h-12 p-1 gap-2 bg-blue-700">
            <TabsTrigger 
              value="eod" 
              className="text-sm font-semibold py-2 px-4 h-10 data-[state=active]:bg-white data-[state=active]:text-blue-600"
            >
              END OF THE DAY
            </TabsTrigger>
            <TabsTrigger 
              value="sales" 
              className="text-sm font-semibold py-2 px-4 h-10 data-[state=active]:bg-white data-[state=active]:text-blue-600"
            >
              SALES
            </TabsTrigger>
          </TabsList>
        </div>
        {/* EOD Tab - First */}
        <TabsContent value="eod" className="flex-1 overflow-auto m-0 p-4">
          <EODManagement />
        </TabsContent>

        {/* Sales Tab - Second */}
        <TabsContent value="sales" className="flex-1 overflow-hidden m-0">
          <div className="h-full flex flex-col overflow-hidden">
            <div className="flex-1 p-4 overflow-hidden">
              <div className="grid grid-cols-12 gap-4 h-full">
                {/* Left side - Product entry and cart */}
                <div className="col-span-8 flex flex-col gap-4">
                  {/* Product Entry */}
                  <Card className="shrink-0">
              <CardContent className="p-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Scan barcode here..."
                    value={barcodeInput}
                    onChange={(e) => setBarcodeInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleBarcodeScanner()}
                    className="flex-1"
                  />
                  <Button onClick={handleBarcodeScanner} size="icon">
                    <Scan className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
                  </Card>

                  {/* Cart table */}
                  <Card className="flex-1 overflow-hidden shadow-md">
              <CardHeader className="pb-2 bg-muted/30">
                <CardTitle className="text-lg">Shopping Cart</CardTitle>
              </CardHeader>
              <CardContent className="p-0 overflow-hidden">
                <DataTable
                  data={rows}
                  columns={[
                    {
                      key: 'selected',
                      header: (
                        <input
                          type="checkbox"
                          onChange={(e) => {
                            const checked = e.target.checked;
                            setRows(rows.map(r => ({ ...r, selected: checked })));
                          }}
                        />
                      ),
                      cell: (row) => (
                        <input
                          type="checkbox"
                          checked={row.selected || false}
                          onChange={(e) => updateRow(row.id, { selected: e.target.checked })}
                        />
                      ),
                      className: "w-8"
                    },
                    {
                      key: 'itemName',
                      header: 'Item',
                      cell: (row) => row.itemName || '-'
                    },
                    {
                      key: 'price',
                      header: 'Price',
                      cell: (row) => `KES ${row.price.toFixed(2)}`,
                      className: "text-right"
                    },
                    {
                      key: 'qty',
                      header: 'Qty',
                      cell: (row) => (
                        <Input
                          type="number"
                          min="1"
                          value={row.qty}
                          onChange={(e) => updateRow(row.id, { qty: parseInt(e.target.value) || 1 })}
                          className="w-16 h-8"
                        />
                      ),
                      className: "w-20"
                    },
                    {
                      key: 'total',
                      header: 'Total',
                      cell: (row) => `KES ${(row.price * row.qty).toFixed(2)}`,
                      className: "text-right font-medium"
                    }
                  ]}
                  compact={true}
                  stickyHeader={true}
                  maxHeight="calc(100vh - 400px)"
                  emptyMessage="No items in cart"
                />
              </CardContent>
                  </Card>
                </div>

                {/* Right side - Summary and actions */}
                <div className="col-span-4 flex flex-col gap-4">
            {/* Total and sales summary */}
            <div className="grid grid-cols-2 gap-2">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-sm text-muted-foreground">Today's Sales</div>
                  <div className="text-lg font-bold">KES {todaysSales.toFixed(2)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-sm text-muted-foreground">Transactions</div>
                  <div className="text-lg font-bold">{todaysTransactions.length}</div>
                </CardContent>
              </Card>
            </div>

            {/* Current total */}
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-primary">
                  Total: KES {total.toFixed(2)}
                </div>
              </CardContent>
            </Card>

            {/* Today's transactions */}
            <Card className="flex-1 overflow-hidden">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Today's Transactions</CardTitle>
              </CardHeader>
              <CardContent className="p-2 overflow-hidden">
                <div className="overflow-auto h-full space-y-1">
                  {todaysTransactions.slice(0, 10).map((sale) => (
                    <div key={sale.id} className="flex justify-between text-xs p-2 bg-muted/50 rounded">
                      <span>{new Date(sale.created_at).toLocaleTimeString()}</span>
                      <span>KES {Number(sale.total_amount).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Bill Hold System */}
            <BillHoldSystem 
              currentBill={{
                items: rows,
                total: total,
                customerName: ""
              }}
              heldBills={heldBills}
              onHoldBill={holdBill}
              onUnholdBill={loadHeldBill}
            />
          </div>
        </div>
      </div>
    </div>
    </TabsContent>

    {/* Action Buttons at Bottom */}
    <div className="shrink-0 bg-blue-500 text-white p-3 border-t-2 border-gray-300">
      <div className="flex gap-2">
        <Button 
          variant="secondary" 
          onClick={deleteSelected}
          className="flex-1 h-12 text-base font-semibold"
        >
          <Trash2 className="h-5 w-5 mr-1" />
          Delete
        </Button>
        <Button 
          variant="secondary"
          onClick={() => holdBill()}
          className="flex-1 h-12 text-base font-semibold"
        >
          <Pause className="h-5 w-5 mr-1" />
          Hold
        </Button>
        <Button 
          variant="secondary"
          onClick={clearAll}
          className="flex-1 h-12 text-base font-semibold"
        >
          Clear
        </Button>
        <Button 
          onClick={() => setShowPaymentDialog(true)}
          disabled={total <= 0}
          className="flex-2 bg-green-600 hover:bg-green-700 h-12 text-base font-semibold"
        >
          <Calculator className="h-5 w-5 mr-1" />
          PAY OUT - KES {total.toFixed(2)}
        </Button>
      </div>
    </div>
  </Tabs>

  {/* Dialogs */}
  <PaymentCalculator
        open={showPaymentDialog}
        onOpenChange={setShowPaymentDialog}
        total={total}
        onPayment={handlePayment}
        defaultMethod={paymentMethod}
      />

  <SupervisorPasswordDialog
        open={showSupervisorDialog}
        onOpenChange={setShowSupervisorDialog}
        action="close shift"
        onSuccess={() => {}}
      />

  <ExpenseDialog
        open={showExpenseDialog}
        onOpenChange={setShowExpenseDialog}
        onSuccess={() => {}}
      />

  <AdminPasswordDialog
        open={showAdminDialog}
        onOpenChange={setShowAdminDialog}
        onSuccess={handleAdminAccess}
      />

  <SaleCompleteDialog
        open={showSaleCompleteDialog}
        onOpenChange={setShowSaleCompleteDialog}
        totalAmount={lastSaleDetails?.totalAmount || 0}
        amountReceived={lastSaleDetails?.amountReceived || 0}
        paymentMethod={lastSaleDetails?.paymentMethod || 'cash'}
        onNextCustomer={handleNextCustomer}
      />
</div>
  );
};

export default NewCashierDashboard;