import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import { SystemSettings } from "@/components/admin/SystemSettings";
import { UsersRights } from "@/components/admin/UsersRights";
import { ExpenseView } from "@/components/admin/ExpenseView";
import { SalesReports } from "@/components/admin/SalesReports";
import { AdminUserManagement } from "@/components/admin/AdminUserManagement";
import { UpdateCheck } from "@/components/ui/update-check";
import { UserPasswordDialog } from "@/components/UserPasswordDialog";
import { StockAdjustment } from "@/components/admin/StockAdjustment";
import { OrderManagement } from "@/components/admin/OrderManagement";

const NewAdminDashboard: React.FC = () => {
  const { profile, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState("reports");
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [pendingTab, setPendingTab] = useState("");
  const [showStockAdjustment, setShowStockAdjustment] = useState(false);
  const [passwordVerified, setPasswordVerified] = useState<Record<string, boolean>>({});

  const adminTabs = [
    { id: 'reports', label: 'Sales Reports', component: SalesReports, requiresPassword: false },
    { id: 'users', label: 'User Management', component: AdminUserManagement, requiresPassword: true },
    { id: 'orders', label: 'Order Management', component: OrderManagement, requiresPassword: true },
    { id: 'settings', label: 'System Settings', component: SystemSettings, requiresPassword: true },
    { id: 'expenses', label: 'Expense View', component: ExpenseView, requiresPassword: true },
  ];

  const ActiveComponent = adminTabs.find(tab => tab.id === activeTab)?.component || SalesReports;

  const handleTabClick = (tabId: string) => {
    const tab = adminTabs.find(t => t.id === tabId);
    if (tab?.requiresPassword && !passwordVerified[tabId]) {
      setPendingTab(tabId);
      setShowPasswordDialog(true);
    } else {
      setActiveTab(tabId);
    }
  };

  const handlePasswordSuccess = () => {
    setPasswordVerified(prev => ({ ...prev, [pendingTab]: true }));
    setActiveTab(pendingTab);
    setShowPasswordDialog(false);
    setPendingTab("");
  };

  const handleStockAdjustmentClick = () => {
    setShowStockAdjustment(true);
  };

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      <Helmet>
        <title>GB PAWA POS - Admin Dashboard</title>
        <meta name="description" content="GB PAWA POS Admin Dashboard" />
      </Helmet>

      {/* Header with pale yellow background */}
      <header className="bg-yellow-50 border-b p-2 shrink-0">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold">GB PAWA POS - Admin</h1>
            <p className="text-sm text-muted-foreground">
              {profile?.full_name} • {profile?.role?.toUpperCase()} • {new Date().toLocaleDateString()}
            </p>
          </div>
          <div className="flex gap-1">
            <UpdateCheck />
            <Button size="sm" variant="outline" asChild>
              <Link to="/cashier">Cashier</Link>
            </Button>
            <Button size="sm" variant="outline" asChild>
              <Link to="/backoffice">Backoffice</Link>
            </Button>
            <Button size="sm" variant="outline" asChild>
              <Link to="/">Home</Link>
            </Button>
            <Button size="sm" variant="destructive" onClick={signOut}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Admin tabs navigation with blue background */}
      <div className="bg-blue-500 text-white shrink-0">
        <div className="p-2">
          <div className="flex flex-wrap gap-1">
            {adminTabs.map((tab) => (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? "default" : "outline"}
                onClick={() => handleTabClick(tab.id)}
                className="text-xs h-8 px-3 bg-yellow-100 hover:bg-yellow-200 border-blue-500 text-blue-700"
                style={{ backgroundColor: activeTab === tab.id ? '#3b82f6' : '#fef3c7' }}
              >
                {tab.label}
              </Button>
            ))}
            <Button
              onClick={handleStockAdjustmentClick}
              className="text-xs h-8 px-3 bg-green-100 hover:bg-green-200 border-blue-500 text-green-700"
            >
              Stock Adjustment
            </Button>
          </div>
        </div>
      </div>

      {/* Main content area */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full p-4 overflow-auto">
          <ActiveComponent />
        </div>
      </div>

      <UserPasswordDialog
        open={showPasswordDialog}
        onOpenChange={setShowPasswordDialog}
        onSuccess={handlePasswordSuccess}
        action={`access ${adminTabs.find(t => t.id === pendingTab)?.label || 'this feature'}`}
      />

      <StockAdjustment
        open={showStockAdjustment}
        onOpenChange={setShowStockAdjustment}
        onSuccess={() => {
          // Optionally refresh data or show success message
        }}
      />
    </div>
  );
};

export default NewAdminDashboard;