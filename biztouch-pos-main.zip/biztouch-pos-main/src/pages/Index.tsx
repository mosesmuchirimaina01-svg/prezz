import { Helmet } from "react-helmet-async";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect, useState } from "react";
import { ShoppingCart, Shield, Building, Settings, Database } from "lucide-react";
import { SystemPasswordDialog } from "@/components/SystemPasswordDialog";
import { CompanyHeader } from "@/components/shared/CompanyHeader";
import { ConnectionPrompt } from "@/components/connection/ConnectionPrompt";
import { ModuleLoginDialog } from "@/components/connection/ModuleLoginDialog";
import { UpdateCheck } from "@/components/ui/update-check";

const Index = () => {
  const { user, profile, loading, signOut, selectedCompany } = useAuth();
  const navigate = useNavigate();
  const [showConnectionPrompt, setShowConnectionPrompt] = useState(false);
  const [showModuleLogin, setShowModuleLogin] = useState(false);
  const [showSystemDialog, setShowSystemDialog] = useState(false);
  const [selectedModule, setSelectedModule] = useState('');
  const [pendingRoute, setPendingRoute] = useState<string>('');

  useEffect(() => {
    // Check if company is selected
    if (!loading && user && !selectedCompany) {
      setShowConnectionPrompt(true);
    }
  }, [user, loading, selectedCompany]);

  const handleConnectionSuccess = () => {
    setShowConnectionPrompt(false);
  };

  const handleTabClick = (route: string, moduleName: string) => {
    if (!selectedCompany) {
      setShowConnectionPrompt(true);
      return;
    }

    if (route === '/system' || route === '/connection') {
      setShowSystemDialog(true);
      setPendingRoute(route);
      return;
    }

    // Check if module is already logged in this session
    const isModuleLoggedIn = sessionStorage.getItem(`${moduleName.toLowerCase()}_logged_in`) === 'true';
    
    if (isModuleLoggedIn) {
      navigate(route);
    } else {
      setSelectedModule(moduleName);
      setPendingRoute(route);
      setShowModuleLogin(true);
    }
  };

  const handleModuleLoginSuccess = () => {
    setShowModuleLogin(false);
    navigate(pendingRoute);
  };

  const handleSystemSuccess = () => {
    setShowSystemDialog(false);
    navigate(pendingRoute);
  };

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  if (showConnectionPrompt) {
    return <ConnectionPrompt onConnectionSuccess={handleConnectionSuccess} />;
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold">Loading...</h2>
        </div>
      </div>
    );
  }

  if (!user || !profile) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Helmet>
        <title>GB PAWA POS – Point of Sale System</title>
        <meta name="description" content="GB PAWA POS - Professional Point of Sale System" />
        <link rel="canonical" href={typeof window !== 'undefined' ? window.location.href : '/'} />
      </Helmet>

      <CompanyHeader title="GB PAWA POS - Main Menu" />

      {/* Update Check Button - Top Left */}
      <div className="absolute top-20 left-4">
        <UpdateCheck />
      </div>

      <div className="flex-1 flex items-center justify-center">
        <div className="text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-3xl md:text-5xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              Welcome to GB PAWA POS
            </h1>
            {selectedCompany && (
              <p className="text-lg text-muted-foreground">
                Connected to <span className="font-semibold text-primary">{selectedCompany.name}</span>
              </p>
            )}
          </div>
          
          <div className="flex flex-wrap justify-center items-center gap-[1cm]">
            <Button 
              size="lg" 
              className="w-32 h-32 bg-blue-500 hover:bg-blue-600 text-white text-sm cursor-pointer flex flex-col items-center gap-2 disabled:opacity-50" 
              onClick={() => handleTabClick('/cashier', 'Cashier')}
              disabled={!selectedCompany}
            >
              <ShoppingCart className="h-6 w-6" />
              CASHIER
            </Button>
            

            <Button 
              size="lg" 
              className="w-32 h-32 bg-orange-500 hover:bg-orange-600 text-white text-sm cursor-pointer flex flex-col items-center gap-2 disabled:opacity-50" 
              onClick={() => handleTabClick('/backoffice', 'Backoffice')}
              disabled={!selectedCompany}
            >
              <Building className="h-6 w-6" />
              BACKOFFICE
            </Button>
            
            <Button 
              size="lg" 
              className="w-32 h-32 bg-red-500 hover:bg-red-600 text-white text-sm cursor-pointer flex flex-col items-center gap-2" 
              onClick={() => handleTabClick('/system', 'System')}
            >
              <Settings className="h-6 w-6" />
              SYSTEM
            </Button>

            <Button 
              size="lg" 
              className="w-32 h-32 bg-purple-500 hover:bg-purple-600 text-white text-sm cursor-pointer flex flex-col items-center gap-2" 
              onClick={() => handleTabClick('/connection', 'Connection')}
            >
              <Database className="h-6 w-6" />
              CONNECTION
            </Button>
          </div>
          
          {!selectedCompany && (
            <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm text-amber-800">
                Please <Link to="/auth" className="underline font-medium">login and select a company</Link> to access Cashier, Admin, and Backoffice modules.
              </p>
            </div>
          )}
        </div>
      </div>

      <ModuleLoginDialog
        open={showModuleLogin}
        onOpenChange={setShowModuleLogin}
        moduleName={selectedModule}
        onSuccess={handleModuleLoginSuccess}
      />

      <SystemPasswordDialog
        open={showSystemDialog}
        onOpenChange={setShowSystemDialog}
        onSuccess={handleSystemSuccess}
        action="access system management"
      />
    </div>
  );
};

export default Index;

