import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { CompanyHeader } from '@/components/shared/CompanyHeader';
import { ConnectionManager } from '@/components/connection/ConnectionManager';
import { useAuth } from '@/contexts/AuthContext';

const ConnectionManagement: React.FC = () => {
  const { signOut } = useAuth();

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      <Helmet>
        <title>GB PAWA POS - Connection Management</title>
        <meta name="description" content="Manage your database connections" />
      </Helmet>

      <header className="shrink-0">
        <CompanyHeader title="GB PAWA POS - Connection Management" showCompanyInfo={false} />
        <div className="border-b p-2 flex items-center justify-between">
          <Button size="sm" variant="outline" asChild>
            <Link to="/">
              <ArrowLeft className="h-3 w-3 mr-1" />
              Home
            </Link>
          </Button>
          <Button size="sm" variant="destructive" onClick={signOut}>
            Logout
          </Button>
        </div>
      </header>

      <div className="flex-1 overflow-hidden">
        <div className="h-full p-6 overflow-auto">
          <ConnectionManager />
        </div>
      </div>
    </div>
  );
};

export default ConnectionManagement;