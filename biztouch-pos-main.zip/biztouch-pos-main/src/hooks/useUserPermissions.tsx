import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import React from 'react';

export interface UserPermissions {
  // Cashier permissions
  canDeleteItems: boolean;
  canProcessExpenses: boolean;
  canHoldBills: boolean;
  canUnholdBills: boolean;
  canClearBills: boolean;
  canProcessPayments: boolean;
  canViewSales: boolean;
  canPrintReceipts: boolean;
  
  // Admin permissions
  canViewReports: boolean;
  canManageUsers: boolean;
  canManageStock: boolean;
  canViewAnalytics: boolean;
  canManageSystem: boolean;
  canViewExpenses: boolean;
  canManageSuppliers: boolean;
  canChangePrices: boolean;
  
  // Backoffice permissions
  canCreateSuppliers: boolean;
  canEditSuppliers: boolean;
  canViewSupplierBalances: boolean;
  canAddStock: boolean;
  canInputInvoices: boolean;
  canViewInventory: boolean;
  canCreatePurchaseOrders: boolean;
  
  // Role-based access
  role: string;
  isAdmin: boolean;
  isManager: boolean;
  isSupervisor: boolean;
  isCashier: boolean;
}

export const useUserPermissions = (): UserPermissions => {
  const { user } = useAuth();
  const [userRole, setUserRole] = React.useState<string>('cashier');
  const [customPermissions, setCustomPermissions] = React.useState<Record<string, boolean>>({});

  React.useEffect(() => {
    const fetchUserRoleAndPermissions = async () => {
      if (!user) return;

      // Fetch role from user_roles table
      const { data: roleData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .order('role')
        .limit(1)
        .maybeSingle();

      if (roleData) {
        setUserRole(roleData.role);
      }

      // Fetch custom permissions
      const { data: permsData } = await supabase
        .from('user_permissions')
        .select('permission_key, enabled')
        .eq('user_id', user.id);

      if (permsData) {
        const permsMap = permsData.reduce((acc, p) => {
          acc[p.permission_key] = p.enabled;
          return acc;
        }, {} as Record<string, boolean>);
        setCustomPermissions(permsMap);
      }
    };

    fetchUserRoleAndPermissions();
  }, [user]);

  const role = userRole;
  const isAdmin = role === 'admin';
  const isManager = role === 'manager';
  const isSupervisor = role === 'supervisor';
  const isCashier = role === 'cashier';
  
  // Define permission sets based on roles
  const adminPermissions = {
    canDeleteItems: true,
    canProcessExpenses: true,
    canHoldBills: true,
    canUnholdBills: true,
    canClearBills: true,
    canProcessPayments: true,
    canViewSales: true,
    canPrintReceipts: true,
    canViewReports: true,
    canManageUsers: true,
    canManageStock: true,
    canViewAnalytics: true,
    canManageSystem: true,
    canViewExpenses: true,
    canManageSuppliers: true,
    canChangePrices: true,
    canCreateSuppliers: true,
    canEditSuppliers: true,
    canViewSupplierBalances: true,
    canAddStock: true,
    canInputInvoices: true,
    canViewInventory: true,
    canCreatePurchaseOrders: true,
  };
  
  const managerPermissions = {
    canDeleteItems: true,
    canProcessExpenses: true,
    canHoldBills: true,
    canUnholdBills: true,
    canClearBills: true,
    canProcessPayments: true,
    canViewSales: true,
    canPrintReceipts: true,
    canViewReports: true,
    canManageUsers: false,
    canManageStock: true,
    canViewAnalytics: true,
    canManageSystem: false,
    canViewExpenses: true,
    canManageSuppliers: true,
    canChangePrices: true,
    canCreateSuppliers: true,
    canEditSuppliers: true,
    canViewSupplierBalances: true,
    canAddStock: true,
    canInputInvoices: true,
    canViewInventory: true,
    canCreatePurchaseOrders: true,
  };
  
  const supervisorPermissions = {
    canDeleteItems: customPermissions.can_delete_items ?? true,
    canProcessExpenses: customPermissions.can_process_expenses ?? true,
    canHoldBills: true,
    canUnholdBills: true,
    canClearBills: true,
    canProcessPayments: true,
    canViewSales: true,
    canPrintReceipts: true,
    canViewReports: customPermissions.can_view_reports ?? true,
    canManageUsers: false,
    canManageStock: customPermissions.can_manage_stock ?? true,
    canViewAnalytics: false,
    canManageSystem: false,
    canViewExpenses: customPermissions.can_view_expenses ?? true,
    canManageSuppliers: false,
    canChangePrices: false,
    canCreateSuppliers: false,
    canEditSuppliers: false,
    canViewSupplierBalances: true,
    canAddStock: true,
    canInputInvoices: true,
    canViewInventory: true,
    canCreatePurchaseOrders: false,
  };
  
  const cashierPermissions = {
    canDeleteItems: customPermissions.can_delete_items ?? false,
    canProcessExpenses: customPermissions.can_process_expenses ?? false,
    canHoldBills: customPermissions.can_hold_bills ?? true,
    canUnholdBills: customPermissions.can_unhold_bills ?? true,
    canClearBills: customPermissions.can_clear_bills ?? true,
    canProcessPayments: true,
    canViewSales: true,
    canPrintReceipts: true,
    canViewReports: false,
    canManageUsers: false,
    canManageStock: false,
    canViewAnalytics: false,
    canManageSystem: false,
    canViewExpenses: false,
    canManageSuppliers: false,
    canChangePrices: false,
    canCreateSuppliers: false,
    canEditSuppliers: false,
    canViewSupplierBalances: false,
    canAddStock: false,
    canInputInvoices: false,
    canViewInventory: false,
    canCreatePurchaseOrders: false,
  };
  
  let permissions: Omit<UserPermissions, 'role' | 'isAdmin' | 'isManager' | 'isSupervisor' | 'isCashier'>;
  
  if (isAdmin) {
    permissions = adminPermissions;
  } else if (isManager) {
    permissions = managerPermissions;
  } else if (isSupervisor) {
    permissions = supervisorPermissions;
  } else {
    permissions = cashierPermissions;
  }
  
  return {
    ...permissions,
    role,
    isAdmin,
    isManager,
    isSupervisor,
    isCashier,
  };
};
