import { useEffect } from 'react';

interface KeyboardShortcutHandlers {
  onF1?: () => void;
  onF2?: () => void;
  onF3?: () => void;
  onM?: () => void;
  onB?: () => void;
  onC?: () => void;
  onEnd?: () => void;
}

export const useKeyboardShortcuts = (handlers: KeyboardShortcutHandlers) => {
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Prevent shortcuts when typing in inputs
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) {
        return;
      }

      switch (event.key) {
        case 'F1':
          event.preventDefault();
          handlers.onF1?.();
          break;
        case 'F2':
          event.preventDefault();
          handlers.onF2?.();
          break;
        case 'F3':
          event.preventDefault();
          handlers.onF3?.();
          break;
        case 'm':
        case 'M':
          if (!event.ctrlKey && !event.altKey) {
            handlers.onM?.();
          }
          break;
        case 'b':
        case 'B':
          if (!event.ctrlKey && !event.altKey) {
            handlers.onB?.();
          }
          break;
        case 'c':
        case 'C':
          if (!event.ctrlKey && !event.altKey) {
            handlers.onC?.();
          }
          break;
        case 'End':
          event.preventDefault();
          handlers.onEnd?.();
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [handlers]);
};