-- Clean up all default/demo data
DELETE FROM sale_items;
DELETE FROM sales;
DELETE FROM held_bill_items;
DELETE FROM held_bills;
DELETE FROM invoice_items;
DELETE FROM invoices;
DELETE FROM order_items;
DELETE FROM purchase_orders;
DELETE FROM stock_adjustments;
DELETE FROM stock_movements;
DELETE FROM expenses;
DELETE FROM shifts;
DELETE FROM products;
DELETE FROM categories;
DELETE FROM suppliers;
DELETE FROM user_permissions;
DELETE FROM user_roles;
DELETE FROM profiles WHERE user_id NOT IN (SELECT id FROM auth.users WHERE email = 'system@admin.local');
DELETE FROM companies;

-- Create system settings for system password
INSERT INTO system_settings (key, value, description) 
VALUES ('system_password', crypt('SysAdmin2025!', gen_salt('bf')), 'System password for accessing sensitive areas (hashed)')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- Add company schema support
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS company_schema text;
CREATE INDEX IF NOT EXISTS idx_profiles_company_schema ON profiles(company_schema);

-- Update companies table to store schema information
ALTER TABLE companies ADD COLUMN IF NOT EXISTS schema_name text UNIQUE;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS admin_email text;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS admin_temp_password text;

-- Function to create isolated company schema
CREATE OR REPLACE FUNCTION create_company_schema(company_id uuid, schema_name text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Create schema for company
  EXECUTE format('CREATE SCHEMA IF NOT EXISTS %I', schema_name);
  
  -- Grant usage to authenticated role
  EXECUTE format('GRANT USAGE ON SCHEMA %I TO authenticated', schema_name);
  
  -- Create company-specific tables in the schema
  EXECUTE format('
    CREATE TABLE IF NOT EXISTS %I.products (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      code text NOT NULL,
      name text NOT NULL,
      description text,
      price numeric(10,2) NOT NULL,
      cost_price numeric(10,2),
      stock_quantity integer DEFAULT 0,
      min_stock_level integer DEFAULT 0,
      category_id uuid,
      supplier_id uuid,
      is_active boolean DEFAULT true,
      blocked_from_selling boolean DEFAULT false,
      created_at timestamptz DEFAULT now(),
      updated_at timestamptz DEFAULT now()
    )', schema_name);
  
  -- Grant permissions
  EXECUTE format('GRANT ALL ON ALL TABLES IN SCHEMA %I TO authenticated', schema_name);
  
  -- Update company record
  UPDATE companies SET schema_name = create_company_schema.schema_name WHERE id = company_id;
END;
$$;