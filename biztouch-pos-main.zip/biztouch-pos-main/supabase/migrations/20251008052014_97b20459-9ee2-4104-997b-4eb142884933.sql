-- Add unique constraint to id_number in profiles table (where not null)
CREATE UNIQUE INDEX IF NOT EXISTS profiles_id_number_unique 
ON public.profiles(id_number) 
WHERE id_number IS NOT NULL;

-- Add index for better performance on id_number lookups
CREATE INDEX IF NOT EXISTS idx_profiles_id_number ON public.profiles(id_number);

-- Create invoice table for stock input
CREATE TABLE IF NOT EXISTS public.invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number text NOT NULL UNIQUE,
  supplier_id uuid REFERENCES public.suppliers(id),
  company_id uuid REFERENCES public.companies(id),
  invoice_date date NOT NULL DEFAULT CURRENT_DATE,
  total_amount numeric DEFAULT 0,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'processed', 'cancelled')),
  created_by uuid REFERENCES auth.users(id),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on invoices
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

-- RLS policy for invoices
CREATE POLICY "Users can manage invoices in their company"
ON public.invoices
FOR ALL
USING (
  company_id = get_user_company_id() AND
  (
    get_user_role_from_table(auth.uid()) = ANY(ARRAY['admin', 'manager', 'supervisor']::user_role[])
  )
);

-- Create invoice items table
CREATE TABLE IF NOT EXISTS public.invoice_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid REFERENCES public.invoices(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.products(id),
  quantity integer NOT NULL CHECK (quantity > 0),
  unit_price numeric NOT NULL,
  total_price numeric NOT NULL,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on invoice_items
ALTER TABLE public.invoice_items ENABLE ROW LEVEL SECURITY;

-- RLS policy for invoice_items
CREATE POLICY "Users can view invoice items for accessible invoices"
ON public.invoice_items
FOR SELECT
USING (
  invoice_id IN (SELECT id FROM public.invoices)
);

CREATE POLICY "Users can manage invoice items"
ON public.invoice_items
FOR ALL
USING (
  invoice_id IN (
    SELECT id FROM public.invoices 
    WHERE get_user_role_from_table(auth.uid()) = ANY(ARRAY['admin', 'manager', 'supervisor']::user_role[])
  )
);

-- Create trigger for updated_at on invoices
CREATE TRIGGER update_invoices_updated_at
BEFORE UPDATE ON public.invoices
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();