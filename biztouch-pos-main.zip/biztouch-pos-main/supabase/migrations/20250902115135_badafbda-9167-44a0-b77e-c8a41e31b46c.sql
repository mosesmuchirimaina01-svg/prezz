-- Create companies table for multi-tenant POS system
CREATE TABLE public.companies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  contact_person TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT NOT NULL,
  address TEXT,
  subscription_type TEXT NOT NULL DEFAULT 'basic' CHECK (subscription_type IN ('basic', 'premium', 'enterprise')),
  expiry_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'expired', 'suspended')),
  database_name TEXT NOT NULL UNIQUE,
  database_url TEXT,
  connection_string TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_payment DATE,
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- Enable Row Level Security
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

-- Create policy for system admins to manage companies
CREATE POLICY "System admins can manage companies" 
ON public.companies 
FOR ALL 
USING (get_user_role(auth.uid()) = 'admin');

-- Create policy for users to view active companies (for login selection)
CREATE POLICY "Users can view active companies" 
ON public.companies 
FOR SELECT 
USING (is_active = true AND status = 'active');

-- Add company_id to profiles table to link users to companies
ALTER TABLE public.profiles ADD COLUMN company_id UUID REFERENCES public.companies(id);

-- Create updated_at trigger for companies table
CREATE TRIGGER update_companies_updated_at
BEFORE UPDATE ON public.companies
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample companies
INSERT INTO public.companies (name, contact_person, email, phone, address, subscription_type, expiry_date, database_name, database_url, connection_string) VALUES
('ABC Retail Store', 'John Doe', 'admin@abcretail.com', '+254712345678', '123 Main St, Nairobi', 'premium', '2024-12-31', 'abc_retail_pos', 'https://abc-retail-pos.supabase.co', 'postgresql://postgres:[PASSWORD]@abc-retail-pos.supabase.co:5432/postgres'),
('XYZ Electronics', 'Jane Smith', 'admin@xyzelec.com', '+254798765432', '456 Tech Ave, Mombasa', 'basic', '2024-08-30', 'xyz_electronics_pos', 'https://xyz-electronics-pos.supabase.co', 'postgresql://postgres:[PASSWORD]@xyz-electronics-pos.supabase.co:5432/postgres'),
('DEF Pharmacy', 'Mike Johnson', 'admin@defpharmacy.com', '+254711223344', '789 Health St, Kisumu', 'enterprise', '2025-03-15', 'def_pharmacy_pos', 'https://def-pharmacy-pos.supabase.co', 'postgresql://postgres:[PASSWORD]@def-pharmacy-pos.supabase.co:5432/postgres');