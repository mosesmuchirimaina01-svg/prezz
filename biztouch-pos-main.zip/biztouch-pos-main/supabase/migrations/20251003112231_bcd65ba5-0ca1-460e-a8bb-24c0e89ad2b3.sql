-- Fix payment issue: Allow NULL shift_id
-- This was already done in previous migration, so we'll skip this part

-- CRITICAL SECURITY FIX: Add company_id to all tables for data isolation
-- Add company_id column to products table
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE;

-- Add company_id column to categories table
ALTER TABLE public.categories ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE;

-- Add company_id column to suppliers table
ALTER TABLE public.suppliers ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE;

-- Add company_id column to sales table
ALTER TABLE public.sales ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE;

-- Add company_id column to shifts table
ALTER TABLE public.shifts ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE;

-- Add company_id column to held_bills table
ALTER TABLE public.held_bills ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE;

-- Add company_id column to expenses table
ALTER TABLE public.expenses ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE;

-- Add company_id column to purchase_orders table
ALTER TABLE public.purchase_orders ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE;

-- Add company_id column to stock_adjustments table
ALTER TABLE public.stock_adjustments ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE;

-- Add company_id column to stock_movements table
ALTER TABLE public.stock_movements ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES public.companies(id) ON DELETE CASCADE;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_products_company_id ON public.products(company_id);
CREATE INDEX IF NOT EXISTS idx_categories_company_id ON public.categories(company_id);
CREATE INDEX IF NOT EXISTS idx_suppliers_company_id ON public.suppliers(company_id);
CREATE INDEX IF NOT EXISTS idx_sales_company_id ON public.sales(company_id);
CREATE INDEX IF NOT EXISTS idx_shifts_company_id ON public.shifts(company_id);
CREATE INDEX IF NOT EXISTS idx_held_bills_company_id ON public.held_bills(company_id);
CREATE INDEX IF NOT EXISTS idx_expenses_company_id ON public.expenses(company_id);
CREATE INDEX IF NOT EXISTS idx_purchase_orders_company_id ON public.purchase_orders(company_id);

-- Drop existing RLS policies that don't filter by company
DROP POLICY IF EXISTS "Everyone can view active products" ON public.products;
DROP POLICY IF EXISTS "Admins and managers can manage products" ON public.products;
DROP POLICY IF EXISTS "Everyone can view active categories" ON public.categories;
DROP POLICY IF EXISTS "Admins and managers can manage categories" ON public.categories;
DROP POLICY IF EXISTS "Everyone can view active suppliers" ON public.suppliers;
DROP POLICY IF EXISTS "Admins and managers can manage suppliers" ON public.suppliers;
DROP POLICY IF EXISTS "Users can view relevant sales" ON public.sales;
DROP POLICY IF EXISTS "Cashiers can create sales" ON public.sales;
DROP POLICY IF EXISTS "Cashiers can manage their own shifts" ON public.shifts;
DROP POLICY IF EXISTS "Users can view their own shifts" ON public.shifts;
DROP POLICY IF EXISTS "Cashiers can manage held bills" ON public.held_bills;
DROP POLICY IF EXISTS "Users can view relevant expenses" ON public.expenses;
DROP POLICY IF EXISTS "Authorized users can create expenses" ON public.expenses;
DROP POLICY IF EXISTS "Authorized users can manage purchase orders" ON public.purchase_orders;
DROP POLICY IF EXISTS "Authorized users can create stock adjustments" ON public.stock_adjustments;
DROP POLICY IF EXISTS "Everyone can view stock adjustments" ON public.stock_adjustments;
DROP POLICY IF EXISTS "Authorized users can create stock movements" ON public.stock_movements;
DROP POLICY IF EXISTS "Everyone can view stock movements" ON public.stock_movements;

-- Create helper function to get user's company_id
CREATE OR REPLACE FUNCTION public.get_user_company_id()
RETURNS uuid
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT company_id FROM public.profiles WHERE user_id = auth.uid();
$$;

-- NEW RLS POLICIES WITH COMPANY ISOLATION

-- Products policies
CREATE POLICY "Users can view products from their company"
ON public.products FOR SELECT
USING (company_id = public.get_user_company_id() AND is_active = true);

CREATE POLICY "Admins and managers can manage products in their company"
ON public.products FOR ALL
USING (
  company_id = public.get_user_company_id() 
  AND get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role])
);

-- Categories policies
CREATE POLICY "Users can view categories from their company"
ON public.categories FOR SELECT
USING (company_id = public.get_user_company_id() AND is_active = true);

CREATE POLICY "Admins and managers can manage categories in their company"
ON public.categories FOR ALL
USING (
  company_id = public.get_user_company_id()
  AND get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role])
);

-- Suppliers policies
CREATE POLICY "Users can view suppliers from their company"
ON public.suppliers FOR SELECT
USING (company_id = public.get_user_company_id() AND is_active = true);

CREATE POLICY "Admins and managers can manage suppliers in their company"
ON public.suppliers FOR ALL
USING (
  company_id = public.get_user_company_id()
  AND get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role])
);

-- Sales policies
CREATE POLICY "Users can view sales from their company"
ON public.sales FOR SELECT
USING (
  company_id = public.get_user_company_id()
  AND (
    cashier_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())
    OR get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role])
  )
);

CREATE POLICY "Cashiers can create sales in their company"
ON public.sales FOR INSERT
WITH CHECK (
  company_id = public.get_user_company_id()
  AND cashier_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())
);

-- Shifts policies
CREATE POLICY "Users can manage shifts in their company"
ON public.shifts FOR ALL
USING (
  company_id = public.get_user_company_id()
  AND (
    cashier_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())
    OR get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role])
  )
);

-- Held bills policies
CREATE POLICY "Users can manage held bills in their company"
ON public.held_bills FOR ALL
USING (
  company_id = public.get_user_company_id()
  AND (
    held_by IN (SELECT id FROM profiles WHERE user_id = auth.uid())
    OR get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role])
  )
);

-- Expenses policies
CREATE POLICY "Users can view expenses from their company"
ON public.expenses FOR SELECT
USING (
  company_id = public.get_user_company_id()
  AND (
    cashier_id IN (SELECT id FROM profiles WHERE user_id = auth.uid())
    OR authorized_by IN (SELECT id FROM profiles WHERE user_id = auth.uid())
    OR get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role])
  )
);

CREATE POLICY "Authorized users can create expenses in their company"
ON public.expenses FOR INSERT
WITH CHECK (
  company_id = public.get_user_company_id()
  AND get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role, 'cashier'::user_role])
);

-- Purchase orders policies
CREATE POLICY "Users can manage purchase orders in their company"
ON public.purchase_orders FOR ALL
USING (
  company_id = public.get_user_company_id()
  AND get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role])
);

-- Stock adjustments policies
CREATE POLICY "Users can view stock adjustments from their company"
ON public.stock_adjustments FOR SELECT
USING (company_id = public.get_user_company_id());

CREATE POLICY "Authorized users can create stock adjustments in their company"
ON public.stock_adjustments FOR INSERT
WITH CHECK (
  company_id = public.get_user_company_id()
  AND get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role])
);

-- Stock movements policies
CREATE POLICY "Users can view stock movements from their company"
ON public.stock_movements FOR SELECT
USING (company_id = public.get_user_company_id());

CREATE POLICY "Authorized users can create stock movements in their company"
ON public.stock_movements FOR INSERT
WITH CHECK (
  company_id = public.get_user_company_id()
  AND get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role])
);