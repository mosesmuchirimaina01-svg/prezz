-- Create function to handle new user profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (
    user_id,
    username,
    full_name,
    role,
    is_active,
    company_id
  ) VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'role', 'cashier'),
    true,
    (NEW.raw_user_meta_data->>'company_id')::uuid
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically create profile on user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Insert profile for existing admin user
INSERT INTO public.profiles (
  user_id,
  username,
  full_name,
  role,
  is_active,
  company_id
) VALUES (
  '5376bc48-bfee-4971-99ad-7620f2bf3f7c',
  'admin',
  'Administrator',
  'admin',
  true,
  '502a5139-2d52-4146-aebd-b28e13cdb0b4'
) ON CONFLICT (user_id) DO NOTHING;