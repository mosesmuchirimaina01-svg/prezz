-- Ensure profile auto-creation on new users
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'on_auth_user_created'
  ) THEN
    CREATE TRIGGER on_auth_user_created
      AFTER INSERT ON auth.users
      FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();
  END IF;
END $$;

-- Seed admin profile if missing (required for cashier sales and permissions)
INSERT INTO public.profiles (id, user_id, username, full_name, role, is_active)
SELECT gen_random_uuid(), u.id, 'admin', 'Administrator', 'admin', true
FROM auth.users u
LEFT JOIN public.profiles p ON p.user_id = u.id
WHERE u.email = 'admin@company.local' AND p.user_id IS NULL;