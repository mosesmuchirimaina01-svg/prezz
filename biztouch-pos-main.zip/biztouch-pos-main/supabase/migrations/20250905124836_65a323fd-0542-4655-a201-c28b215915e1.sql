-- Fix critical security vulnerability: Restrict companies table access to admins only
-- Drop the overly permissive policy that allows all users to view companies
DROP POLICY IF EXISTS "Users can view active companies" ON public.companies;

-- Create a new restrictive policy that only allows system admins to view companies
CREATE POLICY "Only system admins can view companies" 
ON public.companies 
FOR SELECT 
USING (get_user_role(auth.uid()) = 'admin'::user_role);

-- Verify the existing admin management policy is still in place
-- (This policy should already exist and allows admins to manage companies)