-- Update companies RLS policy to allow everyone to view active companies for login
DROP POLICY IF EXISTS "Only system admins can view companies" ON companies;

CREATE POLICY "Everyone can view active companies" ON companies
FOR SELECT USING (is_active = true AND status = 'active');

-- Keep the admin-only management policy
-- "System admins can manage companies" policy remains unchanged