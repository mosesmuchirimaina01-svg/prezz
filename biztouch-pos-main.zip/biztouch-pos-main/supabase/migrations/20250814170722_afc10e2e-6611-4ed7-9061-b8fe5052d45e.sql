-- Create payment methods enum
CREATE TYPE public.payment_method AS ENUM ('cash', 'mpesa', 'bank');

-- Create shift status enum
CREATE TYPE public.shift_status AS ENUM ('open', 'closed');

-- Create profiles table for user management
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'cashier',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create categories table
CREATE TABLE public.categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create products/catalog table
CREATE TABLE public.products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category_id UUID REFERENCES public.categories(id),
  price DECIMAL(10,2) NOT NULL,
  cost_price DECIMAL(10,2),
  stock_quantity INTEGER NOT NULL DEFAULT 0,
  min_stock_level INTEGER DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  blocked_from_selling BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create shifts table
CREATE TABLE public.shifts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  cashier_id UUID NOT NULL REFERENCES public.profiles(id),
  opened_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  closed_at TIMESTAMP WITH TIME ZONE,
  opening_cash DECIMAL(10,2) NOT NULL DEFAULT 0,
  closing_cash DECIMAL(10,2),
  status shift_status NOT NULL DEFAULT 'open',
  notes TEXT
);

-- Create sales table
CREATE TABLE public.sales (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  cashier_id UUID NOT NULL REFERENCES public.profiles(id),
  shift_id UUID NOT NULL REFERENCES public.shifts(id),
  total_amount DECIMAL(10,2) NOT NULL,
  payment_method payment_method NOT NULL,
  tax_amount DECIMAL(10,2) DEFAULT 0,
  discount_amount DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create sale items table
CREATE TABLE public.sale_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sale_id UUID NOT NULL REFERENCES public.sales(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id),
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  total_price DECIMAL(10,2) NOT NULL
);

-- Create expenses table
CREATE TABLE public.expenses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  cashier_id UUID NOT NULL REFERENCES public.profiles(id),
  authorized_by UUID REFERENCES public.profiles(id),
  shift_id UUID REFERENCES public.shifts(id),
  amount DECIMAL(10,2) NOT NULL,
  reason TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create stock movements table
CREATE TABLE public.stock_movements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES public.products(id),
  user_id UUID NOT NULL REFERENCES public.profiles(id),
  movement_type TEXT NOT NULL, -- 'in', 'out', 'adjustment'
  quantity INTEGER NOT NULL,
  reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create system settings table
CREATE TABLE public.system_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  value TEXT NOT NULL,
  description TEXT,
  updated_by UUID REFERENCES public.profiles(id),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sale_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

-- Create security definer function for getting user role
CREATE OR REPLACE FUNCTION public.get_user_role(user_uuid UUID)
RETURNS user_role AS $$
  SELECT role FROM public.profiles WHERE user_id = user_uuid;
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Create RLS policies for profiles
CREATE POLICY "Users can view all active profiles" ON public.profiles
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can insert profiles" ON public.profiles
  FOR INSERT WITH CHECK (public.get_user_role(auth.uid()) = 'admin');

CREATE POLICY "Admins can update profiles" ON public.profiles
  FOR UPDATE USING (public.get_user_role(auth.uid()) = 'admin');

-- Create RLS policies for categories
CREATE POLICY "Everyone can view active categories" ON public.categories
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins and managers can manage categories" ON public.categories
  FOR ALL USING (public.get_user_role(auth.uid()) IN ('admin', 'manager'));

-- Create RLS policies for products
CREATE POLICY "Everyone can view active products" ON public.products
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins and managers can manage products" ON public.products
  FOR ALL USING (public.get_user_role(auth.uid()) IN ('admin', 'manager'));

-- Create RLS policies for shifts
CREATE POLICY "Users can view their own shifts" ON public.shifts
  FOR SELECT USING (
    cashier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
    OR public.get_user_role(auth.uid()) IN ('admin', 'manager', 'supervisor')
  );

CREATE POLICY "Cashiers can manage their own shifts" ON public.shifts
  FOR ALL USING (
    cashier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
    OR public.get_user_role(auth.uid()) IN ('admin', 'manager', 'supervisor')
  );

-- Create RLS policies for sales
CREATE POLICY "Users can view relevant sales" ON public.sales
  FOR SELECT USING (
    cashier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
    OR public.get_user_role(auth.uid()) IN ('admin', 'manager', 'supervisor')
  );

CREATE POLICY "Cashiers can create sales" ON public.sales
  FOR INSERT WITH CHECK (
    cashier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  );

-- Create RLS policies for sale items
CREATE POLICY "Users can view sale items for accessible sales" ON public.sale_items
  FOR SELECT USING (
    sale_id IN (
      SELECT id FROM public.sales WHERE 
      cashier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
      OR public.get_user_role(auth.uid()) IN ('admin', 'manager', 'supervisor')
    )
  );

CREATE POLICY "Cashiers can create sale items" ON public.sale_items
  FOR INSERT WITH CHECK (
    sale_id IN (
      SELECT id FROM public.sales WHERE 
      cashier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
    )
  );

-- Create RLS policies for expenses
CREATE POLICY "Users can view relevant expenses" ON public.expenses
  FOR SELECT USING (
    cashier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
    OR authorized_by IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
    OR public.get_user_role(auth.uid()) IN ('admin', 'manager', 'supervisor')
  );

CREATE POLICY "Authorized users can create expenses" ON public.expenses
  FOR INSERT WITH CHECK (
    public.get_user_role(auth.uid()) IN ('admin', 'manager', 'supervisor', 'cashier')
  );

-- Create RLS policies for stock movements
CREATE POLICY "Everyone can view stock movements" ON public.stock_movements
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authorized users can create stock movements" ON public.stock_movements
  FOR INSERT WITH CHECK (
    public.get_user_role(auth.uid()) IN ('admin', 'manager', 'supervisor')
  );

-- Create RLS policies for system settings
CREATE POLICY "Everyone can view system settings" ON public.system_settings
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage system settings" ON public.system_settings
  FOR ALL USING (public.get_user_role(auth.uid()) = 'admin');

-- Insert default categories
INSERT INTO public.categories (name, description) VALUES
  ('Beverages', 'All drinks and beverages'),
  ('Snacks', 'Snacks and light foods'),
  ('Groceries', 'General grocery items'),
  ('Services', 'Service-based items');

-- Insert default system settings
INSERT INTO public.system_settings (key, value, description) VALUES
  ('company_name', 'SpankiPOS', 'Company name displayed in the system'),
  ('tax_rate', '16', 'Default tax rate percentage'),
  ('currency', 'KES', 'Default currency'),
  ('theme', 'light', 'System theme'),
  ('supervisor_password', 'supervisor123', 'Default supervisor password'),
  ('require_supervisor_for_delete', 'true', 'Require supervisor password for deletions'),
  ('require_supervisor_for_expenses', 'true', 'Require supervisor password for expenses');

-- Create trigger function for updating timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updating timestamps
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_products_updated_at
  BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to handle new user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, username, full_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'username', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email),
    COALESCE((NEW.raw_user_meta_data ->> 'role')::user_role, 'cashier')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user registration
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();