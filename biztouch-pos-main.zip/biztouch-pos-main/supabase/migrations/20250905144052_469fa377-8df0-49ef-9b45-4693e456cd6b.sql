-- Create system settings for passwords if not exists
INSERT INTO public.system_settings (key, value, description) VALUES 
('system_password', '28132813', 'System password for accessing system features')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

INSERT INTO public.system_settings (key, value, description) VALUES 
('supervisor_password', '28132813', 'Supervisor password for accessing restricted features')  
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- Create stock_adjustments table for tracking manual stock adjustments
CREATE TABLE IF NOT EXISTS public.stock_adjustments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL,
    adjustment_type TEXT NOT NULL CHECK (adjustment_type IN ('stock_in', 'stock_out', 'adjustment')),
    quantity INTEGER NOT NULL,
    reason TEXT NOT NULL,
    notes TEXT,
    adjusted_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on stock_adjustments
ALTER TABLE public.stock_adjustments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for stock_adjustments
CREATE POLICY "Authorized users can create stock adjustments" ON public.stock_adjustments
FOR INSERT WITH CHECK (get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role]));

CREATE POLICY "Everyone can view stock adjustments" ON public.stock_adjustments
FOR SELECT USING (true);

-- Create trigger for stock_adjustments updated_at
CREATE TRIGGER update_stock_adjustments_updated_at
    BEFORE UPDATE ON public.stock_adjustments
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();