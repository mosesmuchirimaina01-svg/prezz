-- Create suppliers table
CREATE TABLE public.suppliers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  contact_person TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  address TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

-- Create policies for suppliers
CREATE POLICY "Admins and managers can manage suppliers"
ON public.suppliers
FOR ALL
USING (get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role]));

CREATE POLICY "Everyone can view active suppliers"
ON public.suppliers
FOR SELECT
USING (is_active = true);

-- Create purchase orders table
CREATE TABLE public.purchase_orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_number TEXT NOT NULL UNIQUE DEFAULT 'PO-' || extract(epoch from now())::text,
  supplier_id UUID NOT NULL REFERENCES public.suppliers(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'ordered', 'received', 'cancelled')),
  total_amount NUMERIC NOT NULL DEFAULT 0,
  order_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expected_delivery DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.purchase_orders ENABLE ROW LEVEL SECURITY;

-- Create policies for purchase orders
CREATE POLICY "Authorized users can manage purchase orders"
ON public.purchase_orders
FOR ALL
USING (get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role]));

-- Create order items table
CREATE TABLE public.order_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID NOT NULL REFERENCES public.purchase_orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit_price NUMERIC NOT NULL CHECK (unit_price >= 0),
  total_price NUMERIC NOT NULL CHECK (total_price >= 0),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

-- Create policies for order items
CREATE POLICY "Users can view order items for accessible orders"
ON public.order_items
FOR SELECT
USING (order_id IN (SELECT id FROM public.purchase_orders));

CREATE POLICY "Authorized users can manage order items"
ON public.order_items
FOR INSERT
WITH CHECK (get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role]));

-- Create held bills table
CREATE TABLE public.held_bills (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  bill_number TEXT NOT NULL UNIQUE,
  customer_name TEXT,
  total_amount NUMERIC NOT NULL DEFAULT 0,
  items_count INTEGER NOT NULL DEFAULT 0,
  hold_reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'held' CHECK (status IN ('held', 'unheld', 'cancelled')),
  held_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  unheld_at TIMESTAMP WITH TIME ZONE,
  held_by UUID NOT NULL REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.held_bills ENABLE ROW LEVEL SECURITY;

-- Create policies for held bills
CREATE POLICY "Cashiers can manage held bills"
ON public.held_bills
FOR ALL
USING (held_by IN (SELECT id FROM public.profiles WHERE user_id = auth.uid()) OR get_user_role(auth.uid()) = ANY (ARRAY['admin'::user_role, 'manager'::user_role, 'supervisor'::user_role]));

-- Create held bill items table
CREATE TABLE public.held_bill_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  held_bill_id UUID NOT NULL REFERENCES public.held_bills(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit_price NUMERIC NOT NULL CHECK (unit_price >= 0),
  total_price NUMERIC NOT NULL CHECK (total_price >= 0),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.held_bill_items ENABLE ROW LEVEL SECURITY;

-- Create policies for held bill items
CREATE POLICY "Users can view held bill items for accessible bills"
ON public.held_bill_items
FOR SELECT
USING (held_bill_id IN (SELECT id FROM public.held_bills));

CREATE POLICY "Cashiers can create held bill items"
ON public.held_bill_items
FOR INSERT
WITH CHECK (held_bill_id IN (SELECT id FROM public.held_bills WHERE held_by IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())));

-- Add supplier_id to products table if not exists
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'products' AND column_name = 'supplier_id') THEN
    ALTER TABLE public.products ADD COLUMN supplier_id UUID REFERENCES public.suppliers(id);
  END IF;
END $$;

-- Create triggers for updated_at timestamps
CREATE TRIGGER update_suppliers_updated_at
  BEFORE UPDATE ON public.suppliers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_purchase_orders_updated_at
  BEFORE UPDATE ON public.purchase_orders
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();