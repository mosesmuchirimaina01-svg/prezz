-- Insert default system company
INSERT INTO public.companies (
  name,
  contact_person,
  email,
  phone,
  address,
  subscription_type,
  expiry_date,
  status,
  database_name,
  schema_name,
  is_active
) VALUES (
  'GB PAWA POS',
  'System Admin',
  'spankiphalela07@gmail.com',
  '0790077128',
  'RUIRU HQ',
  'enterprise',
  (CURRENT_DATE + INTERVAL '365 days')::date,
  'active',
  'gb_pawa_pos_db',
  'gb_pawa_pos_db',
  true
) ON CONFLICT DO NOTHING;