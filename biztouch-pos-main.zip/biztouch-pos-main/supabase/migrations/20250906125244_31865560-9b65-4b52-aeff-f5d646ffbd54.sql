-- Update existing admin user credentials
UPDATE auth.users 
SET 
  email = 'admin@company.local',
  encrypted_password = crypt('28132813', gen_salt('bf')),
  raw_user_meta_data = '{"username": "admin", "full_name": "Administrator", "role": "admin"}',
  updated_at = NOW()
WHERE id = '5376bc48-bfee-4971-99ad-7620f2bf3f7c';