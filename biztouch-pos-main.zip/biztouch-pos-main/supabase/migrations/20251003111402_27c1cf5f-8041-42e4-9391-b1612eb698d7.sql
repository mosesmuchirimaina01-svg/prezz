-- Add new fields to profiles table for enhanced user management
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS phone_number text,
ADD COLUMN IF NOT EXISTS id_number text,
ADD COLUMN IF NOT EXISTS fingerprint text;

-- Add index for phone number lookup
CREATE INDEX IF NOT EXISTS idx_profiles_phone_number ON public.profiles(phone_number);

-- Add index for id number lookup
CREATE INDEX IF NOT EXISTS idx_profiles_id_number ON public.profiles(id_number);