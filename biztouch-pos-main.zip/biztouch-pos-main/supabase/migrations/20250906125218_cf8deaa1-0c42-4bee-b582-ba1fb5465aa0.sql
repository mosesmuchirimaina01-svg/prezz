-- Create admin user for existing profile
INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_user_meta_data,
  created_at,
  updated_at,
  confirmation_token,
  email_change,
  email_change_token_new,
  recovery_token
) VALUES (
  '00000000-0000-0000-0000-000000000000',
  '5376bc48-bfee-4971-99ad-7620f2bf3f7c',
  'authenticated',
  'authenticated',
  'admin@company.local',
  crypt('28132813', gen_salt('bf')),
  NOW(),
  '{"username": "admin", "full_name": "Administrator", "role": "admin"}',
  NOW(),
  NOW(),
  '',
  '',
  '',
  ''
);