-- Fix: Make shift_id nullable in sales table since not all sales require shifts
ALTER TABLE public.sales 
ALTER COLUMN shift_id DROP NOT NULL;

-- Verify company isolation by checking get_user_company_id function
-- This function should already exist and return the company_id from profiles table

-- Add index to improve query performance for company-based filtering
CREATE INDEX IF NOT EXISTS idx_products_company_id ON public.products(company_id);
CREATE INDEX IF NOT EXISTS idx_sales_company_id ON public.sales(company_id);
CREATE INDEX IF NOT EXISTS idx_expenses_company_id ON public.expenses(company_id);
CREATE INDEX IF NOT EXISTS idx_suppliers_company_id ON public.suppliers(company_id);
CREATE INDEX IF NOT EXISTS idx_categories_company_id ON public.categories(company_id);

-- Ensure product codes are unique WITHIN each company (not globally)
-- First drop the old unique constraint if it exists
DO $$ 
BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'products_code_key'
    ) THEN
        ALTER TABLE public.products DROP CONSTRAINT products_code_key;
    END IF;
END $$;

-- Create unique constraint on code per company
CREATE UNIQUE INDEX IF NOT EXISTS products_code_company_unique 
ON public.products(code, company_id) 
WHERE is_active = true;