import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CompanyData {
  name: string;
  contact_person: string;
  email: string;
  phone: string;
  address?: string;
  subscription_type: 'basic' | 'premium' | 'enterprise';
  subscription_months: number;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { company }: { company: CompanyData } = await req.json();
    
    // Calculate expiry date
    const expiryDate = new Date();
    expiryDate.setMonth(expiryDate.getMonth() + company.subscription_months);
    
    // Generate database name
    const dbName = company.name.toLowerCase()
      .replace(/[^a-z0-9]/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_|_$/g, '') + '_pos';
    
    // In a real implementation, this would:
    // 1. Create new Supabase project via Management API
    // 2. Set up database schema
    // 3. Configure authentication
    // 4. Set up RLS policies
    
    // For now, we'll simulate the database creation
    console.log(`Creating database for ${company.name}...`);
    
    const setupSQL = `
      -- Company: ${company.name}
      -- Database: ${dbName}
      
      -- Create enums
      CREATE TYPE user_role AS ENUM ('admin', 'manager', 'supervisor', 'cashier');
      CREATE TYPE payment_method AS ENUM ('cash', 'card', 'mobile_money', 'credit');
      CREATE TYPE shift_status AS ENUM ('open', 'closed');
      
      -- Create tables
      CREATE TABLE categories (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        description TEXT,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMPTZ DEFAULT now()
      );
      
      CREATE TABLE suppliers (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        contact_person TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT,
        address TEXT,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMPTZ DEFAULT now(),
        updated_at TIMESTAMPTZ DEFAULT now()
      );
      
      CREATE TABLE products (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        cost_price DECIMAL(10,2),
        stock_quantity INTEGER DEFAULT 0,
        min_stock_level INTEGER DEFAULT 0,
        category_id UUID REFERENCES categories(id),
        supplier_id UUID REFERENCES suppliers(id),
        is_active BOOLEAN DEFAULT true,
        blocked_from_selling BOOLEAN DEFAULT false,
        created_at TIMESTAMPTZ DEFAULT now(),
        updated_at TIMESTAMPTZ DEFAULT now()
      );
      
      CREATE TABLE profiles (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id UUID NOT NULL,
        username TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role user_role NOT NULL DEFAULT 'cashier',
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMPTZ DEFAULT now(),
        updated_at TIMESTAMPTZ DEFAULT now()
      );
      
      CREATE TABLE shifts (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        cashier_id UUID NOT NULL,
        opened_at TIMESTAMPTZ DEFAULT now(),
        closed_at TIMESTAMPTZ,
        opening_cash DECIMAL(10,2) DEFAULT 0,
        closing_cash DECIMAL(10,2),
        status shift_status DEFAULT 'open',
        notes TEXT
      );
      
      CREATE TABLE sales (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        cashier_id UUID NOT NULL,
        shift_id UUID NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL,
        payment_method payment_method NOT NULL,
        tax_amount DECIMAL(10,2) DEFAULT 0,
        discount_amount DECIMAL(10,2) DEFAULT 0,
        created_at TIMESTAMPTZ DEFAULT now()
      );
      
      CREATE TABLE sale_items (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        sale_id UUID NOT NULL REFERENCES sales(id),
        product_id UUID NOT NULL,
        quantity INTEGER NOT NULL,
        unit_price DECIMAL(10,2) NOT NULL,
        total_price DECIMAL(10,2) NOT NULL
      );
      
      -- Enable RLS on all tables
      ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
      ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
      ALTER TABLE products ENABLE ROW LEVEL SECURITY;
      ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
      ALTER TABLE shifts ENABLE ROW LEVEL SECURITY;
      ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
      ALTER TABLE sale_items ENABLE ROW LEVEL SECURITY;
      
      -- Create helper function for role checking
      CREATE OR REPLACE FUNCTION get_user_role(user_uuid uuid)
      RETURNS user_role
      LANGUAGE sql
      STABLE SECURITY DEFINER
      SET search_path = public
      AS $$
        SELECT role FROM public.profiles WHERE user_id = user_uuid;
      $$;
      
      -- Create RLS policies
      CREATE POLICY "Admins and managers can manage categories" ON categories
      FOR ALL USING (get_user_role(auth.uid()) IN ('admin', 'manager'));
      
      CREATE POLICY "Everyone can view active categories" ON categories
      FOR SELECT USING (is_active = true);
      
      -- Add more policies as needed...
      
      -- Insert default admin user
      INSERT INTO auth.users (email, encrypted_password, email_confirmed_at, created_at, updated_at)
      VALUES (
        '${company.email}',
        crypt('admin123', gen_salt('bf')),
        now(),
        now(),
        now()
      );
    `;
    
    console.log('Database setup SQL generated');
    
    // Simulate creating the database URL
    const databaseUrl = `https://${dbName}.supabase.co`;
    const connectionString = `postgresql://postgres:[PASSWORD]@${dbName}.supabase.co:5432/postgres`;
    
    // Return success response with database details
    return new Response(
      JSON.stringify({
        success: true,
        database_name: dbName,
        database_url: databaseUrl,
        connection_string: connectionString,
        expiry_date: expiryDate.toISOString().split('T')[0],
        setup_sql: setupSQL
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
    
  } catch (error) {
    console.error('Error creating company database:', error);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Failed to create company database'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});