import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { Resend } from "npm:resend@4.0.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CompanyData {
  name: string;
  contact_person: string;
  email: string;
  phone: string;
  address?: string;
  subscription_type: 'basic' | 'premium' | 'enterprise';
  subscription_months: number;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    const { company }: { company: CompanyData } = await req.json();
    
    console.log('Creating company:', company.name);
    
    // Calculate expiry date
    const expiryDate = new Date();
    expiryDate.setMonth(expiryDate.getMonth() + company.subscription_months);
    
    // Generate database schema name
    const schemaName = company.name.toLowerCase()
      .replace(/[^a-z0-9]/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_|_$/g, '') + '_db';
    
    // Generate temporary password
    const tempPassword = `Temp${Math.random().toString(36).slice(-8)}!`;
    
    // Check if user already exists by checking profiles first
    const { data: existingProfile } = await supabase
      .from('profiles')
      .select('user_id')
      .eq('username', company.email.split('@')[0])
      .maybeSingle();
    
    let authData;
    if (existingProfile) {
      console.log('Profile already exists, fetching user:', existingProfile.user_id);
      const { data: existingUsers } = await supabase.auth.admin.listUsers();
      const existingUser = existingUsers?.users?.find(u => u.id === existingProfile.user_id);
      if (existingUser) {
        authData = { user: existingUser };
      }
    }
    
    if (!authData) {
      // Create admin user
      const { data: newAuthData, error: authError } = await supabase.auth.admin.createUser({
        email: company.email,
        password: tempPassword,
        email_confirm: true,
        user_metadata: {
          full_name: company.contact_person,
          username: company.email.split('@')[0],
          phone_number: company.phone,
        }
      });

      if (authError) {
        console.error('Error creating admin user:', authError);
        throw new Error(`Failed to create admin user: ${authError.message}`);
      }

      authData = newAuthData;
      console.log('Admin user created:', authData.user.id);
    }

    // Create company record
    const { data: companyData, error: companyError } = await supabase
      .from('companies')
      .insert({
        name: company.name,
        contact_person: company.contact_person,
        email: company.email,
        phone: company.phone,
        address: company.address,
        subscription_type: company.subscription_type,
        expiry_date: expiryDate.toISOString().split('T')[0],
        status: 'active',
        database_name: schemaName,
        schema_name: schemaName,
        admin_email: company.email,
        admin_temp_password: tempPassword,
      })
      .select()
      .single();

    if (companyError) {
      console.error('Error creating company:', companyError);
      // Cleanup: delete the user if company creation fails
      await supabase.auth.admin.deleteUser(authData.user.id);
      throw new Error(`Failed to create company: ${companyError.message}`);
    }

    console.log('Company created:', companyData.id);

    // Create company schema
    const { error: schemaError } = await supabase.rpc('create_company_schema', {
      company_id: companyData.id,
      schema_name: schemaName
    });

    if (schemaError) {
      console.error('Error creating schema:', schemaError);
    }

    // Create profile for admin user
    const { error: profileError } = await supabase
      .from('profiles')
      .insert({
        user_id: authData.user.id,
        username: company.email.split('@')[0],
        full_name: company.contact_person,
        role: 'admin',
        company_id: companyData.id,
        company_schema: schemaName,
        phone_number: company.phone,
        is_active: true,
      });

    if (profileError) {
      console.error('Error creating profile:', profileError);
    }

    // Create admin role
    const { error: roleError } = await supabase
      .from('user_roles')
      .insert({
        user_id: authData.user.id,
        role: 'admin',
      });

    if (roleError) {
      console.error('Error creating role:', roleError);
    }

    // Send email with credentials
    const resend = new Resend(Deno.env.get('RESEND_API_KEY'));
    const loginUrl = `${supabaseUrl.replace('https://', 'https://app.')}`;

    try {
      await resend.emails.send({
        from: 'GB PAWA POS <onboarding@resend.dev>',
        to: [company.email],
        subject: 'Welcome to GB PAWA POS - Your Account is Ready!',
        html: `
          <h1>Welcome to GB PAWA POS!</h1>
          <p>Your company account has been created successfully.</p>
          
          <h2>Company Details:</h2>
          <ul>
            <li><strong>Company Name:</strong> ${company.name}</li>
            <li><strong>Database Schema:</strong> ${schemaName}</li>
            <li><strong>Subscription Type:</strong> ${company.subscription_type}</li>
            <li><strong>Expiry Date:</strong> ${expiryDate.toISOString().split('T')[0]}</li>
          </ul>
          
          <h2>Admin Login Credentials:</h2>
          <ul>
            <li><strong>Email:</strong> ${company.email}</li>
            <li><strong>Temporary Password:</strong> ${tempPassword}</li>
          </ul>
          
          <p><strong>IMPORTANT:</strong> Please change your password immediately after your first login for security reasons.</p>
          
          <p>
            <a href="${loginUrl}" style="display: inline-block; padding: 12px 24px; background-color: #4F46E5; color: white; text-decoration: none; border-radius: 6px; font-weight: bold;">
              Login to Your Account
            </a>
          </p>
          
          <p>If you have any questions, please don't hesitate to contact our support team.</p>
          
          <p>Best regards,<br>GB PAWA POS Team</p>
        `,
      });
      
      console.log('Welcome email sent to:', company.email);
    } catch (emailError) {
      console.error('Error sending email:', emailError);
      // Don't fail the whole process if email fails
    }

    return new Response(
      JSON.stringify({
        success: true,
        company_id: companyData.id,
        schema_name: schemaName,
        admin_email: company.email,
        expiry_date: expiryDate.toISOString().split('T')[0],
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
    
  } catch (error) {
    console.error('Error in create-company function:', error);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Failed to create company'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
